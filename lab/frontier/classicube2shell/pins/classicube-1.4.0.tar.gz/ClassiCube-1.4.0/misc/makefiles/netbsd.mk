SOURCE_DIRS := src third_party/bearssl
BUILD_DIR	:= build/netbsd
TARGET 		:= ClassiCube
DIST_NAME	:= ClassiCube

CFLAGS	:= -I /usr/X11R7/include -I /usr/pkg/include -fvisibility=hidden -fno-ident
LDFLAGS := -L /usr/X11R7/lib -L /usr/pkg/lib -rdynamic -Wl,-R/usr/X11R7/lib
LIBS    := -lexecinfo -lGL -lX11 -lXi -lpthread
include misc/makefiles/common_config.mk


#---------------------------------------------------------------------------------
# executable generation
#---------------------------------------------------------------------------------
include misc/makefiles/common_build.mk


#---------------------------------------------------------------------------------
# common targets
#---------------------------------------------------------------------------------
include misc/makefiles/common_targets.mk

dist: $(TARGET)
	$(call DIST_PKG_INIT_DEFAULT,$(TARGET))
	$(call DIST_PKG_BUILD_TAR,$(TARGET))
