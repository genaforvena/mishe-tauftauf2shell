/* SPDX-License-Identifier: MIT OR GPL-3.0-only */
/* scram.c
 * strophe XMPP client library
 *
 * SCRAM-SHA1 helper functions according to RFC5802
 * HMAC-SHA1 implementation according to RFC2104
 *
 * Copyright (C) 2013 Dmitry Podgorny <pasis.ua@gmail.com>
 *
 *  This software is provided AS-IS with no warranty, either express
 *  or implied.
 *
 *  This program is dual licensed under the MIT or GPLv3 licenses.
 */

/** @file
 *  SCRAM-SHA1 helper functions.
 */

#include <string.h>

#include "common.h"
#include "sha1.h"
#include "sha256.h"
#include "sha512.h"
#include "ostypes.h"

#include "scram.h"

#define HMAC_BLOCK_SIZE_MAX 128

/* Maximum length of a salt SCRAM_Hi() can process. The salt is concatenated
 * with INT(1) into a buffer on the stack, see SCRAM_Hi().
 */
#define SCRAM_SALT_MAX 124

static const uint8_t ipad = 0x36;
static const uint8_t opad = 0x5C;

const struct hash_alg scram_sha1 = {
    "SCRAM-SHA-1",
    SASL_MASK_SCRAMSHA1,
    SHA1_DIGEST_SIZE,
    (void (*)(const uint8_t *, size_t, uint8_t *))crypto_SHA1,
    (void (*)(void *))crypto_SHA1_Init,
    (void (*)(void *, const uint8_t *, size_t))crypto_SHA1_Update,
    (void (*)(void *, uint8_t *))crypto_SHA1_Final};

const struct hash_alg scram_sha1_plus = {
    "SCRAM-SHA-1-PLUS",
    SASL_MASK_SCRAMSHA1_PLUS,
    SHA1_DIGEST_SIZE,
    (void (*)(const uint8_t *, size_t, uint8_t *))crypto_SHA1,
    (void (*)(void *))crypto_SHA1_Init,
    (void (*)(void *, const uint8_t *, size_t))crypto_SHA1_Update,
    (void (*)(void *, uint8_t *))crypto_SHA1_Final};

const struct hash_alg scram_sha256 = {
    "SCRAM-SHA-256",
    SASL_MASK_SCRAMSHA256,
    SHA256_DIGEST_SIZE,
    (void (*)(const uint8_t *, size_t, uint8_t *))sha256_hash,
    (void (*)(void *))sha256_init,
    (void (*)(void *, const uint8_t *, size_t))sha256_process,
    (void (*)(void *, uint8_t *))sha256_done};

const struct hash_alg scram_sha256_plus = {
    "SCRAM-SHA-256-PLUS",
    SASL_MASK_SCRAMSHA256_PLUS,
    SHA256_DIGEST_SIZE,
    (void (*)(const uint8_t *, size_t, uint8_t *))sha256_hash,
    (void (*)(void *))sha256_init,
    (void (*)(void *, const uint8_t *, size_t))sha256_process,
    (void (*)(void *, uint8_t *))sha256_done};

const struct hash_alg scram_sha512 = {
    "SCRAM-SHA-512",
    SASL_MASK_SCRAMSHA512,
    SHA512_DIGEST_SIZE,
    (void (*)(const uint8_t *, size_t, uint8_t *))sha512_hash,
    (void (*)(void *))sha512_init,
    (void (*)(void *, const uint8_t *, size_t))sha512_process,
    (void (*)(void *, uint8_t *))sha512_done};

const struct hash_alg scram_sha512_plus = {
    "SCRAM-SHA-512-PLUS",
    SASL_MASK_SCRAMSHA512_PLUS,
    SHA512_DIGEST_SIZE,
    (void (*)(const uint8_t *, size_t, uint8_t *))sha512_hash,
    (void (*)(void *))sha512_init,
    (void (*)(void *, const uint8_t *, size_t))sha512_process,
    (void (*)(void *, uint8_t *))sha512_done};

/* The order of this list defines the order in which the SCRAM algorithms are
 * tried if the server supports them.
 * Their order is derived from
 * https://datatracker.ietf.org/doc/html/draft-ietf-kitten-password-storage
 */
const struct hash_alg *scram_algs[] = {
    /* *1 */
    &scram_sha512_plus,
    /* *1 */
    &scram_sha256_plus,
    /* *1 */
    &scram_sha1_plus,
    /* *1 */
    &scram_sha512,
    /* *1 */
    &scram_sha256,
    /* *1 */
    &scram_sha1,
};
/* *1 - I want to use clang-format here, but by default it will put multiple
 * elements per line if there's no comment. Currently clang-format also doesn't
 * have an option to enforce it to behave like that, besides by putting comments
 * between each element (or I couldn't find a way to do it). In order to prevent
 * clang-format from re-formatting the array I added the comments above and
 * wrote this lengthy description.
 */
const size_t scram_algs_num = sizeof(scram_algs) / sizeof(scram_algs[0]);

union common_hash_ctx {
    SHA1_CTX sha1;
    sha256_context sha256;
    sha512_context sha512;
};

static void crypto_HMAC(const struct hash_alg *alg,
                        const uint8_t *key,
                        size_t key_len,
                        const uint8_t *text,
                        size_t len,
                        uint8_t *digest)
{
    uint8_t key_pad[HMAC_BLOCK_SIZE_MAX];
    uint8_t key_ipad[HMAC_BLOCK_SIZE_MAX];
    uint8_t key_opad[HMAC_BLOCK_SIZE_MAX];
    uint8_t sha_digest[SCRAM_DIGEST_SIZE];
    size_t blocksize;
    size_t i;
    union common_hash_ctx ctx;

    STROPHE_ASSERTVD(alg->digest_size <= HMAC_BLOCK_SIZE_MAX);
    blocksize = alg->digest_size < 48 ? 64 : 128;

    memset(key_pad, 0, blocksize);
    if (key_len <= blocksize) {
        memcpy(key_pad, key, key_len);
    } else {
        /* according to RFC2104 */
        alg->hash(key, key_len, key_pad);
    }

    for (i = 0; i < blocksize; i++) {
        key_ipad[i] = key_pad[i] ^ ipad;
        key_opad[i] = key_pad[i] ^ opad;
    }

    alg->init((void *)&ctx);
    alg->update((void *)&ctx, key_ipad, blocksize);
    alg->update((void *)&ctx, text, len);
    alg->final((void *)&ctx, sha_digest);

    alg->init((void *)&ctx);
    alg->update((void *)&ctx, key_opad, blocksize);
    alg->update((void *)&ctx, sha_digest, alg->digest_size);
    alg->final((void *)&ctx, digest);
}

static int SCRAM_Hi(const struct hash_alg *alg,
                    const uint8_t *text,
                    size_t len,
                    const uint8_t *salt,
                    size_t salt_len,
                    uint32_t i,
                    uint8_t *digest)
{
    static uint8_t int1[] = {0x0, 0x0, 0x0, 0x1};

    size_t k;
    uint32_t j;
    uint8_t tmp[SCRAM_SALT_MAX + sizeof(int1)];

    /* The salt is attacker-controlled, it comes from the 's=' attribute of
     * the server-first-message, therefore this has to be checked at runtime
     * instead of with assert().
     */
    if (salt_len > SCRAM_SALT_MAX) {
        return -1;
    }

    memset(digest, 0, alg->digest_size);
    if (i == 0) {
        return 0;
    }

    memcpy(tmp, salt, salt_len);
    memcpy(&tmp[salt_len], int1, sizeof(int1));

    /* 'text' for Hi is a 'key' for HMAC */
    crypto_HMAC(alg, text, len, tmp, salt_len + sizeof(int1), digest);
    memcpy(tmp, digest, alg->digest_size);

    for (j = 1; j < i; j++) {
        crypto_HMAC(alg, text, len, tmp, alg->digest_size, tmp);
        for (k = 0; k < alg->digest_size; k++) {
            digest[k] ^= tmp[k];
        }
    }

    return 0;
}

int SCRAM_ClientKey(const struct hash_alg *alg,
                    const uint8_t *password,
                    size_t len,
                    const uint8_t *salt,
                    size_t salt_len,
                    uint32_t i,
                    uint8_t *key)
{
    uint8_t salted[SCRAM_DIGEST_SIZE];

    /* XXX: Normalize(password) is omitted */

    if (SCRAM_Hi(alg, password, len, salt, salt_len, i, salted) != 0) {
        return -1;
    }
    crypto_HMAC(alg, salted, alg->digest_size, (uint8_t *)"Client Key",
                strlen("Client Key"), key);

    return 0;
}

void SCRAM_ClientSignature(const struct hash_alg *alg,
                           const uint8_t *ClientKey,
                           const uint8_t *AuthMessage,
                           size_t len,
                           uint8_t *sign)
{
    uint8_t stored[SCRAM_DIGEST_SIZE];

    alg->hash(ClientKey, alg->digest_size, stored);
    crypto_HMAC(alg, stored, alg->digest_size, AuthMessage, len, sign);
}

void SCRAM_ClientProof(const struct hash_alg *alg,
                       const uint8_t *ClientKey,
                       const uint8_t *ClientSignature,
                       uint8_t *proof)
{
    size_t i;
    for (i = 0; i < alg->digest_size; i++) {
        proof[i] = ClientKey[i] ^ ClientSignature[i];
    }
}
