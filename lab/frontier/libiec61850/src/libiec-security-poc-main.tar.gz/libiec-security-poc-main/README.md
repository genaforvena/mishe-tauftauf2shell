# libIEC61850 v1.6.1 — MMS/GOOSE vulnerability PoCs

Proof-of-concept code for four memory-safety vulnerabilities in
[libIEC61850](https://github.com/mz-automation/libiec61850) ≤ v1.6.1. All four are
**pre-authentication** and network-reachable in the default configuration: the MMS server binds
`INADDR_ANY` on TCP/102 with no authenticator by default, and the GOOSE subscriber processes frames
directly off the wire.

**Full technical write-up:** <https://abhinavagarwal07.github.io/posts/libiec61850-mms-goose-cves/>

All PoCs run against `127.0.0.1` in an isolated lab. For security research and defensive testing only.

## Vulnerabilities

| CVE | Component | Class (CWE) | Impact | CVSS v3.1 / v4 | Directory |
|-----|-----------|-------------|--------|----------------|-----------|
| [CVE-2026-49035](https://nvd.nist.gov/vuln/detail/CVE-2026-49035) | MMS file service | Heap overflow via integer underflow (CWE-122/191) | **RCE** (lab) / DoS | 8.1 / 9.2 | [`CVE-2026-49035-mms-fileread-heap-rce/`](CVE-2026-49035-mms-fileread-heap-rce/) |
| [CVE-2026-50039](https://nvd.nist.gov/vuln/detail/CVE-2026-50039) | MMS value cache | Stack overflow, unbounded copy (CWE-121) | DoS | 7.5 / 8.7 | [`CVE-2026-50039-mms-valuecache-stack-bof/`](CVE-2026-50039-mms-valuecache-stack-bof/) |
| [CVE-2026-50032](https://nvd.nist.gov/vuln/detail/CVE-2026-50032) | MMS write service | NULL deref on empty `listOfData` (CWE-476) | DoS | 7.5 / 8.7 | [`CVE-2026-50032-mms-write-nvl-null/`](CVE-2026-50032-mms-write-nvl-null/) |
| [CVE-2026-50103](https://nvd.nist.gov/vuln/detail/CVE-2026-50103) | GOOSE / R-GOOSE parser | NULL deref on malformed TLV (CWE-476/228) | DoS | 6.5 / 7.1 | [`CVE-2026-50103-goose-null-deref/`](CVE-2026-50103-goose-null-deref/) |

**Affected:** v1.0.0 through v1.6.1. Validated against **commit `a1396111`** (v1.6.1 tip).

## CVE-2026-49035 — unauthenticated MMS → RCE

`maxPduSize` from the MMS Initiate request has no lower bound. `maxFileChunkSize = maxPduSize - 20`
(`mms_file_service.c:834`) underflows to ~4 GB when `maxPduSize < 20`, so the chunk-size guard is
bypassed and a FileRead response copies an entire staged file into a fixed 65,100-byte heap buffer.

[`CVE-2026-49035-mms-fileread-heap-rce/rce/`](CVE-2026-49035-mms-fileread-heap-rce/rce/) is a
self-contained, Dockerized end-to-end RCE: `maxPduSize=1` → stage a payload via the default-enabled MMS
**ObtainFile** service → FileRead heap overflow → COTP-state corruption → `free@GOT` overwrite →
`system()`. Proven by an strace `execve` capture and a nonce-stamped proof file, with a patched build as
negative control.

```bash
cd CVE-2026-49035-mms-fileread-heap-rce/rce
bash run.sh          # Docker + Python 3, ~2 min
```

> **Lab conditions for the full RCE:** ASLR disabled and a non-PIE build (both common in fielded
> IEC 61850 devices; the Dockerfile verifies non-PIE with `readelf`). Under PIE + ASLR the same bug is a
> reliable pre-auth DoS and would additionally require an info-leak primitive to reach code execution —
> not demonstrated here. The DoS is unconditional.

## Repository layout

```
CVE-2026-xxxxx-.../
  README.md      # root cause, CVSS, reproduction, fix status
  poc/           # exploit client, vulnerable-server harness, models, build/run scripts,
                 # patch diff (fix), negative/positive controls, evidence (ASAN logs, pcaps)
  rce/           # (49035 only) Dockerized end-to-end RCE + captured evidence
```

## Safety and reproducibility

**Run these in a disposable VM or throwaway environment.** A few notes:

- The RCE harness (`rce/run.sh`) disables ASLR **per process** via `setarch -R` (ADDR_NO_RANDOMIZE),
  relaxing seccomp for that container only (`--security-opt seccomp=unconfined`, which the `personality()`
  syscall `setarch` uses requires under Docker's default profile). It does **not** modify the host's
  `kernel.randomize_va_space` and does not use `--privileged`.
- The RCE exploit uses **hard-coded AArch64** heap/GOT/libc/`system()` offsets against an **un-pinned**
  Ubuntu base image. The end-to-end `system()` result reproduces only in that AArch64 environment; on
  other architectures or after base-image updates it demonstrates the crash, and the offsets must be
  re-derived. Treat `rce/output_*/` as a captured evidence trail (its `manifest.sha256` is a record, not
  a sealed manifest — logging continued after hashing).
- The value-cache build applies a patch to the fetched library checkout and reverts it with
  `git checkout`; a mid-run failure can leave `.libiec61850` modified (recover with
  `git -C .libiec61850 checkout .` or re-run `./setup.sh`).

## Building and running

Two independent flows — a one-time `setup.sh` for the `poc/*` crash harnesses, and a self-contained
Docker build for the RCE. Everything works from a **standalone clone of this repository**.

```bash
git clone https://github.com/abhinavagarwal07/libiec-security-poc
cd libiec-security-poc

# poc/* crash harnesses: fetch the pinned libIEC61850 source once, then build any CVE
./setup.sh
export LIBIEC61850_SRC="$PWD/.libiec61850"
( cd CVE-2026-50032-mms-write-nvl-null/poc && ./build.sh && ./run_poc.sh )

# CVE-2026-49035 RCE: self-contained — the Dockerfile clones libIEC61850 itself
( cd CVE-2026-49035-mms-fileread-heap-rce/rce && bash run.sh )   # Docker + Python 3
```

`setup.sh` clones libIEC61850 at the pinned commit `a1396111` into `./.libiec61850` and each
`poc/*/build.sh` honors `$LIBIEC61850_SRC` (falling back to the original in-tree layout if unset).
Each per-CVE `README.md` gives the root cause with `file:line`, CVSS, the expected crash signature
(ASAN / stack-canary / GDB), and the negative and patched controls. Fixes are included as
`patch_*.diff`.

## Fix status

Fixed in **v1.6.2** — all four, committed to the public `v1.6_develop` branch on 2026-05-08 (the day
after disclosure): CVE-2026-49035 ([`db35acf6`](https://github.com/mz-automation/libiec61850/commit/db35acf6)),
CVE-2026-50039 ([`a0bd0aaa`](https://github.com/mz-automation/libiec61850/commit/a0bd0aaa)),
CVE-2026-50103 ([`62f22887`](https://github.com/mz-automation/libiec61850/commit/62f22887)),
CVE-2026-50032 ([`bd338f23`](https://github.com/mz-automation/libiec61850/commit/bd338f23)). The four fix
commits (or the `patch_*.diff` files here) apply cleanly to v1.6.1. Keep IEC 61850 services off untrusted
networks.

## Use

For security research, detection engineering, and defensive testing only. Do not use against systems
you do not own or are not explicitly authorized to test.
