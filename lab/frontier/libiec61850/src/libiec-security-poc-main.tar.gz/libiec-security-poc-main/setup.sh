#!/usr/bin/env bash
# Fetch the exact libIEC61850 source these PoCs target, so the poc/* harnesses
# build from a standalone clone of THIS repository.
#
#   ./setup.sh
#   export LIBIEC61850_SRC="$PWD/.libiec61850"
#   ( cd CVE-2026-50032-mms-write-nvl-null/poc && ./build.sh && ./run_poc.sh )
#
# The four poc/*/build.sh scripts honor $LIBIEC61850_SRC. The RCE harness
# (CVE-2026-49035-.../rce) is independent — it clones the library inside its
# own Docker image.
set -euo pipefail

REPO_URL="${LIBIEC61850_REPO:-https://github.com/mz-automation/libiec61850}"
COMMIT="${LIBIEC61850_COMMIT:-a1396111}"
DEST="$(cd "$(dirname "$0")" && pwd)/.libiec61850"

if [ -d "$DEST/.git" ]; then
    echo "[*] $DEST already present; fetching..."
    git -C "$DEST" fetch origin
else
    echo "[*] Cloning $REPO_URL into $DEST ..."
    git clone "$REPO_URL" "$DEST"
fi
git -C "$DEST" checkout -q "$COMMIT"

echo "[+] libIEC61850 checked out at $(git -C "$DEST" rev-parse --short HEAD)"
echo
echo "Next:"
echo "    export LIBIEC61850_SRC=\"$DEST\""
echo "    ( cd CVE-2026-50032-mms-write-nvl-null/poc && ./build.sh && ./run_poc.sh )"
