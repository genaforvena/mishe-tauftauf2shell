/sbin/ldconfig
