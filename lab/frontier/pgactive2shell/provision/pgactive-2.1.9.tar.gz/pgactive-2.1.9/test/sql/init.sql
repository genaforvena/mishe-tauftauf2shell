-- This should be done with pg_regress's --create-role option
-- but it's blocked by bug 37906
CREATE USER nonsuper;
CREATE USER super SUPERUSER;

-- Can't because of bug 37906
--GRANT ALL ON DATABASE regress TO nonsuper;
--GRANT ALL ON DATABASE regress TO nonsuper;

\c postgres
GRANT ALL ON SCHEMA public TO nonsuper;
\c regression
GRANT ALL ON SCHEMA public TO nonsuper;

\c postgres
CREATE EXTENSION btree_gist;
CREATE EXTENSION pgactive;

\c regression
CREATE EXTENSION btree_gist;
CREATE EXTENSION pgactive;

-- DDL lock state before pgactive comes up
SELECT * FROM pgactive.pgactive_get_global_locks_info();

-- pgactive functions must behave sanely when the database hasn't been added
-- yet to the pgactive group.
CREATE DATABASE test;

\c test
CREATE EXTENSION pgactive;
SELECT pgactive.pgactive_get_local_nodeid();
SELECT pgactive.pgactive_get_replication_lag_info();
SELECT pgactive.pgactive_skip_changes('unknown', 0, 0, '0/FFFFFFFF');
SELECT pgactive.pgactive_get_global_locks_info();

\c regression

DROP DATABASE test;
