dnl aclocal.m4
