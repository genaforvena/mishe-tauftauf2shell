# Release Notes

## 2.93

Added a new *admirations* entry point to the web UI, containing a timeline of liked, boosted and reacted posts. Please take note that, after installing the new version, it will start empty, and be filled with subsequent reactions (contributed by violette).

It's now possible to disable showing posts in a given set of languages.

Nested quoted posts are limited up to 3 levels.

New configuration knob: by setting `keep_replies_posts` to true in `server.json`, remote posts that a local user has replied to are retained in the public timeline, preventing them from being purged (contributed by hanchan).

New configuration knob: by setting `keep_replied_me` to true in `server.json`, remote replies to local posts are retained in the public timeline, preventing them from being purged (contributed by hanchan).

Ensure actors' public key PEM never includes anything after the end marker.

Fixed some memory leaks (contributed by inz).

Several additional keyId checks (many thanks to lainsoykaf for bringing this to my attention).

Fixed crash in the JSON parser (many thanks to nullenvk for bringing this to my attention).

Mastodon API: fixed lost custom emojis after edition (contributed by e0w0e).

Updated French, Brazilian Portuguese, German, Spanish translations (contributed by dragondaddy, daltux, zen).

## 2.92

Changed default: for newly created instances, `disable_inbox_collection` is set to `true` (see `snac(8)` for more information). The reason is because it seems to be used for harrasing people.

Changed default: for newly created instances, `disable_history` is set to `true` (see `snac(8)` for more information). The reason is because archived history files don't reflect reality after posts are deleted or modified (they always have been an ugly kludge).

Changed default: in previous versions, posts with a scope of `unlisted` were shown in public pages and RSS feeds. Now, they are no longer shown. If you want to get back to previous behaviour, use a new toggle in the User Settings section (see `snac(1)` for more information).

New admin configuration option: if the `purge_static` value is set to `true` in `server.json`, each user's static directory is explored and those files there that are no longer attached to any post or referenced anywhere are deleted. See `snac(8)` for more information about those cases where you may not want to enable this option.

Allow serving files from subdirectories of the `static/` subdirectory (contributed by la_ninpre).

Minor tweak to webfinger code to handle Hubzilla's peculiarities.

Fixed a search case where URLs to GotoSocial statuses were misidentified as accounts.

Accounts that follow you are now marked with a thumb-up emoji, because followers are adorable people.

Fixed some account export errors.

Fixed an incorrect hash in post links.

Show an account's location link in the people page, if they have one.

Mastodon API: Fixed hashtags loosing the link after editing a post, minor tweak in access token processing (contributed by trondd555).

Drop usage of PATH_MAX (contributed by sergiodj).

New Polish translation (contributed by kpm).

Updated German and Czech translations (contributed by zen and pmjv).

## 2.91

Fixed some local posts not being shown if the replied post is deleted.

Fixed web UI incorrect links to public posts for some configurations.

Fixed encoding bug in Mastodon-style share links.

Fixed an error that made imposible to leave empty the following hashtags or blocked hashtags from the web UI.

Include post attachments in the RSS feed entries.

Added some OpenBSD-specific documentation (contributed by oxzi).

Fixed some timezones (contributed by matoken).

Fixed some crashes (special thanks to Louis Merlin for helping me with this).

Updated Docker scripts to avoid generating a useless log file.

Fixed several memory leaks, key generation errors and HTML inconsistencies (contributed by dandelions).

Added ostatus.org and FEP-3b86 data to Webfinger objects.

Added a new CONTRIBUTING.md file. Among other guidelines, I explicitly say there that AI contributions are **NOT** accepted.

snac is now available as a [Yunohost app](https://apps.yunohost.org/app/snac). Thank you very much to Bruno Cesar Rocha for this.

## 2.90

Minor tweak to improve signature key retrieving for some Wordpress configurations.

Fixed web UI incorrect links to actor public pages for some configurations.

Fixed mismatch in the accounts being followed number in the public and people pages.

Notifications can be filtered by category (contributed by byte).

Dates are shown adjusted to the account's time zone (contributed by dandelions).

Configurable limit for poll items (contributed by dandelions).

Fixed incorrect scope when editing a post (contributed by dandelions).

Change the strip_exif logic to work with the already existing OpenBSD sandbox (contributed by oxzi).

Mastodon API: Add poll creation (contributed by davidrv00), fixed a voting bug (contributed by davidrv00), added a fix to verify_credentials (contributed by ag-eitilt).

Updated Czech, German, Brazilian Portuguese, Spanish translations (contributed by pmjv, zen, daltux).

## 2.89

Fixed crash in pronouns processing (contributed by byte).

Added counters in the people page (contributed by byte).

New command-line option `refresh`, to refresh all follower and following `Actor` objects, marking them as broken if they are.

## 2.88

If `disable_emojireact` is set to `true` in `server.json`, EmojiReacts (incoming and outgoing) are totally disabled.

New command-line option `top_ten`, that returns the top ten most popular posts by a user (ordered by the sum of likes and boosts) (contributed by aov).

Added a new set of per-user muted words; if a post contains any of them, it's hidden behind a dropdown (contributed by byte).

If an account has a metadata named `pronouns`, it's shown by the name (contributed by violette).

Mastodon API: children of a post are returned recursively, not just the first level (contributed by violette).

Implemented optional metadata stripping for images and videos using external tools (contributed by Stefano Marinelli).

## 2.87

Hide EmojiReacts from muted actors and blocked instances.

## 2.86

Truncate RSS titles at UTF-8 character boundaries (contributed by lxo).

Link contacts to single-user people pages. Also, user's posts are shown (contributed by lxo).

Added emoji reactions (contributed by violette).

Mastodon API: Fix for some client notifications (contributed by violette), fix for a status visibility error (contributed by fruye).

If the query variable `terse` of a public post page is set to anything, no header is shown.

Fixed search failures when the query string has any leading blank.

## 2.85

Quoted posts are now shown.

Added metadata to remote users in the people page (contributed by dandelions).

Fixed memory leak (contributed by dandelions).

Fixed user matching (contributed by rakoo).

Rendering visibility conditionally, with lesser reach if needed (contributed by byte).

Added a button next to a follow notification to follow back.

Fixed typo in man page (contributed by spky).

Updated Czech and German translations (contributed by pmjv and zen).

## 2.84

Implemented more scopes to match other ActivityPub implementations (public, unlisted, followers-only and direct message) (contributed by byte).

New icons showing instance and actor failures.

Mastodon API: Added remote accounts follow metrics and statuses when viewing profiles (contributed by Stefano Marinelli), fixed post deletion.

Fixed outbox collection (contributed by byte).

New file FEDERATION.md (contributed by andypiper).

Updated Czech, Spanish and Brazilian Portuguese translations (contributed by pmjv and daltux).

Fixed manpage typos (contributed by r-ricci).

## 2.83

After receiving a follow confirmation, a bunch of posts from that account are requested and inserted into the timeline as context.

Continuously failing instances are marked as broken after a given number of days (see `snac(8)` on how to tune this counter). Incoming activity from any of these instances resets the counter.

Fixed a nasty bug that incorrectly deleted private local posts in certain cases.

Scheduled posts can now be sent from the command line (see `snac(1)` for more information on how to do it).

Docker: add timezone, new examples for building and complete Swarm mode stack with Traefik (contributed by daltux).

Fixed timezone names (contributed by dharmik).

Documented the `update` command (contributed by xvello).

## 2.82

The language in which a post is written can now be set from the UI; you must configure the list of languages you usually post in in the User Settings.

Added support for bullet points in posts (lines starting with an asterisk or a hyphen, plus a space).

Added Dutch (nl_NL) translation (contributed by martijndeb).

Added Western Frisian (fy_NL) translation (contributed by martijndeb).

Mastodon API: Fixed repeated entries in timelines.

Added nodeinfo 2.1 support.

Fixed boosts from the command line not showing in the public timeline (contributed by xvello).

Updated several language files (contributed by zen and daltux).

Retrieving a post's replies is now possible via ActivityPub.

## 2.81

If the `propagate_local_purge` configuration variable is set to `true` in `server.json`, purged local posts generate a `Delete` activity that is sent everywhere, instead of only deleted from the filesystem.

Included a small tweak to avoid being confused by implementations that return valid webfinger queries for non-account URLs (like i.e. the Wordpress ActivityPub plugin in some configurations). This helps in searching by URL.

Added Ukrainian translation (contributed by wincentbalin).

New command-line option `muted`, to list all MUTEd actors.

Mastodon API: Fixed metadata and follower approval flag when editing the account.

## 2.80

Mastodon API: fixed a regression (introduced in previous version in the "boosts disappear in Tusky" fix) that interrupted timelines.

## 2.79

Added a server-wide Webmention hook; this way, if somebody out there (that supports Webmention) links to a user or post in this instance, a notification is sent (this is the complementary of what was implemented in version 2.76).

Fixed regression while sending email via pipe on OpenBSD.

Fixed Markdown parsing when the URL has parenthesis.

Always show the 'pending follow confirmations' section if there are any (even if the toggle is off).

If a metadata value is an account handler, it's also tried to be validated (rel="me" links).

Another search by URL tweak (this time for Pixelfed links).

Mastodon API: fixed a bug that made some boosts disappear after being shown in apps like Tusky, added followed hashtags maintenance, other minor changes.

Renamed command-line actions `create_list` to `list_create` and `delete_list` to `list_remove`.

The default favicon URL can be changed from the server configuration.

New command-line option `export_posts`, to export all posts by a user in a JSON format compatible with the one generated by Mastodon.

The command-line options to send notes also allow an optional `-r` argument, to set the URL of a Fediverse post this note is a reply to.

## 2.78

Hashtag following also allow URLs to RSS feeds of ActivityPub objects (like e.g. https://mastodon.social/tags/ThankYouTuesday).

Users can now configure a webhook to receive an HTTP POST for every notification. This can be useful for implementing bots that react to activities, like autorepliers, chatbots or interactive textual games (see `snac(1)` for more information).

The number of pending follow confirmations is shown next to the "people" link.

Faster performance metrics (contributed by dandelions).

Improved lowercasing in hashtags (contributed by postscriptum).

A search-by-url tweak for implementations that return 200 for invalid webfinger queries (e.g. piefed).

Mastodon API: added follow confirmation endpoints, fixed collisions in attachment file names.

Fixed potential crashes in attachment uploads.

## 2.77 "Ugly Links Everywhere"

As they look confusing in some platforms, links in content posts are no longer included as `Link` attachments.

## 2.76

Added Webmention support for links (Markdown-style or direct) written in a post.

Added new command-line options for list maintenance.

Display custom emoji in more places (contributed by dandelions).

Mastodon API: fixed infinite scroll in many clients (thanks to cheeaun for giving me the clue), added `/api/v1/accounts/.../lists` endpoint (contributed by dandelions).

Email notifications can now be sent via `libcurl` SMTP instead of spawning the `/usr/sbin/sendmail` program. To use this new feature, some additional server configuration is needed, see `snac(8)` (contributed by shtrophic).

## 2.75 "Time Is On My Side"

Added support for scheduled posts (for this to work correctly, users will have to set their time zone, see below).

The user can now select a working time zone. This will be used to correctly parse the local date and time of a scheduled post.

Fixed incorrect poll vote format, which was causing problems in platforms like GotoSocial.

Mastodon API: added support for `/api/v1/instance/peers`.

Added a new `snac-admin` helper script (contributed by shtrophic).

In the web UI, posts are separated by the `<hr hidden>` tag; it's invisible in graphical browsers, but it separates post clearly in text-based browsers.

Some Finnish, Spanish, Czech and Russian translation updates and fixes.

## 2.74 "The Days of Nicole, the Fediverse Chick"

Added Spanish (default, Argentina and Uruguay) translation (contributed by gnemmi).

Added Czech translation (contributed by pmjv).

Added Brazilian Portuguese translation (contributed by daltux).

Added Finnish translation (contributed by inz).

Added French translation (contributed by Popolon).

Added Russian translation (contributed by sn4il).

Added Chinese translation (contributed by mistivia).

Added German translation (contributed by zen and Menel).

Added Greek translation (contributed by uhuru).

Added Italian translation (contributed by anzu).

Mastodon API: added support for `/api/v1/custom_emojis` (contributed by violette).

Improved Undo+Follow logic (contributed by rozenglass).

Reverted (temporarily) the Markdown code that converted text between underscores to italics, because it was causing more problems that what it was worth.

Fixed bug in bookmark CSV import.

Don't indent Twitter-like "threads" (i.e. chains of short posts from the same author that are self-replies).

## 2.73

Added support for customizing and translating the web UI language via simple `.po` files. For more information on how to install language files or create new ones, please see `snac(8)` (the administrator manual).

New user support for blocking hashtags from the web UI.

The `Content-Security-Policy` HTTP header is now always sent to disable any JavaScript, instead of just being suggested in the documentation.

Image attachments in SVG format are now disabled by default; you can enable them back by setting the `enable_svg` value to `true` in `server.json`.

Several fixes (contributed by inz).

## 2.72

Each post can have more than one attachment from the web UI. The maximum number can be configured in `server.json` via the `max_attachments` value (default: 4).

Each notification includes a link labelled `Context`, that leads to a page with the full conversation tree the post is a part of.

Each followed hashtag has now a directly accesible link.

Fixed a search bug (some matches were missed).

Fixed more crashes (contributed by inz).

Fixed link detection in posts (contributed by inz).

Allow multiple editors for command-line posts (contributed by inz).

Separated maximum and default timeline entry count, allowing larger timelines to be requested without having to increase the default (contributed by lxo).

Turned message date into a link to the local post, so that it can be loaded into a separate tab for interacting with (contributed by lxo).

Special thanks to fellow developer inz for bringing my attention to code places where I should have been more careful.

## 2.71

Fixed memory leak (contributed by inz).

Fixed crash.

## 2.70

Notifications are now shown in a more compact way (i.e. all reactions are shown just above your post, instead of repeating the post *ad nauseam* for every reaction).

New command-line option `unmute` to, well, no-longer-mute an actor.

The private timeline now includes an approximate mark between new posts and "already seen" ones.

Fixed a spurious 404 error in the instance root URL for some configurations.

## 2.69 "Yin/Yang of Love"

Added support for subscribing to LitePub (Pleroma-style) Fediverse Relays like e.g. https://fedi-relay.gyptazy.com to improve federation. See `snac(8)` (the Administrator Manual) for more information on how to use this feature.

Added support for following hashtags. This is only useful if your instance is subscribed to relays (see above).

Added support for a Mastodon-like `/authorize_interaction` webpoint entry, that allows following, liking and boosting from another account's Mastodon public web interface. To be able to use it, you must reconfigure your https proxy to redirect `/authorize_interaction` to snac (see `snac(8)`).

Some fixes to accept `Event` objects properly (like those coming from implementations like https://gancio.org/ or https://mobilizon.fr).

Added some caching for local `Actor` objects.

Hashtags that are not explicitly linked in a post's content are shown below it.

Fixed broken NetBSD build (missing dependency in Makefile.NetBSD).

The user profile can now include longitude and latitude data for your current location.

Mastodon API: implemented limit= on notification fetches (contributed by nowster), implemented faster min_id handling (contributed by nowster), obey the quiet public visibility set for posts, other timeline improvements (contributed by nowster).

Reduced RSA key size for new users from 4096 to 2048. This will be friendlier to smaller machines, and everybody else out there is using 2048.

If the `SNAC_BASEDIR` environment variable is defined and set to the base directory of your installation, you don't have to include the base directory in the command line.

Fixed a bug in the generation of the top page (contributed by an-im-dugud).

Added support for Markdown headers and underlining (contributed by an-im-dugud).

## 2.68

Fixed regression in link verification code (contributed by nowster).

Added ipv6 support for the https frontend connection (contributed by hb9hnt).

New "Like by URL" operation (contributed by dheadshot).

Added support for a Mastodon-like `/share` link sharing URL, like the one provided by sites like https://mastodonshare.com/ and such. To be able to use it, you must reconfigure your https proxy to redirect `/share` to snac (see `snac(8)`).

New linux landlock (sandboxing) support for enhanced security (contributed by shtrophic). It's still a bit experimental, so you have to enable it explicitly by recompiling with the WITH_LINUX_SANDBOX directive (e.g. `make CFLAGS=-DWITH_LINUX_SANDBOX`).

Some search fixes regarding repeated matches.

The `export_csv` cmdline operation now exports the CSV files inside a user's `export/` subdirectory instead of the current directory.

All CSV files to be imported must now be stored inside a user's `import/` subdirectory instead of the current directory.

Mastodon API: more timeline paging tunings (contributed by nowster), post language selected in apps is properly set.

The command-line operation `note` new reads the `LANG` environment variable to set the post's language.

A new command-line operation, `note_unlisted`, allows posting "unlisted" or "quiet public" posts.

The maximum number of entries in users' RSS feeds and in outboxes can now be set via the `max_public_entries` variable in the `server.json` file.

Fixed broken support for `Audio` objects.

Made xmpp and mailto URLs clickable.

## 2.67

The search box also accepts post URLs; the post is requested and, if it's found, can be interacted with (liked, boosted, replied to, etc.).

IP addresses for failed logins are tracked and throttled to mitigate brute force attacks (see `snac(8)` for more information).

Fixed a bug regarding repeated attachments when editing a post.

Mastodon API: Improved timeline pagination in some clients (details: an HTTP `Link` header has been added), fixed missing audio attachments, fixed an incorrect value for the `bot` field in newly created accounts, fixed a crash, implemented markers (contributed by nowster).

When running in server mode, the pidfile is locked to avoid concurrent running of the same server instance.

Added documentation and some tweaks to enable static compilation with musl (contributed by Shamar).

## 2.66

As many users have asked for it, there is now an option to make the number of followed and following accounts public (still disabled by default). These are only the numbers; the lists themselves are never published.

Some fixes to blocked instances code (posts from them were sometimes shown).

Fixed non-appearing buttons `Approve` and `Discard` if the account requesting a follow were being followed.

## 2.65

Added a new user option to disable automatic follow confirmations (follow requests must be manually approved from the people page).

The search box also searches for accounts (via webfinger).

New command-line action `import_list`, to import a Mastodon list in CSV format (so that [Mastodon Follow Packs](https://mastodonmigration.wordpress.com/?p=995) can be directly used).

New command-line action `import_block_list`, to import a Mastodon list of accounts to be blocked in CSV format.

## 2.64

Some tweaks for better integration with https://bsky.brid.gy (the BlueSky bridge by brid.gy).

A corner case bug in the media proxying code has been fixed.

Hashtags can now include underscores.

The server now creates a pidfile inside the data directory.

Mastodon API: fixed a crash in the notification code, fixed autocapitalization in the OAuth login field (contributed by fkooman).

## 2.63

The server can now act as a proxy for all image, audio or video media coming from other account's posts (both from the Web UI and the Mastodon API). This way, other servers will see media requests coming from the server IP, not the user's, improving privacy. This is controlled by setting the `proxy_media` boolean field to `server.json` to true.

The `strict_public_timelines` option introduced in the previous release now works correctly.

Fixed a crash when posting from the links browser.

Fixed some repeated images from Lemmy posts.

Fixed a crash when posting an image from the tooot mobile app.

Updated FreeBSD rc script: the server process is now managed by the daemon(8) utility (contributed by @stefano@bsd.cafe).

RSS feeds are now in 2.0 version instead of 0.91.

## 2.62

Added a new user option to collapse top level threads by default.

Added a new `disable_block_notifications` boolean field to `server.json` to disable the notifications of Block activities.

Added a new `strict_public_timelines` boolean field to `server.json` to only show an account's posts and boosts (no trees) in public timelines.

Fixed repeated images in posts from some implementations (those that include an image both as an attachment and as an `<img>` tag inside the post content).

Added a small HTML/CSS tweak to improve post previews from some implementations (contributed by nyanide).

Notifications for `EmojiReact` activities now show the emoji.

New command-line action `insert`, to insert a post by its URL in a user's timeline.

Fixed bad processing/rendering of URLs with two or more @ symbols.

## 2.61

Migration from a Mastodon account to a snac one has been implemented. Please see `snac(8)` (the administrator manual) for more information.

Mastodon API: fixed `timelines/public` (it was showing less posts that it should).

Fixed over-zealous caching to the public timeline.

Some HTML tweaks and fixes to the web interface.

## 2.60

Migration from a snac account to a Mastodon one has been implemented. Please see `snac(8)` (the administrator manual) for more information.

Fixed a bug in argument parsing regarding some special characters (contributed by ndagestad).

Fixed image emojis in the public profile bio.

## 2.59

Added post drafts: new or edit post edition dialogs include a checkbox that will cause the message to not be posted, but stored in a list of drafts, directly accesible from the private timeline. From that list, drafts can be edited and definitely posted (or re-stored as a draft for later editing).

Fixed a bug that caused `Block` notifications to not be shown properly.

Fixed crash in a corner case of the URL parameter parsing code.

## 2.58

Search by content also looks into alt-text from attachments (images, videos, etc.).

Search by content is case insensitive for all Unicode-supported alphabets (previously was only for ASCII characters).

Added support for bookmarking posts.

Fixed a failed compilation under Solaris/Illumos.

The actor `Person` object now includes a `featured` property, that returns the list of pinned posts.

The delete post button can now be hidden server-wise (it's not very useful and clutters the space).

The lists of pinned and bookmarked posts are directly accesible from the private timeline.

## 2.57

Added support for listening on UNIX-like sockets.

Don't allow empty polls.

Added support for Markdown-style images (converted to attachments) and strikethrough text.

Added support for incoming `Move` messages: when received, the new account is followed and the old one is unfollowed.

Incoming `EmojiReact` messages are internally converted to `Like` (more proper support will happen eventually).

Blocks are also notified.

Mastodon API: fixed a cache bug when following local users.

## 2.56

Don't show instance announcements in public timelines (contributed by sarahpw).

Added auto boosting. If an account has this flag enabled, all mentions to that account are automatically boosted to all its followers (contributed by sarahpw).

Fixed typos in manpages (contributed by sergiodj).

Some minor performance improvements (contributed by Claire).

## 2.55

Mastodon API: fixed a last-minute bug that broke some API functions.

## 2.54

Markdown-style links are now supported.

The alt text in attachments that have one is also shown in a dropdown just below it (useful for environments where mouseover is not available, i.e. for phones and tablets).

Instance-wide notifications has been implemented (contributed by louis77). A small tweak to the default CSS was made to suit this change; please consider updating your style.css (see doc/style.css as an example).

The avatar and/or the header images can now be deleted (contributed by louis77).

Code cleaning: HTTP status codes use names instead of hardcoded integers (contributed by louis77).

Mastodon API: fixed login problems with the official Mastodon API, IceCube and Toot! on iOS, some fixes for Mona and Tokodon apps, user credentials can now be edited from apps (all contributed by louis77), fixed crash on unset content-type header.

The webfinger content-type response header is now RFC-compliant (contributed by steve-bate).

Improved support for the HTTP OPTIONS method, allowing sites like https://mastodonlistmanager.org to work.

Fixed non-working content warnings in the public instance timeline.

## 2.53

New user feature to search by post content (using regular expressions) or tag.

Added some (partial) support for `Event` object types.

Minor fixes: Allow unboosting your own posts (contributed by khm), CSS fixes for the Dillo browser (contributed by kvibber).

## 2.52

Posts that were liked or boosted can now be unliked and unboosted.

Outgoing message timeouts are no longer hardcoded and can be configured (see `snac(8)` for more information).

Fixed a bug that caused some incorrect unfollows under special conditions (with shared inboxes enabled and users from the same instance that follow each other, the internal message distributor was confused).

Mastodon API: Added support for lists.

Added a header to avoid over-zealous caching in some browsers (contributed by louis77).

Added support for running and federating inside hidden networks like Tor, I2P or Loki (contributed by iwojima).

Fixed an error processing polls coming from Pleroma instances.

## 2.51

Support for custom Emojis has been added; they are no longer hardcoded, but read from the `emojis.json` file at the server base directory. Also, they are no longer limited to string substitutions, but images as external URLs are also supported (see `snac(8)` for more information).

Fixed a bug that caused some notifications to be lost when coming from a user in the same instance.

Added an additional check for blocked instances (sometimes, posts from blocked sites that were ancestors of legit posts were 'leaking' into the timeline).

On OpenBSD, if the `disable_email_notifications` server flag is set to `true`, `unveil()` is not called for the execution of the `/usr/sbin/sendmail` binary and `pledge()` doesn't set the `exec` promise.

## 2.50

Incoming posts can now be filtered out by content using regular expressions on a server level (these regexes are written in the `filter_reject.txt` file at the server base directory; see `snac(5)` and `snac(8)`).

Improved page position after hitting the `Hide` or `MUTE` buttons (for most cases).

Use a shorter maximum conversation thread level (also, this maximum value is now configurable at compilation level with the `MAX_CONVERSATION_LEVELS` define).

Fixed a bug where editing a post made the attached media or video to be lost.

The way of refreshing remote actor data has been improved.

Posting from the command-line now allows attachments.

Added defines for time to enable MacOS builds (contributed by andypiper).

## 2.49

Mastodon API: Fixed a bug in how validated links are reported.

Mastodon API: Fixed a bug in search by account.

Mastodon API: Fixed missing `Video` type objects in timelines.

Mastodon API: Added search by hashtag.

Some cosmetic fixes to the web interface.

## 2.48

A new instance page, that shows all posts by users in the same instance (like the public instance timeline, but interactive). This will help building communities.

Follower-only replies to unknown users are not shown in timelines.

Added verification of metadata links: if the linked page contains a link back to the snac user with a rel="me" attribute, it's marked as verified.

Added a new server-level configuration parameter: `min_account_age`. If this value (in seconds) is set in `server.json`, any activity coming from accounts that were created newer than that will be discarded. This can be used to mitigate spam.

Added a profile-page relation to links in webfinger responses (contributed by khm).

Fixed some regressions and a crash.

## 2.47

Added pagination to the notification page.

The *New Post...* option now includes an optional field to set the URL of an ActivityPub post to be a reply to.

Fixed spurious notifications from the same user.

Fixed repeated mentions in the reply text field.

One-post only pages include the post content instead of the user bio in their metadata (improving post previews from other software).

Mastodon API: Added support for timelines by tag (for sites like e.g. https://fediwall.social to work).

## 2.46

Added support for Peertube videos.

Mastodon API: Tweaks to support the Subway Tooter app (contributed by pswilde), added support for editing posts, fixed an error related to the edit date of a post, fixed some crashes.

Added a handshake emoji next to a user name if it's a mutual relation (follower and followed), because friendship is bliss.

Tweaked some retry timeout values for better behaviour in larger instances (thanks to me@mysmallinstance.homelinux.org for their help).

## 2.45

Fixed a collision in webfinger caching. This may affect federation with some software, so I recommend an upgrade.

Fixed crashes in some command-line options.

New command-line option `state`, that dumps some information about the running server and the state of each thread (note: this feature uses shared memory blocks and you may need an argument to the `make` call in older Linux distributions; please see the `README` file for details).

Fixed a bug that may leave an inconsistent state for a followed actor in a special case of repeated messages.

Mastodon API: added some fixes for integration with the Mona iOS app (contributed by jamesoff).

Added support for ntfy notifications, both using a self-hosted server or the official ntfy.sh (contributed by Stefano Marinelli).

## 2.44

Fixed a nasty bug that caused the in-memory output queue to be corrupted under heavy traffic loads. This is a good reason to upgrade (thanks to Víctor Moral and Stefano Marinelli for helping me in fixing this).

Shared inboxes are now supported. This is not a user visible feature (hopefully, they will not feel any change), but it will significantly improve traffic for snac instances with many users and will open room for new features that are only feasible with these kind of input channels (this is not enabled by default; see `snac(8)`).

I've refactored all HTML code because it was somewhat of a mess; now it's much more maintainable (at least for me). I think I haven't broken anything.

Fixed crash in a special case of malformed query.

Mastodon API: some tweaks for better integration with more clients, and fixed a crash when processing boosts from kbin.

Fixed crash in the FastCGI code (thanks to Yonle for helping me debug this).

Added apache2 configuration information (contributed by Víctor Moral).

Added FreeBSD and NetBSD setup information and examples (contributed by draga79).

## 2.43

Tags in posts are now indexed and searching by tag is possible. It's still not very useful, but at least new user posts contain links that return real search-by-tag results. Also, no "re-indexing" of the previously stored data is done (only new local and remote posts will be searchable by tag).

Added FastCGI support. This allows for simpler setups (e.g. on #OpenBSD, it's no longer necessary to enable and configure `relayd`, as the native `httpd` daemon includes FastCGI support).

History can be disabled by administrators by setting the `disable_history` field to true.

New command-line option `deluser`, to delete a user (including unfollowing everybody).

Mastodon API: account lookups has been implemented.

Fixed a minor memory leak :facepalm:

Fixed some HTML errors :facepalm:

## 2.42

It's now possible to add profile metadata.

Accounts can be marked as 'private', so that they are not accesible from any non-authorized web UI (i.e. only through the Fediverse).

Outgoing connections that fail with a timeout are retried with a higher timeout limit. But, if the instance keeps timing out, it's penalized by skipping one retry.

If a post comes from a group or community (i.e. it has an `audience` field set), the buttons `Follow Group` or `Unfollow Group` are shown.

Pinned posts are never (incorrectly) purged.

Some RSS validation fixes.

Mastodon API: some tweaks to better match Mastodon behaviour in timeline entries and boosted posts are correctly returned, and some fixes for crashes.

Don't allow creating users which user name strings only differ in case. This was creating some problems (e.g. the webfinger interface doesn't allow case sensitivity).

## 2.41

Added support for `Article` ActivityPub objects to correctly process reviews from #Bookwyrm instances and other similar software.

Show `Link` objects that are image, audio or video media as if they were attachments.

Added more aggressive caching to timelines and history files.

The history at the end of the public page is listed in reverse chronological order.

Mastodon API: minor fixes.

Be more strict when serving note objects.

Additional HTTP response headers can be defined by adding an `http_headers` object with header/content pairs into the `server.json` configuration file.

If you hover the mouse pointer over a vote option in a pool, the current count (as per the last update) is shown. This may be considered cheating in some cases, so try to be honest (or not).

The `nodeinfo` URL now returns more accurate information.

## 2.40

Announces (boosts) can now be disabled/reenabled on a per-people basis (to limit those boost-trigger-happy friends from flooding your timeline). This is operated from the people page.

It's now possible to show an instance timeline instead of the classic greeting static page at the base URL. This can be enabled by setting the `show_instance_timeline` field to `true` in the server configuration file. Other metadata fields can be set to add information to this page; please see `snac(8)` (the Administrator manual page) for details.

Users can now upload an image (preferably in landscape mode) that will be shown as a banner in their public pages.

Added hints to web UI buttons.

Mastodon API: some minor fixes to allow the semaphore.social web client to work.

Fixed miscalculation of the `votersCount` field in multiple-choice polls.

DNS or TLS errors in outgoing connections are considered fatal errors and not retried.

## 2.39

Added support for Follow confirmation messages that only return the follow request id (this fixes following Guppe channels).

Fixed some Gotosocial ActivityPub compatibility (details: support fields like `tag` and `attachment` being single objects instead of arrays).

Fixed ActivityPub outbox (it listed 'Note' objects instead of 'Create' activities).

Show the 'audience' field (channel URL) if a post has one (like pages from lemmy channels and other forums).

Some web UI tweaks: the new post field is hidden by default (wasting less screen space), added a 'back to top' link at the bottom of the page and other minor tuning to the HTML and default CSS (contributed by yonle).

Fixed RSS (contributed by yonle).

Fixed interactive text processes (like instance or user creating) by calling `fflush()` after printing text prompts (it was broken on systems that use musl like Alpine Linux).

## 2.38

More vulnerability fixes (contributed by yonle).

Added support for ActivityPub `Group` and `Page` objects. This allows subscribing to Lemmy channels and interacting with them.

Confirmation messages to follow requests are sent as soon as possible (i.e. bypassing the usual output queue).

Fixed crash when accessing some static or history objects.

## 2.37

Fixed several XSS vulnerabilities (contributed by yonle).

Fixed a bug that prevented working in systemd restricted environments (details: `mkdir()` failed if trying to set the setgid bit).

## 2.36

Added proper HTTP caching when serving static files (attached images, avatars, etc.)

Sensitive content messages can now have a summary.

Added a way to block full instances (from the command-line tool, as I consider this to be an administration priviledge).

If the user style.css does not exist, the server-wide one if served instead.

Added support for pinning user posts. These posts are shown first in the public AND in the private timelines.

Fixed some crashes on badly-formatted input messages.

The image alt-text is also inserted in the 'title' attribute, so it's shown on mouse hover in browsers like Firefox (contributed by Haijo7).

Some improvements to HTML sanitization.

For polls, show the time left before it closes.

Fixed a bug that prevented unfollows to be shown in the notification area.

## 2.35

Fixed broken URL links with the # symbol on them.

Fixed people-being-followed data loss after not logging in for a long time (actor objects were purged too soon).

Fixed bug that made impossible to vote on polls that were replied to.

Don't show 'ghost' no-longer-followers in the people list.

When sanitizing HTML input, unsupported tags are deleted instead of escaped.

Fixed crash on missing headers while checking signatures.

Mastodon API: several bug fixes (contributed by Poesty), improved account object (contributed by Haijo7).

There is new a user configuration setup checkbox to mark an account as a bot.

## 2.34

Polls can now be created from the web interface.

New Mastodon API features: polls are shown and can be voted on.

The user@host identifier is now shown next to the user avatar (contributed by Haijo7). A small tweak to the default CSS was made to suit this change; please consider updating your style.css.

Clicking on an image attachment opens it in a new tab (contributed by Haijo7).

Bots are marked as such using an emoji (contributed by Haijo7).

## 2.33

Polls (in #ActivityPub lingo, Questions) are shown and can be voted on. Creating a poll is not yet implemented, though.

If an URL written in a post links to an image, it's converted to an attachment.

Fixed a bug in the semaphore code that caused total hangs on OpenBSD.

## 2.32

New user configuration switch to drop direct messages from people you don't follow, in order to mitigate spam from Mastodon open registration instances.

When updating user information (e.g. the display name or the bio), the changes are also sent to the people being followed (so they have an updated description about who the user is).

Mastodon API: account search has been implemented, so mention completion works from apps; new support for blocking users (this operation is called MUTE here).

## 2.31

Fixed webfinger and curl issues, which crashed snac while trying to follow Mitra users (contributed by Poesty).

Use named semaphores instead of anonymous ones, to make it work under MacOS (contributed by Saagar Jha).

Fixed semaphore name conflicts (contributed by Poesty).

Fix warning in ugly pointer substraction (contributed by Saagar Jha).

Added user-agent to webfinger queries (contributed by Poesty).

Mastodon API: implemented notification type filters, fixed (partially) the issue with mentions without server.

## 2.30

Fixed a bug that made some notifications to be missed.

New Mastodon API features: the instance public timeline is now a real one, unfavourite / unreblog is supported (somewhat). Some regression bugs regarding image posting were also fixed.

The non-standard `Ping` and `Pong` #ActivityPub activities have been implemented as proposed by @tedu@honk.tedunangst.com in the https://humungus.tedunangst.com/r/honk/v/tip/f/docs/ping.txt document (with a minor diversion: retries are managed in the same way as the rest of #snac messages).

The build process now includes the `-Wextra` flag.

## 2.29

New Mastodon API features: account search, relationships (so the Follow/Unfollow buttons now appear for each account), follow and unfollow accounts, an instance-level timeline (very kludgy), custom emojis for accounts and statuses, many bug fixes (sadly, the Mastodon official app still does not work).

## 2.28

Added a new notification area to the web interface, accessible from a link at the top, that also shows the number of unseen events. This area lists all notifications in reverse chronological order and provides a button to clear all.

More work in the Mastodon API. The new supported features are: notifications, post of new and reply messages (including attached images). Some API v2 entry points had to be implemented, so you'll need to update your HTTPS proxy configuration again, see `snac(8)`. #Tusky no longer crashes, or so I think. The official app and close relatives like #Megalodon still don't work, though.

If you are not interested in this Mastodon API crap, you can compile it out of your #snac by defining the `NO_MASTODON_API` preprocessor directive and forget about it.

Fixed an HTML cache bug (it was not refreshed after editing a post).

## 2.27

Started Mastodon API support, so you can use Mastodon-compatible apps to access #snac accounts. What works so far: login, private and public timelines, full post information (replies and ancestors), liking and boosting posts. Things that don't work yet but eventually will: following accounts, posting and replying to messages (I still have to figure out how some things work, like posting images), notifications (needs some internal support), the instance timeline (snac does not have one, but it can be simulated with not much effort) and probably many other things. Things that will never work: bookmarks, pinning, a federated timeline, many other things that I don't remember right now. Please note that if you want to use this API in your instance, you must add some lines to your HTTP proxy configuration, see the `snac(8)` (administrator documentation) manual page. I'm doing my tests using the #Tusky (which sometimes crashes, surely my fault), #AndStatus, #Fedilab and #Husky Android apps. Success or failure reports will be appreciated.

Fixed some buffer overflows (contributed by Saagar Jha).

Fixed overzealous rejection of some local boosts.

## 2.26

The OpenSSL code has been refactored to avoid using deprecated functions.

Added more aggressive filtering on unwanted `Announce` (boost) messages.

## 2.25

Federation with other instances have been improved by collecting shared inbox information from input messages more thoroughly.

Fixed an obscure bug that caused connection rejections from some instances.

Some rules regarding incoming messages have been tightened; messages that are not related to the user are not added to the timeline. This has to be implemented because some ill-behaving ActivityPub implementations were found injecting unwanted messages to user inboxes.

Messages from MUTEd users are rejected as soon as possible with a 403 Forbidden HTTP status.

Fixed a minor bug regarding the scope of the 'Update' activity (edited posts were sent to more recipients that it should).

More aggressive input sanitization (some posts were found that included strange ASCII control codes).

Added "Open Graph" HTML meta tags for better previsualization of `snac` links from other social media.

## 2.24

Sending non-public messages is now much easier: a checkbox to post a message to only those people mentioned in the message body has been added.

Fixed an over-optimization bug that caused some mentioned recipients to be skipped.

Added some new administrator tweaks: email notifications can be globally disabled.

## 2.23

The user avatar can now be uploaded (instead of given as an URL).

Minor speed improvements int output messages.

Minor improvements in error logging.

## 2.22

Fixed a bug with the Delete button in the web interface: sometimes, instead of the post (as the user intended), the follower was deleted instead :facepalm:

Fixed a bug in the command-line option `follow` (and probably others), that made it fail silently if there was no running server.

Fixed a crash under OpenBSD (a recent change needed a new permission to the `pledge()` call that was forgotten).

## 2.21

Users can now specify an expire time for the entries in their timelines (both their own and others').

Added support for sending notifications (replies, follows, likes, etc.) via Telegram.

Followers can now be deleted (from the *people* page in the web interface). Yes, to stop sending in vain your valuable and acute posts to those accounts that disappeared long ago and flood the log with connection errors.

The internal way of processing connections have been rewritten to be more efficient or, as technical people say, "scalable". This way, `snac` is much faster in processing outgoing connections and less prone to choke on an avalanche of incoming messages. This is a big step towards the secret and real purpose of the creation of this software: being able to host the account of #StephenKing when he finally leaves that other site.

The `note` action from the command-line tool can also accept the post content from the standard input.

## 2.20

Image attachments in posts can now have a description (a.k.a. "alt text").

## 2.19

You can edit your own posts from now on.

Fixed the breakage of Emojis I introduced when implementing HashTags because I am a moron.

Added adaptative timeouts when sending messages to other instances.

## 2.18

Added support for #HashTags (they are not internally indexed yet, only propagated to other instances).

Added support for OpenBSD enhanced security functions `unveil()` and `pledge()` (contributed by alderwick).

The purge ttl for stray global objects has been shortened.

In the HTML interface, don't show the collapse widget for non-existent children.

Added support for HTTP signature pseudo-headers `(created)` and `(expires)`, that are used by some ActivityPub implementations (e.g. Lemmy).

When replying, the mentioned people inherited from the original post will be clearly labelled with a CC: prefix string instead of just being dropped out there like noise like Mastodon and others do. (I hope) this will help you realise that you are involving other people in the conversation.

## 2.17

Fixed a header bug (contributed by alderwick).

Fixed a bug in the Boost by URL option when the URL of the boosted message is not the canonical id for the message (e.g. Mastodon's host/@user/NNN vs. host/users/user/statuses/NNN).

Fixed crash on a corner case regarding failed webfinger requests.

## 2.16

Some outgoing connection tweaks: the protocol is no longer forced to be HTTP/1.1 and timeouts are less restrictive. This has proven useful for some unreachable instances.

Conversations can be collapsed.

Added support for edited posts on input. These updated messages will be marked by two dates (creation and last update).

Some tweaks to the docker configuration to generate a smaller image (contributed by ogarcia).

## 2.15

Fixed bug in message posting that may result in 400 Bad Request errors (contributed by tobyjaffey).

Fixed crash and a deletion error in the unfollow code.

Added configuration files and examples for running snac with docker (contributed by tobyjaffey).

Serve /robots.txt (contributed by kensanata).

## 2.14

Previous posts in the public and private timelines can be reached by a "More..." post at the end (contributed by kensanata).

Clicking the 'Like' and 'Boost' buttons don't move the full conversation up; after that, the page is reloaded to a more precise position. Still not perfect, but on the way.

New command-line operation, `resetpwd`, to reset a user's password to a new, random one.

Added a user setup option to toggle if sensitive content is shown or not by default (contributed by kensanata).

All images are loaded in lazy mode for a snappier feel (contributed by kensanata).

Fixed crash in the data storage upgrade process when debug level >= 2 (contributed by kensanata).

Log message improvements for excelence (contributed by kensanata).

The logging of "new 'Delete'..." messages has been moved to debug level 1, because I'm fed up of seeing my logs swamped with needless cruft.

Don't show the 'Boost' button for private messages.

Added (partial) support for /.well-known/nodeinfo site information. This is not mandatory at all, but if you want to serve it, remember that you need to proxy this address from your web server to the `snac` server.

Some internal structure improvements.

## 2.13

A big disk layout rework, to make it more efficient when timelines get very big. Please take note that you must run `snac upgrade` when you install this version over an already existing one.

Fixed HTML loose close tag (contributed by kensanata).

Fixed bug when closing sendmail pipe (contributed by jpgarcia and themusicgod1).

## 2.12

Fixed some bugs triggered when a GET query does not have an `Accept:` header.

RSS feeds are a bit less ugly.

## 2.11

Marking posts and replies as sensitive content is now possible.

On output, shared inboxes are used on instances that support it. This reduces bandwidth usage greatly, specially for very popular users with thousands of followers.

Added RSS output support for the user posts (by adding .rss to the actor URL or by requesting the actor with an Accept HTTP header of `text/xml` or `application/rss+xml`).

Much more aggresive HTML sanitization.

## 2.10

The local timeline purge has been implemented. The maximum days to live can be configured by setting the field `local_purge_days` in the server configuration file. By default it's 0 (no purging).

Some memory usage fixes.

More formatting fixes.

The only JavaScript snippet has been replaced by pure HTML, so `snac` is now purely JavaScript-free.

## 2.09

New button `Hide`, to hide a post and its children.

You can boost your own posts indefinitely, because Social Media is about repeating yourself until the others care about you.

Fixed bug in the webfinger query (uid queries should no longer fail).

Updated documentation.

## 2.08

A new page showing the list of people being followed and that follows us has been implemented, with all operations associated (including sending Direct Messages).

Messages marked as sensitive are now hidden behind a dropdown.

More aggressive HTML sanitization.

Fixed possible crash when following somebody by its @user@host.

Some fixes to formatting in post creation.

Fixed a small memory leak.

After a like or boost, the scrolling position is set to the next entry in the timeline and not to the top of the page. This is still somewhat confusing so it may change again in the future.

## 2.07

Fixed some minor memory leaks.

Mail notifications are sent through the queue (and retried if failed).

## 2.06

Fixed a nasty bug in newly created users.

The purge is managed internally, so there is no longer a need to add a cron job for that. If you don't want any timeline data to be purged, set `timeline_purge_days` to 0.

The :shortnames: or Emoji or whatever the fuck these things are called are now shown in actor names and post contents.

Added optional email notifications.

## 2.05

Image upload is now supported (one image per post).

Added support for HEAD methods (who knew it was necessary?).

Fixed bug in greeting.html completion (%host% was not being replaced).

Referrers (actors that like or announce posts) are not overwritten.

## 2.04

More multithreading.

Image URLs can also be attached to reply messages.

Improved default mentions in reply text fields.

The static directory now works.

New command line `unfollow`.

## 2.03

Notes can now attach images and other media. The web interface still limits this feature to only one attachment (given by URL, so the file must have been uploaded elsewhere).

Videos attached to notes are now shown.

A small set of ASCII emoticons are translated to emojis.

The new (optional) server configuration directive, `disable_cache`, disables the caching of timeline HTML output if set to `true` (useful only for debugging, don't use it otherwise).

## 2.02

Fixed a bug that caused empty actor names look like crap.

Fixed a severe bug in number parsing and storage.

Children entries are not indented further than 4 levels, so that fucking Twitter-like threads are readable.

Added some asserts for out-of-memory situations.

The publication timestamp only shows the date, so timezone configuration and conversion is no longer an issue.

The reply textareas are pre-filled with the user ids mentioned in the message.

Fixed bug in the web command `Boost (by URL)`.

New command-line option `purge`.

Fixed a null-termination bug in Basic Authentication parsing.

Updated documentation.

New systemd and OpenBSD startup script examples in the examples/ directory.

## 2.01

This is the first public release of the 2.x branch.
