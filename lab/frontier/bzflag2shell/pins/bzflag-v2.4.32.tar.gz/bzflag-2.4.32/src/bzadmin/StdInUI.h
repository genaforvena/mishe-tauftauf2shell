/* bzflag
 * Copyright (c) 1993-2026 Tim Riker
 *
 * This package is free software;  you can redistribute it and/or
 * modify it under the terms of the license found in the file
 * named COPYING that should have accompanied this file.
 *
 * THIS PACKAGE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef STDINUI_H
#define STDINUI_H

// Inherits from
#include "BZAdminUI.h"

/* system interface headers */
#include <string>

/* common interface headers */
#include "Address.h"
#include "global.h"

// Local headers
#include "UIMap.h"


/** This class is an interface for bzadmin that reads commands from stdin. */
class StdInUI final : public BZAdminUI
{
public:

    StdInUI(BZAdminClient& c);

    bool checkCommand(std::string& str) override;

    /** This function returns a pointer to a dynamically allocated
        StdInUI object. */
    static BZAdminUI* creator(BZAdminClient&);

protected:

    static UIAdder uiAdder;
};

#endif

// Local Variables: ***
// mode: C++ ***
// tab-width: 4 ***
// c-basic-offset: 4 ***
// indent-tabs-mode: nil ***
// End: ***
// ex: shiftwidth=4 tabstop=4
