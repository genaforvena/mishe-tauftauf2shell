/* bzflag
 * Copyright (c) 1993-2026 Tim Riker
 *
 * This package is free software;  you can redistribute it and/or
 * modify it under the terms of the license found in the file
 * named COPYING that should have accompanied this file.
 *
 * THIS PACKAGE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

/* ZSceneDatabase:
 *  Database of geometry to render using Z-buffer algorithm
 */

#ifndef BZF_Z_SCENE_DATABASE_H
#define BZF_Z_SCENE_DATABASE_H

// Inherits from
#include "SceneDatabase.h"

class ZSceneDatabase final : public SceneDatabase
{
    friend class ZSceneIterator;
public:
    ZSceneDatabase();
    ~ZSceneDatabase();

    // returns true if the node would have been deleted
    bool        addStaticNode(SceneNode*, bool dontFree) override;
    void        addDynamicNode(SceneNode*) override;
    void        addDynamicSphere(SphereSceneNode*) override;
    void        finalizeStatics() override;
    void        removeDynamicNodes() override;
    void        removeAllNodes() override;
    bool        isOrdered() override;

    void        updateNodeStyles() override;
    void        addLights(SceneRenderer& renderer) override;
    void        addShadowNodes(SceneRenderer &renderer) override;
    void        addRenderNodes(SceneRenderer& renderer) override;
    void        renderRadarNodes(const ViewFrustum&) override;

    void        drawCuller() override;
    void        setOccluderManager(int) override;

    const Extents*  getVisualExtents() const override;

private:
    void        setupCullList();
    void        makeCuller();

private:
    int         staticCount;
    int         staticSize;
    SceneNode**     staticList;

    int         dynamicCount;
    int         dynamicSize;
    SceneNode**     dynamicList;

    int         culledCount;
    SceneNode**  culledList;

    class Octree*       octree;
    int         cullDepth;
    int         cullElements;

};


#endif // BZF_Z_SCENE_DATABASE_H

// Local Variables: ***
// mode: C++ ***
// tab-width: 4 ***
// c-basic-offset: 4 ***
// indent-tabs-mode: nil ***
// End: ***
// ex: shiftwidth=4 tabstop=4
