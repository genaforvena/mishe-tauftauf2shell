/* bzflag
 * Copyright (c) 1993-2025 Tim Riker
 *
 * This package is free software;  you can redistribute it and/or
 * modify it under the terms of the license found in the file
 * named COPYING that should have accompanied this file.
 *
 * THIS PACKAGE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef BZF_BZFLAG_H
#define BZF_BZFLAG_H

#include "common.h"

// system includes
#include <string>

extern void dumpResources();

extern bool echoToConsole;
extern bool echoAnsi;
extern std::string alternateConfig;
extern const char *argv0;
extern struct tm   userTime;

#ifdef ROBOT
extern int numRobotTanks;
#endif

#endif // BZF_BZFLAG_H

// Local Variables: ***
// mode: C++ ***
// tab-width: 4 ***
// c-basic-offset: 4 ***
// indent-tabs-mode: nil ***
// End: ***
// ex: shiftwidth=4 tabstop=4
