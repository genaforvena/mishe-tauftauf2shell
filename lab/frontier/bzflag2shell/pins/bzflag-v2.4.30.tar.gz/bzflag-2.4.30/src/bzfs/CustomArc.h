/* bzflag
 * Copyright (c) 1993-2025 Tim Riker
 *
 * This package is free software;  you can redistribute it and/or
 * modify it under the terms of the license found in the file
 * named COPYING that should have accompanied this file.
 *
 * THIS PACKAGE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef __CUSTOM_ARC_H__
#define __CUSTOM_ARC_H__

/* interface header */
#include "WorldFileObstacle.h"

/* common interface headers */
#include "BzMaterial.h"

/* local interface headers */
#include "WorldInfo.h"


class CustomArc : public WorldFileObstacle
{
public:
    CustomArc(bool boxStyle);
    ~CustomArc();
    bool read(const char* cmd, std::istream& input) override;
    void writeToGroupDef(GroupDefinition*) override;

private:
    void makePie(bool isCircle, float angle, float rot, float height,
                 float radius, float squish, float texsz[4],
                 WorldInfo* world) const;
    void makeRing(bool isCircle, float angle, float rot, float height,
                  float inrad, float outrad, float squish, float texsz[4],
                  WorldInfo* world) const;
    enum
    {
        Top,
        Bottom,
        Inside,
        Outside,
        StartFace,
        EndFace,
        MaterialCount
    };
    static const char* sideNames[MaterialCount];

    bool boxStyle;
    int divisions;
    float angle;
    float ratio;
    float texsize[4];
    int phydrv;
    bool useNormals;
    bool smoothBounce;
    BzMaterial materials[MaterialCount];
};


#endif  /* __CUSTOM_ARC_H__ */

// Local variables: ***
// mode: C++ ***
// tab-width: 4***
// c-basic-offset: 4 ***
// indent-tabs-mode: nil ***
// End: ***
// ex: shiftwidth=4 tabstop=4
