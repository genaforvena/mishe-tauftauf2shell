/* bzflag
 * Copyright (c) 1993-2025 Tim Riker
 *
 * This package is free software;  you can redistribute it and/or
 * modify it under the terms of the license found in the file
 * named COPYING that should have accompanied this file.
 *
 * THIS PACKAGE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef PLAYERINFO_H
#define PLAYERINFO_H

// 1st
#include "common.h"

// System headers
#include <map>

// Common headers
#include "Address.h"
#include "global.h"


/** This struct stores information about a player that is relevant to
    bzadmin. */
struct PlayerInfo
{
    PlayerInfo(): wins(), losses(), tks(),
        isRegistered(), isVerified(), isAdmin() {}
    PlayerInfo(const std::string& n) : name(n),
        wins(), losses(), tks(), isRegistered(),
        isVerified(), isAdmin() {}
    std::string name;
    std::string ip;
    TeamColor team;
    int wins;
    int losses;
    int tks;
    bool isRegistered;
    bool isVerified;
    bool isAdmin;
};


typedef std::map<PlayerId, PlayerInfo> PlayerIdMap;


#endif

// Local Variables: ***
// mode: C++ ***
// tab-width: 4 ***
// c-basic-offset: 4 ***
// indent-tabs-mode: nil ***
// End: ***
// ex: shiftwidth=4 tabstop=4
