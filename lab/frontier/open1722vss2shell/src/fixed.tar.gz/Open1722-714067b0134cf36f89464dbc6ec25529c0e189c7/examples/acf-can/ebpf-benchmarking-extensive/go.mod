module open1722-can-tracing-extensive

go 1.25.0

require (
	github.com/bsipos/thist v1.0.0
	github.com/cilium/ebpf v0.22.0
)

require (
	github.com/ajstarks/svgo v0.0.0-20180226025133-644b8db467af // indirect
	github.com/fogleman/gg v1.2.1-0.20190220221249-0403632d5b90 // indirect
	github.com/golang/freetype v0.0.0-20170609003504-e2365dfdc4a0 // indirect
	github.com/jung-kurt/gofpdf v1.0.3-0.20190309125859-24315acbbda5 // indirect
	golang.org/x/crypto v0.52.0 // indirect
	golang.org/x/image v0.41.0 // indirect
	golang.org/x/sys v0.45.0 // indirect
	golang.org/x/term v0.43.0 // indirect
	gonum.org/v1/plot v0.0.0-20190515093506-e2840ee46a6b // indirect
)
