/*
 * Copyright (c) 2024, COVESA
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of COVESA nor the names of its contributors may be
 *      used to endorse or promote products derived from this software without
 *      specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifdef __linux__
#include <linux/if_packet.h>
#include <arpa/inet.h>
#include <linux/if.h>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <sys/ioctl.h>
#elif defined(__ZEPHYR__)
#include <zephyr/kernel.h>
#include <zephyr/posix/sys/socket.h>
#include <zephyr/net/socketcan.h>
#include <zephyr/net/socketcan_utils.h>
#include <zephyr/net/ethernet.h>

#include <zephyr/logging/log.h>
LOG_MODULE_REGISTER(acf_can_common, LOG_LEVEL_DBG);
#endif

#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include <stdbool.h>
#include <inttypes.h>

#include "avtp/Udp.h"
#include "avtp/CommonHeader.h"
#include "avtp/acf/Ntscf.h"
#include "avtp/acf/Tscf.h"
#include "acf-can-common.h"

#ifdef __linux__
// Define LOG macros for Linux
#ifndef LOG_ERR
#define LOG_ERR(...) fprintf(stderr, "[ERROR]" __VA_ARGS__)
#endif

#ifndef LOG_DBG
#define LOG_DBG(...) fprintf(stderr, "[DEBUG]" __VA_ARGS__)
#endif

#ifndef LOG_INF
#define LOG_INF(...) fprintf(stderr, "[INFO]" __VA_ARGS__)
#endif

#endif

#ifdef __ZEPHYR__
typedef uint32_t canid_t;
#endif

#ifdef __linux__
int setup_can_socket(const char *can_ifname, bool can_fd)
{

    int can_socket, res;
    struct sockaddr_can can_addr;

    can_socket = socket(AF_CAN, SOCK_RAW, CAN_RAW);
    if (can_socket < 0) {
        perror("Failed to create CAN socket");
        return can_socket;
    }

    // Get the CAN address to bind the socket to.
    memset(&can_addr, 0, sizeof(can_addr));

    struct ifreq ifr;
    strcpy(ifr.ifr_name, can_ifname);
    ioctl(can_socket, SIOCGIFINDEX, &ifr);
    can_addr.can_family = AF_CAN;
    can_addr.can_ifindex = ifr.ifr_ifindex;

    if (can_fd) {
        int enable_canfx = 1;
        setsockopt(can_socket, SOL_CAN_RAW, CAN_RAW_FD_FRAMES, &enable_canfx, sizeof(enable_canfx));
    }

    res = bind(can_socket, (struct sockaddr *)&can_addr, sizeof(can_addr));
    if (res < 0) {
        perror("Failed to bind CAN socket");
        close(can_socket);
        return res;
    }

    return can_socket;
}
#endif

static int init_cf_pdu(uint8_t *pdu, uint64_t stream_id, acf_can_cf_t cf, uint32_t seq_num)
{
    if (cf == ACF_CAN_CF_NTSCF_V1) {
        Avtp_NtscfV1_t *ntscf = (Avtp_NtscfV1_t *)pdu;
        Avtp_Ntscf_InitV1(ntscf);
        Avtp_Ntscf_SetSequenceNum_V1(ntscf, seq_num);
        Avtp_Ntscf_SetStreamId_V1(ntscf, stream_id);
        return (int)Avtp_Ntscf_GetHeaderLen_V1(ntscf);
    }

    if (cf == ACF_CAN_CF_NTSCF_V0) {
        Avtp_Ntscf_t *ntscf = (Avtp_Ntscf_t *)pdu;
        Avtp_Ntscf_InitV0(ntscf);
        Avtp_Ntscf_SetSequenceNum_V0(ntscf, seq_num);
        Avtp_Ntscf_SetStreamId_V0(ntscf, stream_id);
        return (int)Avtp_Ntscf_GetHeaderLen_V0(ntscf);
    }

    if (cf == ACF_CAN_CF_TSCF_V1) {
        Avtp_TscfV1_t *tscf = (Avtp_TscfV1_t *)pdu;
        Avtp_Tscf_InitV1(tscf);
        Avtp_Tscf_SetTu_V1(tscf, false);
        Avtp_Tscf_SetSequenceNum_V1(tscf, seq_num);
        Avtp_Tscf_SetStreamId_V1(tscf, stream_id);
        return (int)Avtp_Tscf_GetHeaderLen_V1(tscf);
    }

    Avtp_Tscf_t *tscf = (Avtp_Tscf_t *)pdu;
    Avtp_Tscf_InitV0(tscf);
    Avtp_Tscf_SetTu_V0(tscf, false);
    Avtp_Tscf_SetSequenceNum_V0(tscf, seq_num);
    Avtp_Tscf_SetStreamId_V0(tscf, stream_id);
    return (int)Avtp_Tscf_GetHeaderLen_V0(tscf);
}

static int update_cf_length(uint8_t *cf_pdu, uint64_t length, acf_can_cf_t cf)
{
    if (cf == ACF_CAN_CF_NTSCF_V1) {
        Avtp_NtscfV1_t *ntscf = (Avtp_NtscfV1_t *)cf_pdu;
        uint64_t payloadLen = length - Avtp_Ntscf_GetHeaderLen_V1(ntscf);
        Avtp_Ntscf_SetNtscfDataLength_V1(ntscf, (uint16_t)payloadLen);
    } else if (cf == ACF_CAN_CF_NTSCF_V0) {
        Avtp_Ntscf_t *ntscf = (Avtp_Ntscf_t *)cf_pdu;
        uint64_t payloadLen = length - Avtp_Ntscf_GetHeaderLen_V0(ntscf);
        Avtp_Ntscf_SetNtscfDataLength_V0(ntscf, (uint16_t)payloadLen);
    } else if (cf == ACF_CAN_CF_TSCF_V1) {
        Avtp_TscfV1_t *tscf = (Avtp_TscfV1_t *)cf_pdu;
        uint64_t payloadLen = length - Avtp_Tscf_GetHeaderLen_V1(tscf);
        Avtp_Tscf_SetStreamDataLength_V1(tscf, (uint16_t)payloadLen);
    } else {
        Avtp_Tscf_t *tscf = (Avtp_Tscf_t *)cf_pdu;
        uint64_t payloadLen = length - Avtp_Tscf_GetHeaderLen_V0(tscf);
        Avtp_Tscf_SetStreamDataLength_V0(tscf, (uint16_t)payloadLen);
    }
    return 0;
}

static int prepare_acf_packet(uint8_t *acf_pdu, frame_t *frame, bool can_fd)
{

    canid_t can_id;
    uint8_t can_payload_length;

    AVTP_CAN(t) *pdu = (AVTP_CAN(t) *)acf_pdu;

    // Set required CAN Flags
#ifdef __linux__
    can_id = can_fd ? (*frame).fd.can_id : (*frame).cc.can_id;
    can_payload_length = can_fd ? (*frame).fd.len : (*frame).cc.len;
#elif defined(__ZEPHYR__)
    can_id = can_fd ? (*frame).fd.id : (*frame).cc.id;
    can_payload_length = can_fd ? (*frame).fd.dlc : (*frame).cc.dlc;
#endif

    // Build the ACF CAN PDU (initializes the header, copies the payload and
    // finalizes the length/pad fields)
    if (can_fd)
        AVTP_CAN(CreateAcfMessage)
    (pdu, can_id & CAN_EFF_MASK, frame->fd.data, can_payload_length, can_fd);
    else AVTP_CAN(CreateAcfMessage)(pdu, can_id & CAN_EFF_MASK, frame->cc.data, can_payload_length,
                                    can_fd);

#if (AVTP_CAN_API == AVTP_CAN_API_CANV2) || (AVTP_CAN_API == AVTP_CAN_API_CAN)
    // Set optional header fields after building the frame
    struct timespec now;
    clock_gettime(CLOCK_REALTIME, &now);
    AVTP_CAN(SetMessageTimestamp)(pdu, (uint64_t)now.tv_nsec + (uint64_t)(now.tv_sec * 1e9));
    AVTP_CAN(SetMtv)(pdu, true);
#endif
    if (can_id & CAN_RTR_FLAG) {
        AVTP_CAN(SetRtr)(pdu, true);
    }

    if (can_fd) {
        if (frame->fd.flags & CANFD_BRS) {
            AVTP_CAN(SetBrs)(pdu, true);
        }
        if (frame->fd.flags & CANFD_FDF) {
            AVTP_CAN(SetFdf)(pdu, true);
        }
        if (frame->fd.flags & CANFD_ESI) {
            AVTP_CAN(SetEsi)(pdu, true);
        }
    }

    return Avtp_AcfCommon_GetAcfMsgLengthInBytes((Avtp_AcfCommon_t *)pdu);
}

int can_to_avtp(frame_t *can_frames, bool can_fd, uint8_t *pdu, int use_udp, acf_can_cf_t cf,
                uint64_t stream_id, uint8_t num_acf_msgs, uint32_t cf_seq_num, uint32_t udp_seq_num)
{

    // Pack into control formats
    uint8_t *cf_pdu;
    uint16_t pdu_length = 0, cf_length = 0;
    int res;

    // Usage of UDP means the PDU needs an encapsulation
    if (use_udp) {
        Avtp_Udp_t *udp_pdu = (Avtp_Udp_t *)pdu;
        Avtp_Udp_SetEncapsulationSeqNo(udp_pdu, udp_seq_num);
        pdu_length += sizeof(Avtp_Udp_t);
    }

    // Prepare the control format: TSCF/NTSCF
    cf_pdu = pdu + pdu_length;
    res = init_cf_pdu(cf_pdu, stream_id, cf, cf_seq_num);
    pdu_length += res;
    cf_length += res;

    int i = 0;
    while (i < num_acf_msgs) {
        uint8_t *acf_pdu = pdu + pdu_length;
        res = prepare_acf_packet(acf_pdu, &(can_frames[i]), can_fd);
        pdu_length += res;
        cf_length += res;
        i++;
    }

    // Update the length of the PDU
    update_cf_length(cf_pdu, cf_length, cf);

    return pdu_length;
}

int avtp_to_can(uint8_t *pdu, size_t pdu_length, frame_t *can_frames, bool can_fd, int use_udp,
                uint64_t stream_id, uint32_t *exp_cf_seqnum, uint32_t *exp_udp_seqnum)
{

    uint8_t *cf_pdu, *acf_pdu, *udp_pdu, i = 0;
    uint32_t seq_num;
    uint32_t udp_seq_num;
    uint32_t seq_mask = UINT32_MAX;
    uint16_t proc_bytes = 0, msg_length = 0;
    uint64_t s_id;

    // Check for UDP encapsulation
    if (use_udp) {
        if (pdu_length < AVTP_UDP_HEADER_LEN) {
            LOG_ERR("Truncated UDP encapsulated frame, ignoring frame.\n");
            return -1;
        }
        udp_pdu = pdu;
        udp_seq_num = Avtp_Udp_GetEncapsulationSeqNo((Avtp_Udp_t *)udp_pdu);
        cf_pdu = pdu + AVTP_UDP_HEADER_LEN;
        proc_bytes += AVTP_UDP_HEADER_LEN;
        msg_length += AVTP_UDP_HEADER_LEN;
        if (udp_seq_num != *exp_udp_seqnum) {
            LOG_ERR("Incorrect UDP sequence num. Expected: %" PRIu32 " Recd.: %" PRIu32 "\n",
                    *exp_udp_seqnum, udp_seq_num);
            *exp_udp_seqnum = udp_seq_num;
        }
    } else {
        cf_pdu = pdu;
    }

    /* The subtype is encoded in the first octet and the version in the
     * second one. Both must have been received before the control format can
     * be identified and validated below. */
    if (pdu_length - proc_bytes < 2) {
        LOG_ERR("Truncated AVTP frame, ignoring frame.\n");
        return -1;
    }

    // Only NTSCF and TSCF formats allowed
    uint8_t subtype = Avtp_CommonHeader_GetSubtype((Avtp_CommonHeader_t *)cf_pdu);
    if (subtype == AVTP_SUBTYPE_TSCF) {
        /* Validate the untrusted header against the number of bytes actually
         * received: this checks the subtype and version, that the declared
         * header fits, and that the declared stream data length fits. */
        if (!Avtp_Tscf_IsValid((const Avtp_Tscf_t *)cf_pdu, pdu_length - proc_bytes)) {
            LOG_ERR("Invalid TSCF header, ignoring frame.\n");
            return -1;
        }
        uint8_t version =
            Avtp_CommonStreamHeader_GetVersion((const Avtp_CommonStreamHeader_t *)cf_pdu);
        if (!Avtp_AvtpduVersion_IsSupported(AVTP_TSCF_SUPPORTED_VERSIONS, version)) {
            LOG_ERR("Unsupported TSCF version %u, ignoring frame.\n", version);
            return -1;
        }
        if (version == AVTPDU_VERSION_1) {
            const Avtp_TscfV1_t *tscf = (const Avtp_TscfV1_t *)cf_pdu;
            size_t headerLen = Avtp_Tscf_GetHeaderLen_V1(tscf);
            proc_bytes += (uint16_t)headerLen;
            msg_length += (uint16_t)(Avtp_Tscf_GetStreamDataLength_V1(tscf) + headerLen);
            s_id = Avtp_Tscf_GetStreamId_V1(tscf);
            seq_num = Avtp_Tscf_GetSequenceNum_V1(tscf);
        } else {
            const Avtp_Tscf_t *tscf = (const Avtp_Tscf_t *)cf_pdu;
            size_t headerLen = Avtp_Tscf_GetHeaderLen_V0(tscf);
            proc_bytes += (uint16_t)headerLen;
            msg_length += (uint16_t)(Avtp_Tscf_GetStreamDataLength_V0(tscf) + headerLen);
            s_id = Avtp_Tscf_GetStreamId_V0(tscf);
            seq_num = Avtp_Tscf_GetSequenceNum_V0(tscf);
            seq_mask = 0xFFU;
        }
    } else if (subtype == AVTP_SUBTYPE_NTSCF) {
        if (!Avtp_Ntscf_IsValid((const Avtp_Ntscf_t *)cf_pdu, pdu_length - proc_bytes)) {
            LOG_ERR("Invalid NTSCF header, ignoring frame.\n");
            return -1;
        }
        uint8_t version =
            Avtp_AlternativeHeader_GetVersion((const Avtp_AlternativeHeader_t *)cf_pdu);
        if (!Avtp_AvtpduVersion_IsSupported(AVTP_NTSCF_SUPPORTED_VERSIONS, version)) {
            LOG_ERR("Unsupported NTSCF version %u, ignoring frame.\n", version);
            return -1;
        }
        if (version == AVTPDU_VERSION_1) {
            const Avtp_NtscfV1_t *ntscf = (const Avtp_NtscfV1_t *)cf_pdu;
            size_t headerLen = Avtp_Ntscf_GetHeaderLen_V1(ntscf);
            proc_bytes += (uint16_t)headerLen;
            msg_length += (uint16_t)(Avtp_Ntscf_GetNtscfDataLength_V1(ntscf) + headerLen);
            s_id = Avtp_Ntscf_GetStreamId_V1(ntscf);
            seq_num = Avtp_Ntscf_GetSequenceNum_V1(ntscf);
        } else {
            const Avtp_Ntscf_t *ntscf = (const Avtp_Ntscf_t *)cf_pdu;
            size_t headerLen = Avtp_Ntscf_GetHeaderLen_V0(ntscf);
            proc_bytes += (uint16_t)headerLen;
            msg_length += (uint16_t)(Avtp_Ntscf_GetNtscfDataLength_V0(ntscf) + headerLen);
            s_id = Avtp_Ntscf_GetStreamId_V0(ntscf);
            seq_num = Avtp_Ntscf_GetSequenceNum_V0(ntscf);
            seq_mask = 0xFFU;
        }
    } else {
        return -1;
    }

    // Check for stream id
    if (s_id != stream_id) {
        return -1;
    }

    // Check sequence numbers. Version 0 only carries an 8-bit sequence
    // number, so compare modulo 256 there; version 1 uses the full 32 bits.
    uint32_t expected_seq_num = *exp_cf_seqnum & seq_mask;
    if ((seq_num & seq_mask) != expected_seq_num) {
        LOG_ERR("Incorrect sequence num. Expected: %" PRIu32 " Recd.: %" PRIu32 "\n",
                expected_seq_num, seq_num);
        *exp_cf_seqnum = seq_num;
    }

    while (proc_bytes < msg_length) {

        acf_pdu = &pdu[proc_bytes];

        /* Verify the CAN-specific invariants now that the ACF message
         * type is confirmed: the encoded message length must fit the
         * remaining buffer, and the resulting payload size must match
         * the CAN/CAN-FD bound encoded by the FDF bit. Without this
         * guard a malformed frame could feed garbage values to the
         * consumers below. The control format header was validated
         * against the received byte count above, so msg_length can never
         * exceed the received frame. */
        if (!AVTP_CAN(IsValid)((AVTP_CAN(t) *)acf_pdu, msg_length - proc_bytes)) {
            LOG_ERR("Error: ACF CAN frame failed validation, ignoring frame.\n");
            return -1;
        }

        canid_t can_id = AVTP_CAN(GetCanIdentifier)((AVTP_CAN(t) *)acf_pdu);
        const uint8_t *can_payload = AVTP_CAN(GetPayload)((AVTP_CAN(t) *)acf_pdu);
        uint16_t acf_msg_length =
            Avtp_AcfCommon_GetAcfMsgLengthInBytes((Avtp_AcfCommon_t *)acf_pdu);
        uint16_t can_payload_length = AVTP_CAN(GetPayloadLength)((AVTP_CAN(t) *)acf_pdu);
        proc_bytes += acf_msg_length;

        if (i >= MAX_CAN_FRAMES_IN_ACF) {
            LOG_ERR("Error: Number of CAN frames in ACF exceeds maximum allowed.\n");
            return -1;
        }
        frame_t *frame = &(can_frames[i]);

        /* The frame array is reused across AVTPDUs and the flag handling
         * below only ever sets bits, so clear the slot first. Otherwise
         * FDF, BRS, or ESI left over from an earlier frame in the same
         * slot would leak onto a later classic frame that never set them. */
        memset(frame, 0, sizeof(*frame));

        // Handle EFF Flag
        if (AVTP_CAN(IsEff)((AVTP_CAN(t) *)acf_pdu)) {
            can_id |= CAN_EFF_FLAG;
        } else if (can_id > 0x7FF) {
            LOG_ERR("Error: CAN ID is > 0x7FF but the EFF bit is not set.\n");
            return -1;
        }

        // Handle RTR Flag
        if (AVTP_CAN(IsRtr)((AVTP_CAN(t) *)acf_pdu)) {
            can_id |= CAN_RTR_FLAG;
        }

        if (can_fd) {
            if (AVTP_CAN(IsBrs)((AVTP_CAN(t) *)acf_pdu)) {
                frame->fd.flags |= CANFD_BRS;
            }
            if (AVTP_CAN(IsFdf)((AVTP_CAN(t) *)acf_pdu)) {
                frame->fd.flags |= CANFD_FDF;
            }
            if (AVTP_CAN(IsEsi)((AVTP_CAN(t) *)acf_pdu)) {
                frame->fd.flags |= CANFD_ESI;
            }
#ifdef __linux__
            frame->fd.can_id = can_id;
            frame->fd.len = can_payload_length;
#elif defined(__ZEPHYR__)
            frame->fd.id = can_id;
            frame->fd.dlc = can_payload_length;
#endif
            memcpy(frame->fd.data, can_payload, can_payload_length);
        } else {
#ifdef __linux__
            frame->cc.can_id = can_id;
            frame->cc.len = can_payload_length;
#elif defined(__ZEPHYR__)
            frame->cc.id = can_id;
            frame->cc.dlc = can_payload_length;
#endif
            memcpy(frame->cc.data, can_payload, can_payload_length);
        }

        i++;
    }

    return i;
}
