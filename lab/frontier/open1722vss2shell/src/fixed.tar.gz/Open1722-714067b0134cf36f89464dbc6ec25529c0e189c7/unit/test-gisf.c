/*
 * Copyright (c) 2026, COVESA
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of COVESA nor the names of its contributors may be
 *      used to endorse or promote products derived from this software without
 *      specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifdef __cplusplus
extern "C" {
#endif

#include "avtp/acf/Gisf.h"
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <stdio.h>

static void Test_Gisf_Init(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;

    // Check init function while passing in a null pointer
    Avtp_Gisf_Init(NULL);

    Avtp_Gisf_Init(gisf);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};

    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_GetPad(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x06, 0xC0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetPad(gisf), 3);
}

static void Test_Gisf_IsMtv(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_IsMtv(gisf), true);
}

static void Test_Gisf_GetImageSensorId(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x5, 0xFF, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetImageSensorId(gisf), 0x5FF);
}

static void Test_Gisf_GetMessageTimestamp(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0, 0x0, 0xBF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
        0x0,  0x0,  0x0, 0x0, 0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetMessageTimestamp(gisf), 0xBFFFFFFFFFFFFFFFull);
}

static void Test_Gisf_IsEl(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x40, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_IsEl(gisf), true);
}

static void Test_Gisf_IsTl(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_IsTl(gisf), true);
}

static void Test_Gisf_IsEf(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_IsEf(gisf), true);
}

static void Test_Gisf_GetEvt(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0xB, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetEvt(gisf), 0xB);
}

static void Test_Gisf_IsBf(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_IsBf(gisf), true);
}

static void Test_Gisf_GetLineTypeId(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0, 0x17, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetLineTypeId(gisf), 0x17);
}

static void Test_Gisf_GetEvt2(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0, 0x0, 0xBF, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetEvt2(gisf), 0xBF);
}

static void Test_Gisf_GetISeqNum(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0, 0x0, 0x0, 0xBF, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetISeqNum(gisf), 0xBF);
}

static void Test_Gisf_GetLineNumber(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x05, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0,  0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0, 0x0, 0x0, 0x0, 0xBF, 0xFF, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetLineNumber(gisf), 0xBFFFul);
}

static void Test_Gisf_GetPayloadLength(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x06, 0xC0, 0x0, 0x0, 0x0, 0x0,  0x0,  0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0,  0x0, 0x0, 0x0, 0xBF, 0xFF, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetPayloadLength(gisf), 1);
}

static void Test_Gisf_GetPayloadLength_NoPadding(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {
        0x18, 0x06, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0,  0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0, 0x0, 0x0, 0x0, 0xBF, 0xFF, 0x0, 0x0, 0x0, 0x0,
    };
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    assert_int_equal(Avtp_Gisf_GetPayloadLength(gisf), 4);
}

static void Test_Gisf_SetMtv(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetMtv(gisf, true);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetImageSensorId(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetImageSensorId(gisf, 0x5FF);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x5, 0xFF, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetMessageTimestamp(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetMessageTimestamp(gisf, 0xBFFFFFFFFFFFFFFFull);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0,  0x0,  0xBF, 0xFF, 0xFF, 0xFF,
                                     0xFF, 0xFF, 0xFF, 0xFF, 0x0,  0x0,  0x0,  0x0,
                                     0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0};

    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetEl(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetEl(gisf, true);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x40, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetTl(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetTl(gisf, true);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetEf(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetEf(gisf, true);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetEvt(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetEvt(gisf, 0xB);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0xB, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetBf(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetBf(gisf, true);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x0, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetLineTypeId(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetLineTypeId(gisf, 0x17);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x0, 0x17, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetEvt2(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetEvt2(gisf, 0xBF);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x0, 0x0, 0xBF, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetISeqNum(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetISeqNum(gisf, 0xBF);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x0, 0x0, 0x0, 0xBF, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetLineNumber(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetLineNumber(gisf, 0xBFFF);

    uint8_t expected_msg[msg_len] = {0x18, 0x00, 0x0,  0x0,  0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0x0,  0x0,  0x0, 0x0, 0x0, 0x0,
                                     0x0,  0x0,  0xBF, 0xFF, 0x0, 0x0, 0x0, 0x0};
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetPayloadLength(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetPayloadLength(gisf, 3);

    uint8_t expected_msg[msg_len] = {
        0x18, 0x06, 0x40, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_SetPayloadLength_NoPadding(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 4;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetPayloadLength(gisf, 4);

    uint8_t expected_msg[msg_len] = {
        0x18, 0x06, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        0x0,  0x0,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
    };
    assert_memory_equal(msg, expected_msg, msg_len);
}

static void Test_Gisf_Payload(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 8;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    uint8_t payload[8] = {0, 1, 2, 3, 4, 5, 6, 7};

    Avtp_Gisf_Init(gisf);
    Avtp_Gisf_SetPayload(gisf, payload, sizeof(payload));

    assert_ptr_equal(Avtp_Gisf_GetPayload(gisf), msg + AVTP_GISF_HEADER_LEN);
    assert_memory_equal(payload, Avtp_Gisf_GetPayload(gisf), sizeof(payload));
}

static void Test_Gisf_CreateAcfMessage(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 8;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    uint8_t payload[8] = {0, 1, 2, 3, 4, 5, 6, 7};

    Avtp_Gisf_CreateAcfMessage(gisf, 0x5FF, payload, sizeof(payload));

    assert_int_equal(Avtp_AcfCommon_GetAcfMsgType((Avtp_AcfCommon_t *)gisf), AVTP_ACF_TYPE_GISF);
    assert_int_equal(Avtp_Gisf_GetImageSensorId(gisf), 0x5FF);
    assert_memory_equal(payload, msg + AVTP_GISF_HEADER_LEN, sizeof(payload));
    assert_int_equal(Avtp_Gisf_GetPayloadLength(gisf), 8);
    assert_int_equal(Avtp_Gisf_IsValid(gisf, msg_len), 1);
}

static void Test_Gisf_CreateFromGarbage(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 8;
    uint8_t msg[msg_len];
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    uint8_t payload[8] = {0, 1, 2, 3, 4, 5, 6, 7};

    // CreateAcfMessage must fully initialize the header even on garbage input.
    memset(msg, 0xAA, msg_len);
    Avtp_Gisf_CreateAcfMessage(gisf, 0x5FF, payload, sizeof(payload));

    assert_int_equal(Avtp_AcfCommon_GetAcfMsgType((Avtp_AcfCommon_t *)gisf), AVTP_ACF_TYPE_GISF);
    assert_int_equal(Avtp_Gisf_IsMtv(gisf), false);
    assert_int_equal(Avtp_Gisf_IsEl(gisf), false);
    assert_int_equal(Avtp_Gisf_IsTl(gisf), false);
    assert_int_equal(Avtp_Gisf_IsEf(gisf), false);
    assert_int_equal(Avtp_Gisf_IsBf(gisf), false);
    assert_int_equal(Avtp_Gisf_GetMessageTimestamp(gisf), 0);
    assert_memory_equal(payload, msg + AVTP_GISF_HEADER_LEN, sizeof(payload));
    assert_int_equal(Avtp_Gisf_IsValid(gisf, msg_len), 1);
}

static void Test_Gisf_IsValid(void **state)
{
    const size_t msg_len = AVTP_GISF_HEADER_LEN + 32;
    uint8_t msg[msg_len] = {0};
    Avtp_Gisf_t *gisf = (Avtp_Gisf_t *)msg;
    uint8_t payload[8] = {0, 1, 2, 3, 4, 5, 6, 7};

    // An Init-only PDU has AcfMsgLength == 0, so IsValid must reject it.
    Avtp_Gisf_Init(gisf);
    assert_int_equal(Avtp_Gisf_IsValid(gisf, msg_len), 0);

    // A properly-formed frame with an 8-byte payload is valid.
    Avtp_Gisf_CreateAcfMessage(gisf, 0x5FF, payload, sizeof(payload));
    assert_int_equal(Avtp_Gisf_IsValid(gisf, msg_len), 1);

    // Not a GISF message (zero buffer, AcfMsgType != GISF).
    memset(msg, 0, msg_len);
    assert_int_equal(Avtp_Gisf_IsValid(gisf, msg_len), 0);

    // Declared length larger than the buffer is invalid.
    Avtp_Gisf_CreateAcfMessage(gisf, 0x5FF, payload, sizeof(payload));
    assert_int_equal(Avtp_Gisf_IsValid(gisf, AVTP_GISF_HEADER_LEN + 1), 0);
}

int main(void)
{
    const struct CMUnitTest tests[] = {cmocka_unit_test(Test_Gisf_Init),
                                       cmocka_unit_test(Test_Gisf_GetPad),
                                       cmocka_unit_test(Test_Gisf_IsMtv),
                                       cmocka_unit_test(Test_Gisf_GetImageSensorId),
                                       cmocka_unit_test(Test_Gisf_GetMessageTimestamp),
                                       cmocka_unit_test(Test_Gisf_IsEl),
                                       cmocka_unit_test(Test_Gisf_IsTl),
                                       cmocka_unit_test(Test_Gisf_IsEf),
                                       cmocka_unit_test(Test_Gisf_GetEvt),
                                       cmocka_unit_test(Test_Gisf_IsBf),
                                       cmocka_unit_test(Test_Gisf_GetLineTypeId),
                                       cmocka_unit_test(Test_Gisf_GetEvt2),
                                       cmocka_unit_test(Test_Gisf_GetISeqNum),
                                       cmocka_unit_test(Test_Gisf_GetLineNumber),
                                       cmocka_unit_test(Test_Gisf_GetPayloadLength),
                                       cmocka_unit_test(Test_Gisf_GetPayloadLength_NoPadding),
                                       cmocka_unit_test(Test_Gisf_SetMtv),
                                       cmocka_unit_test(Test_Gisf_SetImageSensorId),
                                       cmocka_unit_test(Test_Gisf_SetMessageTimestamp),
                                       cmocka_unit_test(Test_Gisf_SetEl),
                                       cmocka_unit_test(Test_Gisf_SetTl),
                                       cmocka_unit_test(Test_Gisf_SetEf),
                                       cmocka_unit_test(Test_Gisf_SetEvt),
                                       cmocka_unit_test(Test_Gisf_SetBf),
                                       cmocka_unit_test(Test_Gisf_SetLineTypeId),
                                       cmocka_unit_test(Test_Gisf_SetEvt2),
                                       cmocka_unit_test(Test_Gisf_SetISeqNum),
                                       cmocka_unit_test(Test_Gisf_SetLineNumber),
                                       cmocka_unit_test(Test_Gisf_SetPayloadLength),
                                       cmocka_unit_test(Test_Gisf_SetPayloadLength_NoPadding),
                                       cmocka_unit_test(Test_Gisf_Payload),
                                       cmocka_unit_test(Test_Gisf_CreateAcfMessage),
                                       cmocka_unit_test(Test_Gisf_CreateFromGarbage),
                                       cmocka_unit_test(Test_Gisf_IsValid)};

    return cmocka_run_group_tests(tests, NULL, NULL);
}

#ifdef __cplusplus
}
#endif
