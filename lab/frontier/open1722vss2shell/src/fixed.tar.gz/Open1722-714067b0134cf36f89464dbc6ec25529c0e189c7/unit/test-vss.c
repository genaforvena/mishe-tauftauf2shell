/*
 * Copyright (c) 2024, COVESA
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of COVESA nor the names of its contributors may be
 *      used to endorse or promote products derived from this software without
 *      specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#if defined(__cplusplus)
extern "C" {
#include <cmocka.h>
}
#else
#include <cmocka.h>
#endif
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

#include "avtp/acf/custom/Vss.h"
#include "avtp/acf/AcfCommon.h"

#define MAX_PDU_SIZE 1500

static void vss_init(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    uint8_t init_pdu[AVTP_VSS_FIXED_HEADER_LEN];

    // Check if the function is initializing properly
    Avtp_Vss_Init((Avtp_Vss_t *)pdu);
    memset(init_pdu, 0, AVTP_VSS_FIXED_HEADER_LEN);
    init_pdu[0] = 0x42 << 1; // Setting ACF type as ACF_VSS
    assert_memory_equal(init_pdu, pdu, AVTP_VSS_FIXED_HEADER_LEN);

    uint8_t type = Avtp_AcfCommon_GetAcfMsgType((Avtp_AcfCommon_t *)pdu);
    assert_int_equal(type, 0x42);
}

static void vss_pad(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);

    // Check if the function is initializing properly
    Avtp_Vss_Init(vss_pdu);

    for (int i = 1; i < 4; i++) {
        Avtp_Vss_SetPayloadLength(vss_pdu, i);

        uint8_t vss_quadlets = Avtp_AcfCommon_GetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu);
        assert_int_equal(vss_quadlets, AVTP_VSS_FIXED_HEADER_LEN / 4 + 1);

        uint8_t vss_pad = Avtp_Vss_GetPad(vss_pdu);
        assert_int_equal(vss_pad, 4 - i);
    }
}

static void vss_static_path(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);

    VssPath_t path_id = {.vss_static_id_path = 0x01020304};
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_STATIC_ID_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    uint8_t exp_static_id[] = {1, 2, 3, 4};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN, exp_static_id, 4);

    VssPath_t get_path_id;
    Avtp_Vss_GetVssPath(vss_pdu, &get_path_id);
    assert_int_equal(get_path_id.vss_static_id_path, path_id.vss_static_id_path);
    assert_int_equal(Avtp_Vss_GetAddrMode(vss_pdu), VSS_STATIC_ID_MODE);
    assert_int_equal(Avtp_Vss_CalcVssPathLength(vss_pdu), 4);
}

static void vss_interop_path(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);

    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    uint8_t get_path_len[] = {0, 13};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN, get_path_len, 2);
    assert_int_equal(Avtp_Vss_GetAddrMode(vss_pdu), VSS_INTEROP_MODE);
    assert_int_equal(Avtp_Vss_CalcVssPathLength(vss_pdu), 15);

    VssPath_t get_vss_path;
    char buffer[15];
    get_vss_path.vss_interop_path.path = buffer;
    Avtp_Vss_GetVssPath(vss_pdu, &get_vss_path);
    assert_int_equal(get_vss_path.vss_interop_path.path_length, 13);
    assert_memory_equal(get_vss_path.vss_interop_path.path, path, 13);
}

static void vss_data_uint8(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_uint8 = {.data_uint8 = 0x05};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT8);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_uint8);
    uint8_t mem[] = {5};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 1);

    VssData_t vss_data_uint8_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_UINT8);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_uint8_get);
    assert_int_equal(vss_data_uint8_get.data_uint8, 0x05);
}

static void vss_data_int8(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_int8 = {.data_int8 = -0x05};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_INT8);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_int8);
    int8_t mem[] = {-5};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, (uint8_t *)mem, 1);

    VssData_t vss_data_int8_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_INT8);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_int8_get);
    assert_int_equal(vss_data_int8_get.data_int8, -0x05);
}

static void vss_data_uint16(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_uint16 = {.data_uint16 = 0x0504};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT16);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_uint16);
    uint8_t mem[] = {5, 4};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 2);

    VssData_t vss_data_uint16_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_UINT16);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_uint16_get);
    assert_int_equal(vss_data_uint16_get.data_uint16, 0x0504);
}

static void vss_data_int16(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_int16 = {.data_int16 = -0x0504};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_INT16);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_int16);
    uint8_t mem[] = {0xFA, 0xFC};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 2);

    VssData_t vss_data_int16_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_INT16);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_int16_get);
    assert_int_equal(vss_data_int16_get.data_int16, -0x0504);
}

static void vss_data_uint32(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_uint32 = {.data_uint32 = 0x05040302};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT32);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_uint32);
    uint8_t mem[] = {5, 4, 3, 2};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 4);

    VssData_t vss_data_uint32_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_UINT32);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_uint32_get);
    assert_int_equal(vss_data_uint32_get.data_uint32, 0x05040302);
}

static void vss_data_int32(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_int32 = {.data_int32 = -0x05040302};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_INT32);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_int32);
    uint8_t mem[] = {0xFA, 0xFB, 0xFC, 0xFE};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 4);

    VssData_t vss_data_int32_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_INT32);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_int32_get);
    assert_int_equal(vss_data_int32_get.data_int32, -0x05040302);
}

static void vss_data_uint64(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_uint64 = {.data_uint64 = 0x0504030201060708};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT64);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_uint64);
    uint8_t mem[] = {5, 4, 3, 2, 1, 6, 7, 8};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 8);

    VssData_t vss_data_uint64_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_UINT64);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_uint64_get);
    uint8_t mem_cpu[] = {8, 7, 6, 1, 2, 3, 4, 5};
    assert_memory_equal(&(vss_data_uint64_get.data_uint64), mem_cpu, 8);
}

static void vss_data_int64(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_int64 = {.data_int64 = -0x0504030201060708};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_INT64);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_int64);
    uint8_t mem[] = {0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xF9, 0xF8, 0xF8};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 8);

    VssData_t vss_data_int64_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_INT64);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_int64_get);
    uint8_t mem_cpu[] = {0xF8, 0xF8, 0xF9, 0xFE, 0xFD, 0xFC, 0xFB, 0xFA};
    assert_memory_equal(&(vss_data_int64_get.data_int64), mem_cpu, 8);
}

static void vss_data_bool(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_bool = {.data_bool = 0x01};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_BOOL);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_bool);
    uint8_t mem[] = {1};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 1);

    VssData_t vss_data_bool_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_BOOL);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_bool_get);
    assert_int_equal(vss_data_bool_get.data_bool, 1);
}

static void vss_data_float(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_float = {.data_float = -1.2};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_FLOAT);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_float);
    uint8_t mem[] = {0xbf, 0x99, 0x99, 0x9a};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 4);

    VssData_t vss_data_float_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_FLOAT);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_float_get);
    assert_float_equal(vss_data_float_get.data_float, -1.2, 0.5);
}

static void vss_data_double(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    VssData_t vss_data_double = {.data_double = -1.2};
    Avtp_Vss_SetDatatype(vss_pdu, VSS_DOUBLE);
    Avtp_Vss_SetVssData(vss_pdu, &vss_data_double);
    uint8_t mem[] = {0xbf, 0xf3, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, mem, 8);

    VssData_t vss_data_double_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_DOUBLE);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_double_get);
    assert_float_equal(vss_data_double_get.data_double, -1.2, 0.1);
}

static void vss_data_string(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    char str_value[] = "10m/s2";
    VssDataString_t vss_data_string = {0};
    vss_data_string.data = str_value;
    vss_data_string.data_length = strlen(str_value);
    VssData_t data = {0};
    data.data_string = &vss_data_string;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_STRING);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, (uint8_t)strlen(str_value)};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, str_value, strlen(str_value));

    VssData_t vss_data_get;
    VssDataString_t vss_data_string_get = {.data = 0};
    vss_data_get.data_string = &vss_data_string_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_STRING);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_string->data_length, strlen(str_value));
    char str_value_recv[vss_data_get.data_string->data_length];
    vss_data_string_get.data = str_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_string->data, str_value, strlen(str_value));
}

static void vss_data_uint8_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    uint8_t uint8_arr_value[] = {5, 4, 3, 2, 1};
    VssDataUint8Array_t vss_data_uint8_arr = {0};
    vss_data_uint8_arr.data = uint8_arr_value;
    vss_data_uint8_arr.data_length = 5;
    VssData_t data = {0};
    data.data_uint8_array = &vss_data_uint8_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT8_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 5};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, uint8_arr_value, 5);

    VssData_t vss_data_get;
    VssDataUint8Array_t vss_data_uint8_arr_get = {.data = 0};
    vss_data_get.data_uint8_array = &vss_data_uint8_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_UINT8_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_uint8_array->data_length, 5);
    uint8_t uint8_arr_value_recv[vss_data_get.data_uint8_array->data_length];
    vss_data_uint8_arr_get.data = uint8_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_uint8_array->data, uint8_arr_value, 5);
}

static void vss_data_int8_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    int8_t int8_arr_value[] = {-5, -4, -3, -2, -1};
    VssDataInt8Array_t vss_data_int8_arr = {0};
    vss_data_int8_arr.data = int8_arr_value;
    vss_data_int8_arr.data_length = 5;
    VssData_t data = {0};
    data.data_int8_array = &vss_data_int8_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_INT8_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 5};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, int8_arr_value, 5);

    VssData_t vss_data_get = {0};
    VssDataInt8Array_t vss_data_int8_arr_get = {0};
    vss_data_int8_arr_get.data = 0;
    vss_data_get.data_int8_array = &vss_data_int8_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_INT8_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_int8_array->data_length, 5);
    int8_t int8_arr_value_recv[vss_data_get.data_int8_array->data_length];
    vss_data_int8_arr_get.data = int8_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_int8_array->data, int8_arr_value, 5);
}

static void vss_data_uint16_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    uint16_t uint16_arr_value[] = {0x100, 0x101, 0x102, 0x103, 0x104};
    VssDataUint16Array_t vss_data_uint16_arr = {0};
    vss_data_uint16_arr.data = uint16_arr_value;
    vss_data_uint16_arr.data_length = 10;
    VssData_t data = {0};
    data.data_uint16_array = &vss_data_uint16_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT16_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 10};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {1, 0, 1, 1, 1, 2, 1, 3, 1, 4};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 10);

    VssData_t vss_data_get;
    VssDataUint16Array_t vss_data_uint16_arr_get = {0};
    vss_data_uint16_arr_get.data = 0;
    vss_data_get.data_uint16_array = &vss_data_uint16_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_UINT16_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_uint16_array->data_length, 10);
    uint16_t uint16_arr_value_recv[vss_data_get.data_uint16_array->data_length / 2];
    vss_data_uint16_arr_get.data = uint16_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_uint16_array->data, uint16_arr_value, 10);
}

static void vss_data_int16_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    int16_t int16_arr_value[] = {-0x100, -0x101, -0x102, -0x103, -0x104};
    VssDataInt16Array_t vss_data_int16_arr = {0};
    vss_data_int16_arr.data = int16_arr_value;
    vss_data_int16_arr.data_length = 10;
    VssData_t data = {0};
    data.data_int16_array = &vss_data_int16_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_INT16_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 10};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {0xFF, 0, 0xFE, 0xFF, 0xfe, 0xfe, 0xfe, 0xfd, 0xfe, 0xfc};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 10);

    VssData_t vss_data_get = {0};
    VssDataInt16Array_t vss_data_int16_arr_get = {0};
    vss_data_int16_arr_get.data = 0;
    vss_data_get.data_int16_array = &vss_data_int16_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_INT16_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_int16_array->data_length, 10);
    int16_t int16_arr_value_recv[vss_data_get.data_int16_array->data_length / 2];
    vss_data_int16_arr_get.data = int16_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_int16_array->data, int16_arr_value, 10);
}

static void vss_data_uint32_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    uint32_t uint32_arr_value[] = {0x10000, 0x10100, 0x10200, 0x10300, 0x10400};
    VssDataUint32Array_t vss_data_uint32_arr = {0};
    vss_data_uint32_arr.data = uint32_arr_value;
    vss_data_uint32_arr.data_length = 20;
    VssData_t data = {0};
    data.data_uint32_array = &vss_data_uint32_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT32_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 20};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 2, 0, 0, 1, 3, 0, 0, 1, 4, 0};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 20);

    VssData_t vss_data_get = {0};
    VssDataUint32Array_t vss_data_uint32_arr_get = {0};
    vss_data_uint32_arr_get.data = 0;
    vss_data_get.data_uint32_array = &vss_data_uint32_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_UINT32_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_uint32_array->data_length, 20);
    uint32_t uint32_arr_value_recv[vss_data_get.data_uint32_array->data_length / 4];
    vss_data_uint32_arr_get.data = uint32_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_uint32_array->data, uint32_arr_value, 20);
}

static void vss_data_int32_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    int32_t int32_arr_value[] = {-0x10000, -0x10100, -0x10200, -0x10300, -0x10400};
    VssDataInt32Array_t vss_data_int32_arr = {0};
    vss_data_int32_arr.data = int32_arr_value;
    vss_data_int32_arr.data_length = 20;
    VssData_t data = {0};
    data.data_int32_array = &vss_data_int32_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_INT32_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 20};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {0xff, 0xff, 0,    0,    0xff, 0xfe, 0xff, 0,    0xff, 0xfe,
                            0xfe, 0,    0xff, 0xfe, 0xfd, 0,    0xff, 0xfe, 0xfc, 0};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 20);

    VssData_t vss_data_get = {0};
    VssDataInt32Array_t vss_data_int32_arr_get = {0};
    vss_data_int32_arr_get.data = 0;
    vss_data_get.data_int32_array = &vss_data_int32_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_INT32_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_int32_array->data_length, 20);
    int32_t int32_arr_value_recv[vss_data_get.data_int32_array->data_length / 4];
    vss_data_int32_arr_get.data = int32_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_int32_array->data, int32_arr_value, 20);
}

static void vss_data_uint64_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    uint64_t uint64_arr_value[] = {0x10000, 0x10100, 0x10200, 0x10300, 0x10400};
    VssDataUint64Array_t vss_data_uint64_arr = {0};
    vss_data_uint64_arr.data = uint64_arr_value;
    vss_data_uint64_arr.data_length = 40;

    VssData_t data = {0};
    data.data_uint64_array = &vss_data_uint64_arr;
    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT64_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 40};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
                            0, 1, 2, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 1, 4, 0};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 40);

    VssData_t vss_data_get = {0};
    VssDataUint64Array_t vss_data_uint64_arr_get = {0};
    vss_data_get.data_uint64_array = &vss_data_uint64_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_UINT64_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_uint64_array->data_length, 40);
    uint64_t uint64_arr_value_recv[vss_data_get.data_uint64_array->data_length / 8];
    vss_data_uint64_arr_get.data = uint64_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_uint64_array->data, uint64_arr_value, 40);
}

static void vss_data_int64_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    int64_t int64_arr_value[] = {-0x10000, -0x10100, -0x10200, -0x10300, -0x10400};
    VssDataInt64Array_t vss_data_int64_arr = {0};
    vss_data_int64_arr.data = int64_arr_value;
    vss_data_int64_arr.data_length = 40;
    VssData_t data = {0};
    data.data_int64_array = &vss_data_int64_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_INT64_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 40};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0,    0,    0xff, 0xff, 0xff, 0xff, 0xff, 0xfe,
        0xff, 0,    0xff, 0xff, 0xff, 0xff, 0xff, 0xfe, 0xfe, 0,    0xff, 0xff, 0xff, 0xff,
        0xff, 0xfe, 0xfd, 0,    0xff, 0xff, 0xff, 0xff, 0xff, 0xfe, 0xfc, 0,
    };
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 40);

    VssData_t vss_data_get = {0};
    VssDataInt64Array_t vss_data_int64_arr_get = {0};
    vss_data_int64_arr_get.data = 0;

    vss_data_get.data_int64_array = &vss_data_int64_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_INT64_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_int64_array->data_length, 40);
    int64_t int64_arr_value_recv[vss_data_get.data_int64_array->data_length / 8];
    vss_data_int64_arr_get.data = int64_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_int64_array->data, int64_arr_value, 40);
}

static void vss_data_bool_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    uint8_t bool_arr_value[] = {1, 0, 0, 0, 1};
    VssDataBoolArray_t vss_data_bool_arr = {0};
    vss_data_bool_arr.data = bool_arr_value;
    vss_data_bool_arr.data_length = 5;

    VssData_t data = {0};
    data.data_bool_array = &vss_data_bool_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_BOOL_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 5};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, bool_arr_value, 5);

    VssData_t vss_data_get = {0};
    VssDataBoolArray_t vss_data_bool_arr_get = {0};
    vss_data_bool_arr_get.data = 0;
    vss_data_get.data_bool_array = &vss_data_bool_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_BOOL_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_bool_array->data_length, 5);
    uint8_t bool_arr_value_recv[vss_data_get.data_bool_array->data_length];
    vss_data_bool_arr_get.data = bool_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_bool_array->data, bool_arr_value, 5);
}

static void vss_data_float_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    float float_arr_value[] = {1.2, -1.2, 1.3, -1.3, 1.5};
    VssDataFloatArray_t vss_data_float_arr = {0};
    vss_data_float_arr.data = float_arr_value;
    vss_data_float_arr.data_length = 20;
    VssData_t data = {0};
    data.data_float_array = &vss_data_float_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_FLOAT_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 20};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {0x3f, 0x99, 0x99, 0x9a, 0xbf, 0x99, 0x99, 0x9a, 0x3f, 0xa6, 0x66,
                            0x66, 0xbf, 0xa6, 0x66, 0x66, 0x3f, 0xc0, 0,    0,    0};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 20);

    VssData_t vss_data_get = {0};
    VssDataFloatArray_t vss_data_float_arr_get = {0};
    vss_data_float_arr_get.data = 0;

    vss_data_get.data_float_array = &vss_data_float_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_FLOAT_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_float_array->data_length, 20);
    float float_arr_value_recv[vss_data_get.data_float_array->data_length / 4];
    vss_data_float_arr_get.data = float_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_float_array->data, float_arr_value, 20);
}

static void vss_data_double_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    double double_arr_value[] = {1.2, -1.2, 1.3, -1.3, 1.5};
    VssDataDoubleArray_t vss_data_double_arr = {0};
    vss_data_double_arr.data = double_arr_value;
    vss_data_double_arr.data_length = 40;
    VssData_t data = {0};
    data.data_double_array = &vss_data_double_arr;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_DOUBLE_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 40};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {0x3f, 0xf3, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0xbf, 0xf3,
                            0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x3f, 0xf4, 0xcc, 0xcc,
                            0xcc, 0xcc, 0xcc, 0xcd, 0xbf, 0xf4, 0xcc, 0xcc, 0xcc, 0xcc,
                            0xcc, 0xcd, 0x3f, 0xf8, 0,    0,    0,    0,    0,    0};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 40);

    VssData_t vss_data_get = {0};
    VssDataDoubleArray_t vss_data_double_arr_get = {0};
    vss_data_get.data_double_array = &vss_data_double_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_DOUBLE_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_double_array->data_length, 40);
    double double_arr_value_recv[vss_data_get.data_double_array->data_length / 8];
    vss_data_double_arr_get.data = double_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_double_array->data, double_arr_value, 40);
}

static void vss_data_string_array(void **state)
{

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    Avtp_Vss_Init(vss_pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 20);
    char path[] = "Vehicle.Speed";
    uint32_t path_length = strlen(path);

    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = path_length;
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetVssPath(vss_pdu, &path_id);

    char str1[] = "Hello";
    char str2[] = "World";
    char str3[] = "Tschuss";
    VssDataString_t vss_str1 = {0};
    vss_str1.data = str1;
    vss_str1.data_length = strlen(str1);
    VssDataString_t vss_str2 = {0};
    vss_str2.data = str2;
    vss_str2.data_length = strlen(str2);
    VssDataString_t vss_str3 = {0};
    vss_str3.data = str3;
    vss_str3.data_length = strlen(str3);

    VssDataString_t *arr[] = {&vss_str1, &vss_str2, &vss_str3};
    /* Each string entry is prefixed by a 2-byte length field. */
    uint8_t buffer[strlen(str1) + strlen(str2) + strlen(str3) + 2 * 3];
    VssDataStringArray_t vss_str_array = {0};
    vss_str_array.data = buffer;
    Avtp_Vss_SerializeStringArray(&vss_str_array, arr, 3);

    VssData_t data = {0};
    data.data_string_array = &vss_str_array;

    Avtp_Vss_SetDatatype(vss_pdu, VSS_STRING_ARRAY);
    Avtp_Vss_SetVssData(vss_pdu, &data);
    uint8_t len_in_mem[] = {0, 23};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 15, len_in_mem, 2);
    uint8_t arr_in_mem[] = {0x00, 0x05, 'H',  'e',  'l', 'l', 'o', 0x00, 0x05, 'W', 'o', 'r',
                            'l',  'd',  0x00, 0x07, 'T', 's', 'c', 'h',  'u',  's', 's'};
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN + 17, arr_in_mem, 23);

    VssData_t vss_data_get = {0};
    VssDataStringArray_t vss_data_string_arr_get = {0};
    vss_data_get.data_string_array = &vss_data_string_arr_get;
    assert_int_equal(Avtp_Vss_GetDatatype(vss_pdu), VSS_STRING_ARRAY);
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_int_equal(vss_data_get.data_string_array->data_length, 23);
    uint8_t string_arr_value_recv[vss_data_get.data_string_array->data_length];
    vss_data_string_arr_get.data = string_arr_value_recv;
    Avtp_Vss_GetVssData(vss_pdu, &vss_data_get);
    assert_memory_equal(vss_data_get.data_string_array->data, arr_in_mem, 23);

    assert_int_equal(Avtp_Vss_GetVSSDataStringArrayLength(vss_data_get.data_string_array), 3);
    VssDataString_t strings[3] = {{.data = 0}, {.data = 0}, {.data = 0}};
    VssDataString_t *strings_array[] = {&strings[0], &strings[1], &strings[2]};
    Avtp_Vss_DeserializeStringArray(vss_data_get.data_string_array,
                                    (VssDataString_t **)&strings_array, 3);

    assert_int_equal(strings[0].data_length, 5);
    assert_int_equal(strings[1].data_length, 5);
    assert_int_equal(strings[2].data_length, 7);

    char str1_recd[5];
    char str2_recd[5];
    char str3_recd[7];
    strings[0].data = str1_recd, strings[1].data = str2_recd, strings[2].data = str3_recd,

    Avtp_Vss_DeserializeStringArray(vss_data_get.data_string_array,
                                    (VssDataString_t **)&strings_array, 3);
    assert_memory_equal(strings[0].data, str1, 5);
    assert_memory_equal(strings[1].data, str2, 5);
    assert_memory_equal(strings[2].data, str3, 7);
}

static void vss_data_string_array_malformed(void **state)
{
    /* On-wire layout for a VSS string array is [u16 length][bytes ...]
     * pairs. Construct a 23-byte payload identical to the well-formed
     * fixture in vss_data_string_array, except the third length prefix
     * has been corrupted from 0x0007 to 0x00AA. The third entry now
     * claims 170 bytes of body, but only 7 bytes of buffer remain after
     * its length prefix.
     *
     * Per the bounds-check, the parser must:
     *   - stop counting at the last fully-contained string, so
     *     GetVSSDataStringArrayLength returns 2 (not 3, and not 0);
     *   - refuse to memcpy past the buffer end, so
     *     DeserializeStringArray fills the first two output structs
     *     with the well-formed strings and leaves the third untouched.
     */
    uint8_t arr_in_mem[] = {
        0x00, 0x05, 'H',  'e',  'l', 'l', 'o', 0x00, 0x05, 'W', 'o', 'r',
        'l',  'd',  0x00, 0xAA, 'T', 's', 'c', 'h',  'u',  's', 's',
    };

    VssDataStringArray_t str_array = {0};
    str_array.data = arr_in_mem;
    str_array.data_length = sizeof(arr_in_mem);

    /* Counting must stop at the second well-formed string. */
    assert_int_equal(Avtp_Vss_GetVSSDataStringArrayLength(&str_array), 2);

    /* Deserialisation must fill only the first two entries. The third
     * struct stays at its initial state (data_length == 0). */
    char buf1[8] = {0}, buf2[8] = {0}, buf3[8] = {0};
    VssDataString_t s1 = {0};
    s1.data = buf1;
    VssDataString_t s2 = {0};
    s2.data = buf2;
    VssDataString_t s3 = {0};
    s3.data = buf3;
    VssDataString_t *strings_array[] = {&s1, &s2, &s3};

    Avtp_Vss_DeserializeStringArray(&str_array, strings_array, 3);

    assert_int_equal(s1.data_length, 5);
    assert_memory_equal(s1.data, "Hello", 5);
    assert_int_equal(s2.data_length, 5);
    assert_memory_equal(s2.data, "World", 5);

    /* Third string was rejected by the bounds check; the output struct
     * is left at its initial state. */
    assert_int_equal(s3.data_length, 0);
}

/* ──────────────────────────────────────────────────────────────────────────
 * OOB / Bounds Truncation Tests
 *
 * Each test constructs a PDU whose ACF msg_length is deliberately smaller
 * than the wire data_length field (0xFFFF).  The parser must
 * clamp the field to the bytes actually available within the declared
 * message length.  Without clamping it would attempt to memcpy or iterate
 * 65535 bytes from a 24‑byte buffer.
 *
 * All data‑type tests use STATIC_ID mode (4‑byte path) so the data payload
 * always starts at PDU offset 16.  Declared PDU size = msg_quadlets × 4.
 * ────────────────────────────────────────────────────────────────────────── */

/* Helper: build a VSS PDU with STATIC_ID path, given msg_quadlets, datatype,
 * and plant 0xFFFF as the on‑wire data_length followed by fill_data.
 * Available data bytes = msg_quadlets × 4 − 16 (header+path) − 2 (prefix). */
static Avtp_Vss_t *vss_build_data_oob_pdu(uint8_t *buf, size_t buf_size, uint8_t msg_quadlets,
                                          Vss_Datatype_t datatype, const uint8_t *fill_data,
                                          uint16_t fill_len)
{
    memset(buf, 0, buf_size);
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    Avtp_Vss_Init(pdu);
    Avtp_Vss_SetAddrMode(pdu, VSS_STATIC_ID_MODE);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)pdu, msg_quadlets);
    Avtp_Vss_SetDatatype(pdu, datatype);

    /* Inflated wire data_length at offset 16 (payload start) */
    buf[16] = 0xFF;
    buf[17] = 0xFF;

    uint16_t max_data = (uint16_t)msg_quadlets * 4 - 16 - 2;
    uint16_t copy_len = fill_len < max_data ? fill_len : max_data;
    if (copy_len > 0 && fill_data != NULL)
        memcpy(buf + 18, fill_data, copy_len);

    return pdu;
}

/* ── Avtp_Vss_GetVssPath  –  INTEROP mode ────────────────────────────── */

static void vss_path_interop_oob(void **state)
{
    uint8_t buf[32];
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    memset(buf, 0, sizeof(buf));

    /* 5 quadlets = 20 bytes. Path at offset 12, 2‑byte prefix →
     * 6 bytes available for path data after the length prefix. */
    Avtp_Vss_Init(pdu);
    Avtp_Vss_SetAddrMode(pdu, VSS_INTEROP_MODE);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)pdu, 5);

    buf[12] = 0xFF;
    buf[13] = 0xFF; /* wire path_length = 0xFFFF */
    buf[14] = 'A';
    buf[15] = 'B'; /* only 2 bytes of real path data
                    * (bytes 16‑17 are zero from memset) */

    char path_buf[16];
    memset(path_buf, 0x5A, sizeof(path_buf));
    VssPath_t get_path;
    get_path.vss_interop_path.path = path_buf;
    Avtp_Vss_GetVssPath(pdu, &get_path);

    /* path_length must be clamped to 6 (20 − 12 − 2 = 6) */
    assert_int_equal(get_path.vss_interop_path.path_length, 6);
    assert_memory_equal(path_buf, "AB\0\0\0\0", 6);

    /* The wire prefix 0xFFFF does not fit the declared frame, so there is
     * no valid path length to report.  CalcVssPathLength must not wrap to
     * 1 or read beyond the declared message. */
    assert_int_equal(Avtp_Vss_CalcVssPathLength(pdu), 0);
}

static void vss_calc_path_length_header_only(void **state)
{
    (void)state;

    /* INTEROP: a header-only frame passes IsValid, but there is no room for
     * the 2-byte path prefix.  Heap allocation makes a stale prefixed read
     * visible under ASan. */
    uint8_t *interop = (uint8_t *)malloc(AVTP_VSS_FIXED_HEADER_LEN);
    assert_non_null(interop);

    Avtp_Vss_Init((Avtp_Vss_t *)interop);
    Avtp_Vss_SetAddrMode((Avtp_Vss_t *)interop, VSS_INTEROP_MODE);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)interop,
                                   AVTP_VSS_FIXED_HEADER_LEN / AVTP_QUADLET_SIZE);
    assert_true(Avtp_Vss_IsValid((Avtp_Vss_t *)interop, AVTP_VSS_FIXED_HEADER_LEN));
    assert_int_equal(Avtp_Vss_CalcVssPathLength((Avtp_Vss_t *)interop), 0);
    free(interop);

    /* STATIC_ID: same header-only frame has no room for the 4-byte ID. */
    uint8_t *static_id = (uint8_t *)malloc(AVTP_VSS_FIXED_HEADER_LEN);
    assert_non_null(static_id);

    Avtp_Vss_Init((Avtp_Vss_t *)static_id);
    Avtp_Vss_SetAddrMode((Avtp_Vss_t *)static_id, VSS_STATIC_ID_MODE);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)static_id,
                                   AVTP_VSS_FIXED_HEADER_LEN / AVTP_QUADLET_SIZE);
    assert_true(Avtp_Vss_IsValid((Avtp_Vss_t *)static_id, AVTP_VSS_FIXED_HEADER_LEN));
    assert_int_equal(Avtp_Vss_CalcVssPathLength((Avtp_Vss_t *)static_id), 0);
    free(static_id);
}

static void vss_calc_path_length_unframed(void **state)
{
    (void)state;

    uint8_t pdu[MAX_PDU_SIZE];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;
    memset(pdu, 0, sizeof(pdu));
    Avtp_Vss_Init(vss_pdu);

    assert_int_equal(Avtp_Vss_CalcVssPathLength(NULL), 0);

    /* Default mode is INTEROP.  A prefix of 13 gives 15 bytes including the
     * 2-byte prefix. */
    pdu[AVTP_VSS_FIXED_HEADER_LEN] = 0x00;
    pdu[AVTP_VSS_FIXED_HEADER_LEN + 1] = 0x0D;
    assert_int_equal(Avtp_Vss_CalcVssPathLength(vss_pdu), 15);

    /* Totals that do not fit uint16_t must not wrap. */
    pdu[AVTP_VSS_FIXED_HEADER_LEN] = 0xFF;
    pdu[AVTP_VSS_FIXED_HEADER_LEN + 1] = 0xFE;
    assert_int_equal(Avtp_Vss_CalcVssPathLength(vss_pdu), 0);

    pdu[AVTP_VSS_FIXED_HEADER_LEN + 1] = 0xFF;
    assert_int_equal(Avtp_Vss_CalcVssPathLength(vss_pdu), 0);

    /* STATIC_ID is a fixed 4-byte path, even before the frame is finalized. */
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_STATIC_ID_MODE);
    assert_int_equal(Avtp_Vss_CalcVssPathLength(vss_pdu), 4);

    /* Reserved addressing modes have no defined path layout. */
    Avtp_Vss_SetAddrMode(vss_pdu, (Vss_AddrMode_t)2);
    assert_int_equal(Avtp_Vss_CalcVssPathLength(vss_pdu), 0);
}

static void vss_set_data_malformed_path_no_write(void **state)
{
    (void)state;

    uint8_t pdu[20];
    uint8_t expected[8];
    Avtp_Vss_t *vss_pdu = (Avtp_Vss_t *)pdu;

    memset(pdu, 0, sizeof(pdu));
    memset(expected, 0x5A, sizeof(expected));
    expected[0] = 0xFF;
    expected[1] = 0xFF;
    memcpy(pdu + AVTP_VSS_FIXED_HEADER_LEN, expected, sizeof(expected));

    Avtp_Vss_Init(vss_pdu);
    Avtp_Vss_SetAddrMode(vss_pdu, VSS_INTEROP_MODE);
    Avtp_Vss_SetDatatype(vss_pdu, VSS_UINT16);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)vss_pdu, 5); /* 20 bytes */

    VssData_t data;
    memset(&data, 0, sizeof(data));
    data.data_uint16 = 0xBEEF;
    Avtp_Vss_SetVssData(vss_pdu, &data);

    /* The malformed 0xFFFF prefix describes no valid path, so SetVssData
     * must leave the path area untouched. */
    assert_memory_equal(pdu + AVTP_VSS_FIXED_HEADER_LEN, expected, sizeof(expected));
}

/* ── Avtp_Vss_GetVssData  –  memcpy group (wire length→memcpy) ──────── */

static void vss_data_string_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu = vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_STRING, fill, sizeof(fill));

    VssDataString_t str = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_string = &str;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(str.data_length, 6);

    char out[16];
    memset(out, 0x5A, sizeof(out));
    str.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_memory_equal(out, fill, 6);
    /* byte 6 untouched → no past‑buffer write */
    assert_int_equal((uint8_t)out[6], 0x5A);
}

static void vss_data_uint8_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_UINT8_ARRAY, fill, sizeof(fill));

    VssDataUint8Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_uint8_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    uint8_t out[16];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_memory_equal(out, fill, 6);
    assert_int_equal(out[6], 0x5A);
}

static void vss_data_int8_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_INT8_ARRAY, fill, sizeof(fill));

    VssDataInt8Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_int8_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    int8_t out[16];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_memory_equal(out, fill, 6);
    assert_int_equal((uint8_t)out[6], 0x5A);
}

static void vss_data_bool_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_BOOL_ARRAY, fill, sizeof(fill));

    VssDataBoolArray_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_bool_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    uint8_t out[16];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_memory_equal(out, fill, 6);
    assert_int_equal(out[6], 0x5A);
}

/* STRING_ARRAY advances vss_data_ptr by 2 past the prefix, then memcpy's
 * from the same position. Behaviour identical to the cases above. */
static void vss_data_string_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_STRING_ARRAY, fill, sizeof(fill));

    VssDataStringArray_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_string_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    uint8_t out[16];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_memory_equal(out, fill, 6);
    assert_int_equal(out[6], 0x5A);
}

/* ── Avtp_Vss_GetVssData  –  loop/iteration group (wire length→loop) ── */

static void vss_data_uint16_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_UINT16_ARRAY, fill, sizeof(fill));

    VssDataUint16Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_uint16_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    /* 6 bytes → 3 uint16 elements: {0x0102, 0x0304, 0x0506} */
    uint16_t out[8];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(out[0], 0x0102);
    assert_int_equal(out[1], 0x0304);
    assert_int_equal(out[2], 0x0506);
    assert_int_equal(out[3], 0x5A5A);
}

static void vss_data_int16_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_INT16_ARRAY, fill, sizeof(fill));

    VssDataInt16Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_int16_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    /* 6 bytes → 3 int16 elements: {0x0102, 0x0304, 0x0506} */
    int16_t out[8];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(out[0], 0x0102);
    assert_int_equal(out[1], 0x0304);
    assert_int_equal(out[2], 0x0506);
    assert_int_equal(out[3], 0x5A5A);
}

static void vss_data_uint32_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_UINT32_ARRAY, fill, sizeof(fill));

    VssDataUint32Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_uint32_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    /* 6 bytes → 1 uint32 element: {0x01020304} */
    uint32_t out[4];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(out[0], 0x01020304);
    assert_int_equal(out[1], 0x5A5A5A5A);
}

static void vss_data_int32_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_INT32_ARRAY, fill, sizeof(fill));

    VssDataInt32Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_int32_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    /* 6 bytes → 1 int32 element: {0x01020304} */
    int32_t out[4];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(out[0], 0x01020304);
    assert_int_equal(out[1], 0x5A5A5A5A);
}

/* msg_quadlets=7 (28 bytes) → 10 bytes available for data payload,
 * enough for one 8‑byte element. */
static void vss_data_uint64_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 7, VSS_UINT64_ARRAY, fill, sizeof(fill));

    VssDataUint64Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_uint64_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 10);

    /* 10 bytes → 1 uint64 element: {0x0102030405060708} */
    uint64_t out[4];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(out[0], 0x0102030405060708ull);
    assert_int_equal(out[1], 0x5A5A5A5A5A5A5A5Aull);
}

static void vss_data_int64_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 7, VSS_INT64_ARRAY, fill, sizeof(fill));

    VssDataInt64Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_int64_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 10);

    /* 10 bytes → 1 int64 element: {0x0102030405060708} */
    int64_t out[4];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(out[0], 0x0102030405060708ull);
    assert_int_equal(out[1], 0x5A5A5A5A5A5A5A5Aull);
}

static void vss_data_float_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 6, VSS_FLOAT_ARRAY, fill, sizeof(fill));

    VssDataFloatArray_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_float_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 6);

    /* 6 bytes → 1 float element (4 bytes read).
     * Wire {0x01,0x02,0x03,0x04} as BE uint32 → Avtp_BeToCpu32 →
     * 0x01020304, stored on LE as {0x04,0x03,0x02,0x01}. */
    float out[4];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    {
        uint8_t exp[] = {0x04, 0x03, 0x02, 0x01};
        assert_memory_equal(out, exp, 4);
    }
    /* Second float slot still holds the sentinel */
    assert_memory_equal(&out[1], "\x5A\x5A\x5A\x5A", 4);
}

static void vss_data_double_array_oob(void **state)
{
    uint8_t buf[64];
    uint8_t fill[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    Avtp_Vss_t *pdu =
        vss_build_data_oob_pdu(buf, sizeof(buf), 7, VSS_DOUBLE_ARRAY, fill, sizeof(fill));

    VssDataDoubleArray_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_double_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 10);

    /* 10 bytes → 1 double element (8 bytes read).
     * Wire {0x01..0x08} as BE uint64 → Avtp_BeToCpu64 →
     * 0x0102030405060708, stored on LE as {0x08..0x01}. */
    double out[4];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    {
        uint8_t exp[] = {0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01};
        assert_memory_equal(out, exp, 8);
    }
    assert_memory_equal(&out[1], "\x5A\x5A\x5A\x5A\x5A\x5A\x5A\x5A", 8);
}

/* Helper for the inflated-path tests: build an INTEROP-mode PDU where the
 * on‑wire path_length (0xFFFD) claims far more path bytes than the declared
 * msg_length allows.  CalcVssPathLength reports 0 because the path does not
 * fit the declared frame; the getters clamp the path instead. */
static Avtp_Vss_t *vss_build_inflated_path_pdu(uint8_t *buf, size_t buf_size, uint8_t msg_quadlets,
                                               Vss_Datatype_t datatype)
{
    memset(buf, 0, buf_size);
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    Avtp_Vss_Init(pdu);
    Avtp_Vss_SetAddrMode(pdu, VSS_INTEROP_MODE);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)pdu, msg_quadlets);
    Avtp_Vss_SetDatatype(pdu, datatype);

    /* Inflated path_length at offset 12 (INTEROP length prefix).
     * 0xFFFD was chosen because 0xFFFD + 2 = 0xFFFF without wrapping. */
    buf[12] = 0xFF;
    buf[13] = 0xFD;

    return pdu;
}

/* ── Regression tests for inflated-path → data-pointer OOB ─────────────
 * When a crafted INTEROP
 * path_length pushes the data pointer beyond the declared PDU, the
 * getters must treat the data area as empty and avoid any dereference.

/* VSS_STRING: the length-prefix dereference inside vss_read_clamped_length
 * must be guarded so it is never reached when the data pointer sits at or
 * past the frame end.  Correct behavior: data_length is 0, output untouched. */
static void vss_data_string_inflated_path_oob(void **state)
{
    uint8_t buf[64];
    Avtp_Vss_t *pdu = vss_build_inflated_path_pdu(buf, sizeof(buf), 6, VSS_STRING);

    VssDataString_t str = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_string = &str;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(str.data_length, 0);

    char out[16];
    memset(out, 0x5A, sizeof(out));
    str.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal((uint8_t)out[0], 0x5A);
}

/* Scalar VSS_UINT8: the raw dereference of *vss_data_ptr must be guarded
 * so that an out‑of‑frame data pointer is never read.
 * Correct behavior: Avtp_Vss_GetVssData is noop, pre‑set sentinel survives. */
static void vss_data_uint8_inflated_path_oob(void **state)
{
    uint8_t buf[64];
    Avtp_Vss_t *pdu = vss_build_inflated_path_pdu(buf, sizeof(buf), 6, VSS_UINT8);

    VssData_t vd;
    memset(&vd, 0xAA, sizeof(vd));
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(vd.data_uint8, 0xAA);
}

/* VSS_UINT8_ARRAY: like the string case but exercises the array path
 * through vss_read_clamped_length (prefix, then memcpy). */
static void vss_data_uint8_array_inflated_path_oob(void **state)
{
    uint8_t buf[64];
    Avtp_Vss_t *pdu = vss_build_inflated_path_pdu(buf, sizeof(buf), 6, VSS_UINT8_ARRAY);

    VssDataUint8Array_t arr = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_uint8_array = &arr;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(arr.data_length, 0);

    uint8_t out[16];
    memset(out, 0x5A, sizeof(out));
    arr.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(out[0], 0x5A);
}

/* STATIC_ID with a frame that is too short for the 4‑byte path: the
 * path must be treated as empty, and the scalar read skipped because
 * the data pointer still exceeds the declared frame. */
static void vss_data_static_id_truncated_oob(void **state)
{
    uint8_t buf[64];
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    memset(buf, 0, sizeof(buf));
    Avtp_Vss_Init(pdu);
    Avtp_Vss_SetAddrMode(pdu, VSS_STATIC_ID_MODE);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)pdu, 3); /* 12 bytes — header only */
    Avtp_Vss_SetDatatype(pdu, VSS_UINT8);

    VssData_t vd;
    memset(&vd, 0xAA, sizeof(vd));
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(vd.data_uint8, 0xAA);
}

/* ACF msg_length == 0 means the declared PDU size is 0 bytes.
 * This is testing for a regression: There used to be a
 * legacy bypass where the lentghts in ACF-VSS frames where trusted
 * when the ACF length was set to 0.
 * Correct behavior:: A zero‑msg‑length frame is treated as empty
 * (all getters no‑op). */

/* INTEROP path with msg_length == 0: the inflated path length must be
 * clamped to 0, memcpy must copy 0 bytes, and the output buffer must
 * survive untouched. */
static void vss_path_interop_zero_msg_length_oob(void **state)
{
    uint8_t buf[64];
    /* msg_quadlets = 0 → declared PDU = 0 bytes */
    Avtp_Vss_t *pdu = vss_build_inflated_path_pdu(buf, sizeof(buf), 0, VSS_UINT8);

    char path_buf[16];
    memset(path_buf, 0x5A, sizeof(path_buf));
    VssPath_t get_path;
    get_path.vss_interop_path.path = path_buf;
    Avtp_Vss_GetVssPath(pdu, &get_path);

    assert_int_equal(get_path.vss_interop_path.path_length, 0);
    assert_int_equal((uint8_t)path_buf[0], 0x5A);
}

/* VSS_STRING data with msg_length == 0 (via inflated‑path helper):
 * data_length must be 0, output buffer untouched. */
static void vss_data_string_zero_msg_length_oob(void **state)
{
    uint8_t buf[64];
    /* msg_quadlets = 0 → declared PDU = 0 bytes */
    Avtp_Vss_t *pdu = vss_build_inflated_path_pdu(buf, sizeof(buf), 0, VSS_STRING);

    VssDataString_t str = {.data = NULL};
    VssData_t vd;
    memset(&vd, 0, sizeof(vd));
    vd.data_string = &str;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal(str.data_length, 0);

    char out[16];
    memset(out, 0x5A, sizeof(out));
    str.data = out;
    Avtp_Vss_GetVssData(pdu, &vd);
    assert_int_equal((uint8_t)out[0], 0x5A);
}

/* ──────────────────────────────────────────────────────────────────────────
 * Avtp_Vss_IsValid tests
 *
 * IsValid is a deliberately shallow envelope check: it guarantees that the
 * declared ACF message length fits the actual buffer, so no getter can
 * overread.  It does NOT verify that the variable-length path/payload is
 * semantically well-formed.  The regression scenario is a frame declaring
 * 511 quadlets (2044 bytes) that is physically much shorter.
 * ────────────────────────────────────────────────────────────────────────── */

static void vss_is_valid_null(void **state)
{
    assert_false(Avtp_Vss_IsValid(NULL, 2044));
}

static void vss_is_valid_buffer_too_small(void **state)
{
    uint8_t buf[AVTP_VSS_FIXED_HEADER_LEN];
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    memset(buf, 0, sizeof(buf));
    Avtp_Vss_Init(pdu);

    /* The fixed header must be fully covered before any field is read. */
    assert_false(Avtp_Vss_IsValid(pdu, 0));
    assert_false(Avtp_Vss_IsValid(pdu, AVTP_VSS_FIXED_HEADER_LEN - 1));
}

static void vss_is_valid_wrong_acf_type(void **state)
{
    uint8_t buf[2044];
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    memset(buf, 0, sizeof(buf));
    Avtp_Vss_Init(pdu);
    Avtp_AcfCommon_SetAcfMsgType((Avtp_AcfCommon_t *)pdu, AVTP_ACF_TYPE_CAN);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)pdu, 3);

    assert_false(Avtp_Vss_IsValid(pdu, sizeof(buf)));
}

static void vss_is_valid_declared_larger_than_buffer(void **state)
{
    /* Regression scenario from the listener report: declared length is the
     * 9-bit maximum (511 quadlets = 2044 bytes) but the actual buffer is
     * far smaller.  Clamping inside the getters alone cannot know the real
     * size, so IsValid must reject the frame up front. */
    uint8_t buf[2044];
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    memset(buf, 0, sizeof(buf));
    Avtp_Vss_Init(pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)pdu, 511);

    assert_false(Avtp_Vss_IsValid(pdu, 100));
    assert_false(Avtp_Vss_IsValid(pdu, AVTP_VSS_FIXED_HEADER_LEN));
    assert_false(Avtp_Vss_IsValid(pdu, 2043));
    /* With a buffer that really is 2044 bytes the same frame is fine. */
    assert_true(Avtp_Vss_IsValid(pdu, 2044));
}

static void vss_is_valid_declared_smaller_than_header(void **state)
{
    uint8_t buf[2044];
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    memset(buf, 0, sizeof(buf));
    Avtp_Vss_Init(pdu);

    /* 0, 1 and 2 quadlets all declare fewer than the fixed header bytes. */
    for (uint16_t quadlets = 0; quadlets <= 2; quadlets++) {
        Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)pdu, quadlets);
        assert_false(Avtp_Vss_IsValid(pdu, sizeof(buf)));
    }
}

static void vss_is_valid_header_only_frame(void **state)
{
    uint8_t buf[AVTP_VSS_FIXED_HEADER_LEN];
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    memset(buf, 0, sizeof(buf));
    Avtp_Vss_Init(pdu);
    Avtp_AcfCommon_SetAcfMsgLength((Avtp_AcfCommon_t *)pdu,
                                   AVTP_VSS_FIXED_HEADER_LEN / AVTP_QUADLET_SIZE);

    /* Smallest frame that still passes: declared == buffer == header. */
    assert_true(Avtp_Vss_IsValid(pdu, sizeof(buf)));
    assert_false(Avtp_Vss_IsValid(pdu, sizeof(buf) - 1));

    /* There is no room for a path prefix or static ID in this frame. */
    assert_int_equal(Avtp_Vss_CalcVssPathLength(pdu), 0);
}

/* A valid full frame (talker-built, interop path + float data) must pass
 * IsValid exactly when the buffer covers the declared length, and the
 * getters must then decode it without any further surprises. */
static void vss_is_valid_roundtrip(void **state)
{
    uint8_t buf[MAX_PDU_SIZE];
    Avtp_Vss_t *pdu = (Avtp_Vss_t *)buf;
    memset(buf, 0, sizeof(buf));
    Avtp_Vss_Init(pdu);
    Avtp_Vss_SetAddrMode(pdu, VSS_INTEROP_MODE);

    char path[] = "Vehicle.Speed";
    VssPath_t path_id = {0};
    path_id.vss_interop_path.path = path;
    path_id.vss_interop_path.path_length = (uint16_t)strlen(path);
    Avtp_Vss_SetVssPath(pdu, &path_id);

    VssData_t data = {.data_float = 12.5f};
    Avtp_Vss_SetDatatype(pdu, VSS_FLOAT);
    Avtp_Vss_SetVssData(pdu, &data);
    Avtp_Vss_SetPayloadLength(pdu, (uint16_t)(2 + strlen(path) + sizeof(float)));

    uint16_t declared = Avtp_AcfCommon_GetAcfMsgLengthInBytes((Avtp_AcfCommon_t *)pdu);
    assert_true(Avtp_Vss_IsValid(pdu, declared));
    assert_true(Avtp_Vss_IsValid(pdu, 2044));
    /* One byte short of the declared length must fail. */
    assert_false(Avtp_Vss_IsValid(pdu, declared - 1));

    char path_out[32];
    VssPath_t get_path = {0};
    get_path.vss_interop_path.path = path_out;
    Avtp_Vss_GetVssPath(pdu, &get_path);
    assert_int_equal(get_path.vss_interop_path.path_length, strlen(path));
    assert_memory_equal(path_out, path, strlen(path));

    VssData_t get_data;
    Avtp_Vss_GetVssData(pdu, &get_data);
    assert_float_equal(get_data.data_float, 12.5, 0.001);
}

int main(void)
{
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(vss_init),
        cmocka_unit_test(vss_pad),
        cmocka_unit_test(vss_is_valid_null),
        cmocka_unit_test(vss_is_valid_buffer_too_small),
        cmocka_unit_test(vss_is_valid_wrong_acf_type),
        cmocka_unit_test(vss_is_valid_declared_larger_than_buffer),
        cmocka_unit_test(vss_is_valid_declared_smaller_than_header),
        cmocka_unit_test(vss_is_valid_header_only_frame),
        cmocka_unit_test(vss_calc_path_length_header_only),
        cmocka_unit_test(vss_calc_path_length_unframed),
        cmocka_unit_test(vss_is_valid_roundtrip),
        cmocka_unit_test(vss_static_path),
        cmocka_unit_test(vss_interop_path),
        cmocka_unit_test(vss_data_uint8),
        cmocka_unit_test(vss_data_int8),
        cmocka_unit_test(vss_data_uint16),
        cmocka_unit_test(vss_data_int16),
        cmocka_unit_test(vss_data_uint32),
        cmocka_unit_test(vss_data_int32),
        cmocka_unit_test(vss_data_uint64),
        cmocka_unit_test(vss_data_int64),
        cmocka_unit_test(vss_data_bool),
        cmocka_unit_test(vss_data_float),
        cmocka_unit_test(vss_data_double),
        cmocka_unit_test(vss_data_string),
        cmocka_unit_test(vss_data_uint8_array),
        cmocka_unit_test(vss_data_int8_array),
        cmocka_unit_test(vss_data_uint16_array),
        cmocka_unit_test(vss_data_int16_array),
        cmocka_unit_test(vss_data_uint32_array),
        cmocka_unit_test(vss_data_int32_array),
        cmocka_unit_test(vss_data_uint64_array),
        cmocka_unit_test(vss_data_int64_array),
        cmocka_unit_test(vss_data_bool_array),
        cmocka_unit_test(vss_data_float_array),
        cmocka_unit_test(vss_data_double_array),
        cmocka_unit_test(vss_data_string_array),
        cmocka_unit_test(vss_data_string_array_malformed),
        cmocka_unit_test(vss_path_interop_oob),
        cmocka_unit_test(vss_set_data_malformed_path_no_write),
        cmocka_unit_test(vss_data_string_oob),
        cmocka_unit_test(vss_data_uint8_array_oob),
        cmocka_unit_test(vss_data_int8_array_oob),
        cmocka_unit_test(vss_data_bool_array_oob),
        cmocka_unit_test(vss_data_string_array_oob),
        cmocka_unit_test(vss_data_uint16_array_oob),
        cmocka_unit_test(vss_data_int16_array_oob),
        cmocka_unit_test(vss_data_uint32_array_oob),
        cmocka_unit_test(vss_data_int32_array_oob),
        cmocka_unit_test(vss_data_uint64_array_oob),
        cmocka_unit_test(vss_data_int64_array_oob),
        cmocka_unit_test(vss_data_float_array_oob),
        cmocka_unit_test(vss_data_double_array_oob),
        cmocka_unit_test(vss_data_string_inflated_path_oob),
        cmocka_unit_test(vss_data_uint8_inflated_path_oob),
        cmocka_unit_test(vss_data_uint8_array_inflated_path_oob),
        cmocka_unit_test(vss_data_static_id_truncated_oob),
        cmocka_unit_test(vss_path_interop_zero_msg_length_oob),
        cmocka_unit_test(vss_data_string_zero_msg_length_oob),
    };

    return cmocka_run_group_tests(tests, NULL, NULL);
}
