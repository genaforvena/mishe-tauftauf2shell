/*
 * Copyright (c) 2024, COVESA
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of COVESA nor the names of its contributors may be
 *      used to endorse or promote products derived from this software without
 *      specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file
 * This file contains the common fields descriptions of the IEEE 1722 ACF PDUs
 */

#pragma once
#include "avtp/Inline.h"

#include "avtp/Utils.h"
#include "avtp/Defines.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AVTP_ACF_COMMON_HEADER_LEN (1 * AVTP_QUADLET_SIZE)

#define GET_ACF_COMMON_FIELD(field)                                                                \
    (Avtp_GetField(Avtp_AcfCommonFieldDesc, AVTP_ACF_COMMON_FIELD_MAX, (const uint8_t *)pdu, field))
#define SET_ACF_COMMON_FIELD(field, value)                                                         \
    (Avtp_SetField(Avtp_AcfCommonFieldDesc, AVTP_ACF_COMMON_FIELD_MAX, (uint8_t *)pdu, field,      \
                   value))

typedef struct {
    uint8_t header[AVTP_ACF_COMMON_HEADER_LEN];
    uint8_t payload[0];
} Avtp_AcfCommon_t;

/**
 * AVTP message types. See IEEE Std 1722-2025 table 22.
 *
 * This enum documents the standardized ACF message types only. The field is
 * user-extensible: IEEE 1722 reserves AVTP_ACF_TYPE_USER_FIRST to
 * AVTP_ACF_TYPE_USER_LAST for user-defined messages, and other specifications
 * assign further values (e.g. VSS uses 0x42). The accessors therefore use the
 * raw uint8_t field type.
 */
typedef enum {
    AVTP_ACF_TYPE_FLEXRAY = 0x0,
    AVTP_ACF_TYPE_CAN = 0x1,
    AVTP_ACF_TYPE_CAN_BRIEF = 0x2,
    AVTP_ACF_TYPE_LIN = 0x3,
    AVTP_ACF_TYPE_MOST = 0x4,
    AVTP_ACF_TYPE_GPC = 0x5,
    AVTP_ACF_TYPE_SERIAL = 0x6,
    AVTP_ACF_TYPE_PARALLEL = 0x7,
    AVTP_ACF_TYPE_SENSOR = 0x8,
    AVTP_ACF_TYPE_SENSOR_BRIEF = 0x9,
    AVTP_ACF_TYPE_AECP = 0x0A,
    AVTP_ACF_TYPE_ANCILLARY = 0x0B,
    AVTP_ACF_TYPE_GISF = 0x0C,
    AVTP_ACF_TYPE_BYTE_BUS = 0x0D,
    AVTP_ACF_TYPE_BYTE_BUS_BRIEF = 0x0E,
    AVTP_ACF_TYPE_I2C = 0x0F,
    AVTP_ACF_TYPE_I2C_BRIEF = 0x10,
    AVTP_ACF_TYPE_CAN_XL = 0x11,
    AVTP_ACF_TYPE_CAN_XL_BRIEF = 0x12,
    AVTP_ACF_TYPE_CAN_V2 = 0x21,
    AVTP_ACF_TYPE_CAN_BRIEF_V2 = 0x22,
    AVTP_ACF_TYPE_LIN_V2 = 0x23,
    AVTP_ACF_TYPE_CHECKSUM = 0x76,
    AVTP_ACF_TYPE_CRC = 0x77,
    AVTP_ACF_TYPE_USER_FIRST = 0x78,
    AVTP_ACF_TYPE_USER_LAST = 0x7F,
} Avtp_AcfMsgType_t;

/**
 * This enum maps all IEEE 1722 ACF common header fields to a descriptor.
 */
typedef enum {
    /* ACF common header fields */
    AVTP_ACF_FIELD_ACF_MSG_TYPE = 0,
    AVTP_ACF_FIELD_ACF_MSG_LENGTH,

    /* Count number of fields for bound checks */
    AVTP_ACF_COMMON_FIELD_MAX
} Avtp_AcfCommonFields_t;

/**
 * This table maps all IEEE 1722 ACF common header fields to a descriptor.
 */
static const Avtp_FieldDescriptor_t Avtp_AcfCommonFieldDesc[AVTP_ACF_COMMON_FIELD_MAX] = {
    /* ACF common header */
    [AVTP_ACF_FIELD_ACF_MSG_TYPE] = {.quadlet = 0, .offset = 0, .bits = 7},
    [AVTP_ACF_FIELD_ACF_MSG_LENGTH] = {.quadlet = 0, .offset = 7, .bits = 9},
};

/**
 * Returns the value of an an ACF common header field as specified in the IEEE 1722 Specification.
 *
 * @param pdu Pointer to the first bit of an 1722 ACF PDU.
 * @param field Specifies the position of the data field to be read.
 * @returns Returns the field of the PDU.
 */
OPEN1722_INLINE uint64_t Avtp_AcfCommon_GetField(const Avtp_AcfCommon_t *const pdu,
                                                 Avtp_AcfCommonFields_t field)
{
    return GET_ACF_COMMON_FIELD(field);
}

/**
 * Returns the ACF message type field value.
 *
 * The ACF message type is a user-extensible 7-bit field: IEEE 1722 reserves
 * AVTP_ACF_TYPE_USER_FIRST to AVTP_ACF_TYPE_USER_LAST for user-defined
 * messages, and other specifications assign further values (e.g. VSS uses
 * 0x42). These cannot be expressed by Avtp_AcfMsgType_t, so the raw field is
 * returned as uint8_t.
 *
 * @param pdu Pointer to the first bit of an 1722 ACF PDU.
 * @returns Returns the ACF message type field of the PDU.
 */
OPEN1722_INLINE uint8_t Avtp_AcfCommon_GetAcfMsgType(const Avtp_AcfCommon_t *const pdu)
{
    return (uint8_t)GET_ACF_COMMON_FIELD(AVTP_ACF_FIELD_ACF_MSG_TYPE);
}

/**
 * Returns the ACF message length field value.
 *
 * @param pdu Pointer to the first bit of an 1722 ACF PDU.
 * @returns Returns the ACF message length field of the PDU.
 */
OPEN1722_INLINE uint16_t Avtp_AcfCommon_GetAcfMsgLength(const Avtp_AcfCommon_t *const pdu)
{
    return (uint16_t)GET_ACF_COMMON_FIELD(AVTP_ACF_FIELD_ACF_MSG_LENGTH);
}

/**
 * Returns the ACF message length field value in bytes.
 *
 * The ACF message length field is quadlet-encoded; this converts it to octets.
 *
 * @param pdu Pointer to the first bit of an 1722 ACF PDU.
 * @returns Returns the ACF message length field of the PDU in bytes.
 */
OPEN1722_INLINE uint16_t Avtp_AcfCommon_GetAcfMsgLengthInBytes(const Avtp_AcfCommon_t *const pdu)
{
    return (uint16_t)(Avtp_AcfCommon_GetAcfMsgLength(pdu) * AVTP_QUADLET_SIZE);
}

/**
 * Sets the value of an an ACF common header field as specified in the IEEE 1722 Specification.
 *
 * @param pdu Pointer to the first bit of an 1722 ACF PDU.
 * @param field Specifies the position of the data field to be read
 * @param value Pointer to location to store the value.
 */
OPEN1722_INLINE void Avtp_AcfCommon_SetField(Avtp_AcfCommon_t *pdu, Avtp_AcfCommonFields_t field,
                                             uint64_t value)
{
    SET_ACF_COMMON_FIELD(field, value);
}

/**
 * Sets the ACF message type field value as specified in the IEEE 1722 Specification.
 *
 * The value is a raw 7-bit field and may be a user-defined or externally
 * assigned ACF message type in addition to the standardized values listed in
 * Avtp_AcfMsgType_t.
 *
 * @param pdu Pointer to the first bit of an 1722 ACF PDU.
 * @param value Value to set the ACF message type field to.
 */
OPEN1722_INLINE void Avtp_AcfCommon_SetAcfMsgType(Avtp_AcfCommon_t *pdu, uint8_t value)
{
    SET_ACF_COMMON_FIELD(AVTP_ACF_FIELD_ACF_MSG_TYPE, value);
}

/**
 * Sets the ACF message length field value as specified in the IEEE 1722 Specification.
 *
 * @param pdu Pointer to the first bit of an 1722 ACF PDU.
 * @param value Value to set the ACF message length field to.
 */
OPEN1722_INLINE void Avtp_AcfCommon_SetAcfMsgLength(Avtp_AcfCommon_t *pdu, uint16_t value)
{
    SET_ACF_COMMON_FIELD(AVTP_ACF_FIELD_ACF_MSG_LENGTH, value);
}

#ifdef __cplusplus
}
#endif
