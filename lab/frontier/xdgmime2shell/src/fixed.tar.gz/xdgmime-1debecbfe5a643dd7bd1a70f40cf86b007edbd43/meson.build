project('xdgmime', 'c',
    version: '0.0',
    default_options: ['c_std=c99', 'warning_level=3', 'debug=true'],
    meson_version: '>=0.54.0',
)

add_project_arguments(
    '-D_POSIX_C_SOURCE=200809L',
    '-DXDG_PREFIX=xdg_test',
    '-DHAVE_MMAP',
    '-Wduplicated-branches',
    '-Wimplicit-fallthrough',
    '-Wmisleading-indentation',
    '-Wmissing-field-initializers',
    '-Wnonnull',
    '-Wstrict-prototypes',
    '-Wunused',
    '-Werror=format=2',
    '-Werror=implicit-function-declaration',
    '-Werror=init-self',
    '-Werror=missing-include-dirs',
    '-Werror=missing-prototypes',
    '-Werror=pointer-arith',
    '-Werror=pointer-sign',
    '-Werror=sign-compare',
    '-Werror=unused-result',
    language: 'c',
)

cc = meson.get_compiler('c')

have_cxx = add_languages('cpp', native: false, required: get_option('oss_fuzz').enabled())
if have_cxx
  cxx = meson.get_compiler('cpp')
endif

subdir('src')
subdir('fuzzing')