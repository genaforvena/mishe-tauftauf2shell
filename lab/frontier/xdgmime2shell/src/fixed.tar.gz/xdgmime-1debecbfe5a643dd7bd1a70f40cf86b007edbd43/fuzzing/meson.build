# Copyright 2018 pdknsk
# Copyright 2020, 2021, 2022 Endless OS Foundation, LLC
# Copyright 2023 GNOME Foundation Inc.
#
# SPDX-License-Identifier: LGPL-2.1-or-later or AFL-2.0

fuzz_targets = [
  'fuzz_dump',
]

deps = [libxdgmime_dep]

extra_sources = ['setup.c']
extra_c_args = cc.get_supported_arguments('-Werror=unused-function')

# Links in a static library provided by oss-fuzz, else a standalone driver.
# https://google.github.io/oss-fuzz/getting-started/new-project-guide/#buildsh-script-environment
have_fuzzing_engine = false
if have_cxx
  fuzzing_engine = cxx.find_library('FuzzingEngine', required : get_option('oss_fuzz'))
  have_fuzzing_engine = fuzzing_engine.found()
endif
if have_fuzzing_engine
  deps += fuzzing_engine
else
  extra_sources += 'driver.c'
endif

foreach target_name : fuzz_targets
  exe = executable(target_name, [extra_sources, target_name + '.c'],
    c_args : extra_c_args,
    dependencies : deps,
  )

  # If the FuzzingEngine isn’t available, build some unit tests to check that
  # the fuzzing files do basically work. This doesn’t do any actual fuzzing though.
  # Pass in the README as an arbitrary fuzzing input, just so we have something.
  if not have_fuzzing_engine
    test(target_name, exe,
      args : files('README.md'),
      suite : 'fuzzing',
    )
  endif
endforeach