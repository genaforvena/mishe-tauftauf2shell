xdgmime_sources = [
    'xdgmime.c',
    'xdgmimeglob.c',
    'xdgmimeint.c',
    'xdgmimemagic.c',
    'xdgmimealias.c',
    'xdgmimeparent.c',
    'xdgmimecache.c',
    'xdgmimeicon.c',
]

libxdgmime = static_library('xdgmime',
    sources: xdgmime_sources,
)

libxdgmime_dep = declare_dependency(
  link_with : libxdgmime,
  include_directories : ['.'],
)
meson.override_dependency('xdgmime', libxdgmime_dep)

test_mime = executable('test-mime',
    'test-mime.c',
    link_with: libxdgmime,
    install: false,
)
meson.override_find_program('test-mime', test_mime)

test_mime_data = executable('test-mime-data',
    'test-mime-data.c',
    link_with: libxdgmime,
    install: false,
)
meson.override_find_program('test-mime-data', test_mime_data)

print_mime_data = executable('print-mime-data',
    'print-mime-data.c',
    link_with: libxdgmime,
    install: false,
)
meson.override_find_program('print-mime-data', print_mime_data)
