#ifndef ASN1SCC_ASN1CRT_ENCODING_ACN_H_
#define ASN1SCC_ASN1CRT_ENCODING_ACN_H_

#include "asn1crt_encoding_uper.h"

#ifdef  __cplusplus
extern "C" {
#endif


/*

       db         ,ad8888ba,   888b      88           88888888888                                             88
      d88b       d8"'    `"8b  8888b     88           88                                               ,d     ""
     d8'`8b     d8'            88 `8b    88           88                                               88
    d8'  `8b    88             88  `8b   88           88aaaaa  88       88  8b,dPPYba,    ,adPPYba,  MM88MMM  88   ,adPPYba,   8b,dPPYba,   ,adPPYba,
   d8YaaaaY8b   88             88   `8b  88           88"""""  88       88  88P'   `"8a  a8"     ""    88     88  a8"     "8a  88P'   `"8a  I8[    ""
  d8""""""""8b  Y8,            88    `8b 88           88       88       88  88       88  8b            88     88  8b       d8  88       88   `"Y8ba,
 d8'        `8b  Y8a.    .a8P  88     `8888           88       "8a,   ,a88  88       88  "8a,   ,aa    88,    88  "8a,   ,a8"  88       88  aa    ]8I
d8'          `8b  `"Y8888Y"'   88      `888           88        `"YbbdP'Y8  88       88   `"Ybbd8"'    "Y888  88   `"YbbdP"'   88       88  `"YbbdP"
*/

void Acn_AlignToNextByte(BitStream* pBitStrm, flag bEncode);
void Acn_AlignToNextWord(BitStream* pBitStrm, flag bEncode);
void Acn_AlignToNextDWord(BitStream* pBitStrm, flag bEncode);

/*ACN Integer functions*/
void Acn_Enc_Int_PositiveInteger_ConstSize(BitStream* pBitStrm, asn1SccUint intVal, int encodedSizeInBits);
void Acn_Enc_Int_PositiveInteger_ConstSize_8(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_Int_PositiveInteger_ConstSize_big_endian_16(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_Int_PositiveInteger_ConstSize_big_endian_32(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_Int_PositiveInteger_ConstSize_big_endian_64(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_Int_PositiveInteger_ConstSize_little_endian_16(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_Int_PositiveInteger_ConstSize_little_endian_32(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_Int_PositiveInteger_ConstSize_little_endian_64(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_Int_PositiveInteger_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccUint intVal);

void Acn_Enc_Int_TwosComplement_ConstSize(BitStream* pBitStrm, asn1SccSint intVal, int encodedSizeInBits);
void Acn_Enc_Int_TwosComplement_ConstSize_8(BitStream* pBitStrm, asn1SccSint intVal);
void Acn_Enc_Int_TwosComplement_ConstSize_big_endian_16(BitStream* pBitStrm, asn1SccSint intVal);
void Acn_Enc_Int_TwosComplement_ConstSize_big_endian_32(BitStream* pBitStrm, asn1SccSint intVal);
void Acn_Enc_Int_TwosComplement_ConstSize_big_endian_64(BitStream* pBitStrm, asn1SccSint intVal);
void Acn_Enc_Int_TwosComplement_ConstSize_little_endian_16(BitStream* pBitStrm, asn1SccSint intVal);
void Acn_Enc_Int_TwosComplement_ConstSize_little_endian_32(BitStream* pBitStrm, asn1SccSint intVal);
void Acn_Enc_Int_TwosComplement_ConstSize_little_endian_64(BitStream* pBitStrm, asn1SccSint intVal);
void Acn_Enc_Int_TwosComplement_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccSint intVal);

void Acn_Enc_Int_BCD_ConstSize(BitStream* pBitStrm, asn1SccUint intVal, int encodedSizeInNibbles);
void Acn_Enc_Int_BCD_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_Int_BCD_VarSize_NullTerminated(BitStream* pBitStrm, asn1SccUint intVal); /*encoding ends when 'F' is reached*/

void Acn_Enc_SInt_ASCII_ConstSize(BitStream* pBitStrm, asn1SccSint intVal, int encodedSizeInBytes);
void Acn_Enc_SInt_ASCII_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccSint intVal);
void Acn_Enc_SInt_ASCII_VarSize_NullTerminated(BitStream* pBitStrm, asn1SccSint intVal, const byte null_characters[], size_t null_characters_size); /*encoding ends when null_character is reached*/

void Acn_Enc_UInt_ASCII_ConstSize(BitStream* pBitStrm, asn1SccUint intVal, int encodedSizeInBytes);
void Acn_Enc_UInt_ASCII_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccUint intVal);
void Acn_Enc_UInt_ASCII_VarSize_NullTerminated(BitStream* pBitStrm, asn1SccUint intVal, const byte null_characters[], size_t null_characters_size); /*encoding ends when null_character is reached*/


/*ACN Decode Integer functions*/
flag Acn_Dec_Int_PositiveInteger_ConstSize(BitStream* pBitStrm, asn1SccUint* pIntVal, int encodedSizeInBits);
flag Acn_Dec_Int_PositiveInteger_ConstSize_8(BitStream* pBitStrm, asn1SccUint* pIntVal);
flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_16(BitStream* pBitStrm, asn1SccUint* pIntVal);
flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_32(BitStream* pBitStrm, asn1SccUint* pIntVal);
flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_64(BitStream* pBitStrm, asn1SccUint* pIntVal);
flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_16(BitStream* pBitStrm, asn1SccUint* pIntVal);
flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_32(BitStream* pBitStrm, asn1SccUint* pIntVal);
flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_64(BitStream* pBitStrm, asn1SccUint* pIntVal);
flag Acn_Dec_Int_PositiveInteger_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccUint* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize(BitStream* pBitStrm, asn1SccSint* pIntVal, int encodedSizeInBits);
flag Acn_Dec_Int_TwosComplement_ConstSize_8(BitStream* pBitStrm, asn1SccSint* pIntVal);
flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_16(BitStream* pBitStrm, asn1SccSint* pIntVal);
flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_32(BitStream* pBitStrm, asn1SccSint* pIntVal);
flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_64(BitStream* pBitStrm, asn1SccSint* pIntVal);
flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_16(BitStream* pBitStrm, asn1SccSint* pIntVal);
flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_32(BitStream* pBitStrm, asn1SccSint* pIntVal);
flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_64(BitStream* pBitStrm, asn1SccSint* pIntVal);
flag Acn_Dec_Int_TwosComplement_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccSint* pIntVal);

flag Acn_Dec_Int_BCD_ConstSize(BitStream* pBitStrm, asn1SccUint* pIntVal, int encodedSizeInNibbles);
flag Acn_Dec_Int_BCD_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccUint* pIntVal);
/*encoding ends when 'F' is reached*/
flag Acn_Dec_Int_BCD_VarSize_NullTerminated(BitStream* pBitStrm, asn1SccUint* pIntVal);

flag Acn_Dec_SInt_ASCII_ConstSize(BitStream* pBitStrm, asn1SccSint* pIntVal, int encodedSizeInBytes);
flag Acn_Dec_SInt_ASCII_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccSint* pIntVal);
flag Acn_Dec_SInt_ASCII_VarSize_NullTerminated(BitStream* pBitStrm, asn1SccSint* pIntVal, const byte null_characters[], size_t null_characters_size);

flag Acn_Dec_UInt_ASCII_ConstSize(BitStream* pBitStrm, asn1SccUint* pIntVal, int encodedSizeInBytes);
flag Acn_Dec_UInt_ASCII_VarSize_LengthEmbedded(BitStream* pBitStrm, asn1SccUint* pIntVal);
flag Acn_Dec_UInt_ASCII_VarSize_NullTerminated(BitStream* pBitStrm, asn1SccUint* pIntVal, const byte null_characters[], size_t null_characters_size);

/*flag Acn_Dec_Int_ASCII_NullTerminated_FormattedInteger(BitStream* pBitStrm, const char* format, asn1SccSint* pIntVal);*/

flag Acn_Dec_Int_PositiveInteger_ConstSizeUInt8(BitStream* pBitStrm, uint8_t* pIntVal, int encodedSizeInBits);

flag Acn_Dec_Int_PositiveInteger_ConstSizeUInt16(BitStream* pBitStrm, uint16_t* pIntVal, int encodedSizeInBits);

flag Acn_Dec_Int_PositiveInteger_ConstSizeUInt32(BitStream* pBitStrm, uint32_t* pIntVal, int encodedSizeInBits);

flag Acn_Dec_Int_PositiveInteger_ConstSize_8UInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_16UInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_16UInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_32UInt32(BitStream* pBitStrm, uint32_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_32UInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_32UInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_64UInt32(BitStream* pBitStrm, uint32_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_64UInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_big_endian_64UInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_16UInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_16UInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_32UInt32(BitStream* pBitStrm, uint32_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_32UInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_32UInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_64UInt32(BitStream* pBitStrm, uint32_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_64UInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_ConstSize_little_endian_64UInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_VarSize_LengthEmbeddedUInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_VarSize_LengthEmbeddedUInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_PositiveInteger_VarSize_LengthEmbeddedUInt32(BitStream* pBitStrm, uint32_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSizeInt8(BitStream* pBitStrm, int8_t* pIntVal, int encodedSizeInBits);

flag Acn_Dec_Int_TwosComplement_ConstSizeInt16(BitStream* pBitStrm, int16_t* pIntVal, int encodedSizeInBits);

flag Acn_Dec_Int_TwosComplement_ConstSizeInt32(BitStream* pBitStrm, int32_t* pIntVal, int encodedSizeInBits);

flag Acn_Dec_Int_TwosComplement_ConstSize_8Int8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_16Int16(BitStream* pBitStrm, int16_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_16Int8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_32Int32(BitStream* pBitStrm, int32_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_32Int16(BitStream* pBitStrm, int16_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_32Int8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_64Int32(BitStream* pBitStrm, int32_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_64Int16(BitStream* pBitStrm, int16_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_big_endian_64Int8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_16Int16(BitStream* pBitStrm, int16_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_16Int8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_32Int32(BitStream* pBitStrm, int32_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_32Int16(BitStream* pBitStrm, int16_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_32Int8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_64Int32(BitStream* pBitStrm, int32_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_64Int16(BitStream* pBitStrm, int16_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_ConstSize_little_endian_64Int8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_VarSize_LengthEmbeddedInt8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_VarSize_LengthEmbeddedInt16(BitStream* pBitStrm, int16_t* pIntVal);

flag Acn_Dec_Int_TwosComplement_VarSize_LengthEmbeddedInt32(BitStream* pBitStrm, int32_t* pIntVal);

flag Acn_Dec_Int_BCD_ConstSizeUInt8(BitStream* pBitStrm, uint8_t* pIntVal, int encodedSizeInNibbles);

flag Acn_Dec_Int_BCD_ConstSizeUInt16(BitStream* pBitStrm, uint16_t* pIntVal, int encodedSizeInNibbles);

flag Acn_Dec_Int_BCD_ConstSizeUInt32(BitStream* pBitStrm, uint32_t* pIntVal, int encodedSizeInNibbles);

flag Acn_Dec_Int_BCD_VarSize_LengthEmbeddedUInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_BCD_VarSize_LengthEmbeddedUInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_BCD_VarSize_LengthEmbeddedUInt32(BitStream* pBitStrm, uint32_t* pIntVal);

flag Acn_Dec_Int_BCD_VarSize_NullTerminatedUInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_Int_BCD_VarSize_NullTerminatedUInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_Int_BCD_VarSize_NullTerminatedUInt32(BitStream* pBitStrm, uint32_t* pIntVal);

flag Acn_Dec_SInt_ASCII_ConstSizeInt8(BitStream* pBitStrm, int8_t* pIntVal, int encodedSizeInBytes);

flag Acn_Dec_SInt_ASCII_ConstSizeInt16(BitStream* pBitStrm, int16_t* pIntVal, int encodedSizeInBytes);

flag Acn_Dec_SInt_ASCII_ConstSizeInt32(BitStream* pBitStrm, int32_t* pIntVal, int encodedSizeInBytes);

flag Acn_Dec_SInt_ASCII_VarSize_LengthEmbeddedInt8(BitStream* pBitStrm, int8_t* pIntVal);

flag Acn_Dec_SInt_ASCII_VarSize_LengthEmbeddedInt16(BitStream* pBitStrm, int16_t* pIntVal);

flag Acn_Dec_SInt_ASCII_VarSize_LengthEmbeddedInt32(BitStream* pBitStrm, int32_t* pIntVal);

flag Acn_Dec_SInt_ASCII_VarSize_NullTerminatedInt8(BitStream* pBitStrm, int8_t* pIntVal, const byte null_characters[], size_t null_characters_size);

flag Acn_Dec_SInt_ASCII_VarSize_NullTerminatedInt16(BitStream* pBitStrm, int16_t* pIntVal, const byte null_characters[], size_t null_characters_size);

flag Acn_Dec_SInt_ASCII_VarSize_NullTerminatedInt32(BitStream* pBitStrm, int32_t* pIntVal, const byte null_characters[], size_t null_characters_size);

flag Acn_Dec_UInt_ASCII_ConstSizeUInt8(BitStream* pBitStrm, uint8_t* pIntVal, int encodedSizeInBytes);

flag Acn_Dec_UInt_ASCII_ConstSizeUInt16(BitStream* pBitStrm, uint16_t* pIntVal, int encodedSizeInBytes);

flag Acn_Dec_UInt_ASCII_ConstSizeUInt32(BitStream* pBitStrm, uint32_t* pIntVal, int encodedSizeInBytes);

flag Acn_Dec_UInt_ASCII_VarSize_LengthEmbeddedUInt8(BitStream* pBitStrm, uint8_t* pIntVal);

flag Acn_Dec_UInt_ASCII_VarSize_LengthEmbeddedUInt16(BitStream* pBitStrm, uint16_t* pIntVal);

flag Acn_Dec_UInt_ASCII_VarSize_LengthEmbeddedUInt32(BitStream* pBitStrm, uint32_t* pIntVal);

flag Acn_Dec_UInt_ASCII_VarSize_NullTerminatedUInt8(BitStream* pBitStrm, uint8_t* pIntVal, const byte null_characters[], size_t null_characters_size);

flag Acn_Dec_UInt_ASCII_VarSize_NullTerminatedUInt16(BitStream* pBitStrm, uint16_t* pIntVal, const byte null_characters[], size_t null_characters_size);

flag Acn_Dec_UInt_ASCII_VarSize_NullTerminatedUInt32(BitStream* pBitStrm, uint32_t* pIntVal, const byte null_characters[], size_t null_characters_size);


/* Boolean Decode */

flag BitStream_ReadBitPattern(BitStream* pBitStrm, const byte* patternToRead, int nBitsToRead, flag* pBoolValue);
flag BitStream_DecodeTrueFalseBoolean(BitStream* pBitStrm, const byte* truePattern, const byte* falsePattern, int nBitsToRead, flag* pBoolValue);

/* NULL Type functions*/
flag BitStream_ReadBitPattern_ignore_value(BitStream* pBitStrm, int nBitsToRead);

/*Real encoding functions*/
void Acn_Enc_Real_IEEE754_32_big_endian(BitStream* pBitStrm, asn1Real realValue);
void Acn_Enc_Real_IEEE754_64_big_endian(BitStream* pBitStrm, asn1Real realValue);
void Acn_Enc_Real_IEEE754_32_little_endian(BitStream* pBitStrm, asn1Real realValue);
void Acn_Enc_Real_IEEE754_64_little_endian(BitStream* pBitStrm, asn1Real realValue);

flag Acn_Dec_Real_IEEE754_32_big_endian(BitStream* pBitStrm, asn1Real* pRealValue);
flag Acn_Dec_Real_IEEE754_64_big_endian(BitStream* pBitStrm, asn1Real* pRealValue);
flag Acn_Dec_Real_IEEE754_32_little_endian(BitStream* pBitStrm, asn1Real* pRealValue);
flag Acn_Dec_Real_IEEE754_64_little_endian(BitStream* pBitStrm, asn1Real* pRealValue);

flag Acn_Dec_Real_IEEE754_32_big_endian_fp32(BitStream* pBitStrm, float* pRealValue);
flag Acn_Dec_Real_IEEE754_32_little_endian_fp32(BitStream* pBitStrm, float* pRealValue);

/*String functions*/
void Acn_Enc_String_Ascii_FixSize                       (BitStream* pBitStrm, asn1SccSint max, const char* strVal);
void Acn_Enc_String_Ascii_Null_Terminated                (BitStream* pBitStrm, asn1SccSint max, char null_character, const char* strVal);
void Acn_Enc_String_Ascii_Null_Terminated_mult           (BitStream* pBitStrm, asn1SccSint max, const byte null_character[], size_t null_character_size, const char* strVal);
void Acn_Enc_String_Ascii_External_Field_Determinant    (BitStream* pBitStrm, asn1SccSint max, const char* strVal);
void Acn_Enc_String_Ascii_Internal_Field_Determinant    (BitStream* pBitStrm, asn1SccSint max, asn1SccSint min, const char* strVal);
void Acn_Enc_String_CharIndex_FixSize                   (BitStream* pBitStrm, asn1SccSint max, byte allowedCharSet[], int charSetSize, const char* strVal);
void Acn_Enc_String_CharIndex_External_Field_Determinant(BitStream* pBitStrm, asn1SccSint max, byte allowedCharSet[], int charSetSize, const char* strVal);
void Acn_Enc_String_CharIndex_Internal_Field_Determinant(BitStream* pBitStrm, asn1SccSint max, byte allowedCharSet[], int charSetSize, asn1SccSint min, const char* strVal);
void Acn_Enc_IA5String_CharIndex_External_Field_Determinant(BitStream* pBitStrm, asn1SccSint max, const char* strVal);
void Acn_Enc_IA5String_CharIndex_Internal_Field_Determinant(BitStream* pBitStrm, asn1SccSint max, asn1SccSint min, const char* strVal);

flag Acn_Dec_String_Ascii_FixSize                       (BitStream* pBitStrm, asn1SccSint max, char* strVal);
flag Acn_Dec_String_Ascii_Null_Terminated                (BitStream* pBitStrm, asn1SccSint max, char null_character, char* strVal);
flag Acn_Dec_String_Ascii_Null_Terminated_mult           (BitStream* pBitStrm, asn1SccSint max, const byte null_character[], size_t null_character_size, char* strVal);
flag Acn_Dec_String_Ascii_External_Field_Determinant    (BitStream* pBitStrm, asn1SccSint max, asn1SccSint extSizeDeterminantFld, char* strVal);
flag Acn_Dec_String_Ascii_Internal_Field_Determinant    (BitStream* pBitStrm, asn1SccSint max, asn1SccSint min, char* strVal);
flag Acn_Dec_String_CharIndex_FixSize                   (BitStream* pBitStrm, asn1SccSint max, byte allowedCharSet[], int charSetSize, char* strVal);
flag Acn_Dec_String_CharIndex_External_Field_Determinant(BitStream* pBitStrm, asn1SccSint max, byte allowedCharSet[], int charSetSize, asn1SccSint extSizeDeterminantFld, char* strVal);
flag Acn_Dec_String_CharIndex_Internal_Field_Determinant(BitStream* pBitStrm, asn1SccSint max, byte allowedCharSet[], int charSetSize, asn1SccSint min, char* strVal);
flag Acn_Dec_IA5String_CharIndex_External_Field_Determinant(BitStream* pBitStrm, asn1SccSint max, asn1SccSint extSizeDeterminantFld, char* strVal);
flag Acn_Dec_IA5String_CharIndex_Internal_Field_Determinant(BitStream* pBitStrm, asn1SccSint max, asn1SccSint min, char* strVal);


/* Length Determinant functions*/
void Acn_Enc_Length(BitStream* pBitStrm, asn1SccUint lengthValue, int lengthSizeInBits);
flag Acn_Dec_Length(BitStream* pBitStrm, asn1SccUint* pLengthValue, int lengthSizeInBits);



asn1SccSint milbus_encode(asn1SccSint val);
asn1SccSint milbus_decode(asn1SccSint val);


/*
   ACN Deferred Patching — types and helpers for reserve-space + patch-later pattern.
   Used when --acn-deferred flag is enabled.
*/

/* Position in a bitstream — used to remember where to patch later */
typedef struct {
    long currentByte;
    int  currentBit;   /* 0..7 */
} AcnBitStreamPos;

/* Reference to an ACN-inserted field that will be patched later.
 * is_set + value enable consistency checking for shared determinants. */
typedef struct {
    AcnBitStreamPos pos;      /* where in the bitstream the field was reserved */
    flag            is_set;   /* TRUE after first PatchDet call */
    asn1SccUint     value;    /* the value that was written (for consistency checking) */
    char            str_value[256]; /* for IA5String determinants (consistency checking) */
} AcnInsertedFieldRef;

static inline AcnBitStreamPos Acn_BitStream_GetPos(const BitStream* bs) {
    AcnBitStreamPos p;
    p.currentByte = bs->currentByte;
    p.currentBit = bs->currentBit;
    return p;
}

static inline void Acn_BitStream_SetPos(BitStream* bs, AcnBitStreamPos p) {
    bs->currentByte = p.currentByte;
    bs->currentBit = p.currentBit;
}

static inline asn1SccUint Acn_BitStream_DistanceInBytes(AcnBitStreamPos start, AcnBitStreamPos end) {
    long startBits = start.currentByte * 8 + start.currentBit;
    long endBits = end.currentByte * 8 + end.currentBit;
    return (asn1SccUint)((endBits - startBits + 7) / 8);
}

static inline asn1SccUint Acn_BitStream_DistanceInBits(AcnBitStreamPos start, AcnBitStreamPos end) {
    long startBits = start.currentByte * 8 + start.currentBit;
    long endBits = end.currentByte * 8 + end.currentBit;
    return (asn1SccUint)(endBits - startBits);
}

/*
 * DEFINE_ACN_DET_ENCODERS(name, encoder_fn, size_bits)
 *
 * Generates InitDet/PatchDet wrappers for a specific integer encoding class.
 * - InitDet: saves current bitstream position, writes placeholder zeros
 * - PatchDet: seeks back to saved position, writes the actual value, restores position.
 *   For shared determinants (same field referenced by multiple children),
 *   the first call writes the value; subsequent calls verify consistency.
 */
#define DEFINE_ACN_DET_ENCODERS(name, encoder_fn, size_bits)                    \
static inline void Acn_InitDet_##name(BitStream* bs,                            \
                                      AcnInsertedFieldRef* det) {               \
    det->pos = Acn_BitStream_GetPos(bs);                                        \
    det->is_set = FALSE;                                                        \
    det->value = 0;                                                             \
    encoder_fn(bs, 0);                                                          \
}                                                                               \
static inline flag Acn_PatchDet_##name(asn1SccUint v, BitStream* bs,            \
                                       AcnInsertedFieldRef* det, int* err) {    \
    if (!det->is_set) {                                                         \
        AcnBitStreamPos cur = Acn_BitStream_GetPos(bs);                         \
        Acn_BitStream_SetPos(bs, det->pos);                                     \
        encoder_fn(bs, v);                                                      \
        Acn_BitStream_SetPos(bs, cur);                                          \
        det->value = v;                                                         \
        det->is_set = TRUE;                                                     \
        return TRUE;                                                            \
    } else {                                                                    \
        if (det->value != v) {                                                  \
            if (err) *err = ERR_ACN_DET_CONSISTENCY_MISMATCH;                   \
            return FALSE;                                                       \
        }                                                                       \
        return TRUE;                                                            \
    }                                                                           \
}

/* Unsigned integer encoding classes */
DEFINE_ACN_DET_ENCODERS(U8,      Acn_Enc_Int_PositiveInteger_ConstSize_8, 8)
DEFINE_ACN_DET_ENCODERS(U16_BE,  Acn_Enc_Int_PositiveInteger_ConstSize_big_endian_16, 16)
DEFINE_ACN_DET_ENCODERS(U32_BE,  Acn_Enc_Int_PositiveInteger_ConstSize_big_endian_32, 32)
DEFINE_ACN_DET_ENCODERS(U64_BE,  Acn_Enc_Int_PositiveInteger_ConstSize_big_endian_64, 64)
DEFINE_ACN_DET_ENCODERS(U16_LE,  Acn_Enc_Int_PositiveInteger_ConstSize_little_endian_16, 16)
DEFINE_ACN_DET_ENCODERS(U32_LE,  Acn_Enc_Int_PositiveInteger_ConstSize_little_endian_32, 32)
DEFINE_ACN_DET_ENCODERS(U64_LE,  Acn_Enc_Int_PositiveInteger_ConstSize_little_endian_64, 64)

/* Variant for signed (two's complement) encoder functions that take asn1SccSint */
#define DEFINE_ACN_DET_ENCODERS_SIGNED(name, encoder_fn, size_bits)             \
static inline void Acn_InitDet_##name(BitStream* bs,                            \
                                      AcnInsertedFieldRef* det) {               \
    det->pos = Acn_BitStream_GetPos(bs);                                        \
    det->is_set = FALSE;                                                        \
    det->value = 0;                                                             \
    encoder_fn(bs, 0);                                                          \
}                                                                               \
static inline flag Acn_PatchDet_##name(asn1SccUint v, BitStream* bs,            \
                                       AcnInsertedFieldRef* det, int* err) {    \
    if (!det->is_set) {                                                         \
        AcnBitStreamPos cur = Acn_BitStream_GetPos(bs);                         \
        Acn_BitStream_SetPos(bs, det->pos);                                     \
        encoder_fn(bs, (asn1SccSint)v);                                         \
        Acn_BitStream_SetPos(bs, cur);                                          \
        det->value = v;                                                         \
        det->is_set = TRUE;                                                     \
        return TRUE;                                                            \
    } else {                                                                    \
        if (det->value != v) {                                                  \
            if (err) *err = ERR_ACN_DET_CONSISTENCY_MISMATCH;                   \
            return FALSE;                                                       \
        }                                                                       \
        return TRUE;                                                            \
    }                                                                           \
}

/* Signed (two's complement) integer encoding classes */
DEFINE_ACN_DET_ENCODERS_SIGNED(I8,      Acn_Enc_Int_TwosComplement_ConstSize_8, 8)
DEFINE_ACN_DET_ENCODERS_SIGNED(I16_BE,  Acn_Enc_Int_TwosComplement_ConstSize_big_endian_16, 16)
DEFINE_ACN_DET_ENCODERS_SIGNED(I32_BE,  Acn_Enc_Int_TwosComplement_ConstSize_big_endian_32, 32)
DEFINE_ACN_DET_ENCODERS_SIGNED(I64_BE,  Acn_Enc_Int_TwosComplement_ConstSize_big_endian_64, 64)

/* Boolean determinant: 1-bit default encoding (writes 0 or 1 as a single bit) */
static inline void Acn_Enc_Bool_1bit(BitStream* bs, asn1SccUint v) {
    (void)bs; (void)v;
    BitStream_AppendBit(bs, v ? 1 : 0);
}
DEFINE_ACN_DET_ENCODERS(BOOL1, Acn_Enc_Bool_1bit, 1)

/* Generic ConstSize — arbitrary bit width.
 * Like DEFINE_ACN_DET_ENCODERS but the encoder takes 3 args (bs, value, nBits)
 * instead of 2.  The extra nBits parameter is forwarded by InitDet/PatchDet.
 * Uses macro approach so that function names (Acn_InitDet_##name) are created
 * via token pasting — this keeps them invisible to the line-based RTL header
 * pruning, avoiding collateral damage from removeFunctionFromHeader. */
#define DEFINE_ACN_DET_ENCODERS_CONSTSIZE(name, encoder_fn)                     \
static inline void Acn_InitDet_##name(BitStream* bs, int nBits,                 \
                                      AcnInsertedFieldRef* det) {               \
    (void)nBits;                                                                \
    det->pos = Acn_BitStream_GetPos(bs);                                        \
    det->is_set = FALSE;                                                        \
    det->value = 0;                                                             \
    encoder_fn(bs, 0, nBits);                                                   \
}                                                                               \
static inline flag Acn_PatchDet_##name(asn1SccUint v, BitStream* bs, int nBits, \
                                       AcnInsertedFieldRef* det, int* err) {    \
    (void)nBits;                                                                \
    if (!det->is_set) {                                                         \
        int _i;                                                                 \
        AcnBitStreamPos cur = Acn_BitStream_GetPos(bs);                         \
        Acn_BitStream_SetPos(bs, det->pos);                                     \
        /* Bit-by-bit overwrite: encoder_fn uses AppendPartialByte which   */ \
        /* clears adjacent bits when crossing a byte boundary — unsafe   */ \
        /* for patching in the middle of a stream. AppendBit is safe.    */ \
        for (_i = 0; _i < nBits; _i++)                                          \
            BitStream_AppendBit(bs, (byte)((v >> (nBits - 1 - _i)) & 1));       \
        Acn_BitStream_SetPos(bs, cur);                                          \
        det->value = v;                                                         \
        det->is_set = TRUE;                                                     \
        return TRUE;                                                            \
    } else {                                                                    \
        if (det->value != v) {                                                  \
            if (err) *err = ERR_ACN_DET_CONSISTENCY_MISMATCH;                   \
            return FALSE;                                                       \
        }                                                                       \
        return TRUE;                                                            \
    }                                                                           \
}

#define DEFINE_ACN_DET_ENCODERS_SIGNED_CONSTSIZE(name, encoder_fn)              \
static inline void Acn_InitDet_##name(BitStream* bs, int nBits,                 \
                                      AcnInsertedFieldRef* det) {               \
    (void)nBits;                                                                \
    det->pos = Acn_BitStream_GetPos(bs);                                        \
    det->is_set = FALSE;                                                        \
    det->value = 0;                                                             \
    encoder_fn(bs, 0, nBits);                                                   \
}                                                                               \
static inline flag Acn_PatchDet_##name(asn1SccUint v, BitStream* bs, int nBits, \
                                       AcnInsertedFieldRef* det, int* err) {    \
    (void)nBits;                                                                \
    if (!det->is_set) {                                                         \
        int _i;                                                                 \
        AcnBitStreamPos cur = Acn_BitStream_GetPos(bs);                         \
        Acn_BitStream_SetPos(bs, det->pos);                                     \
        /* Bit-by-bit write (same rationale as unsigned CONSTSIZE variant) */    \
        for (_i = 0; _i < nBits; _i++)                                          \
            BitStream_AppendBit(bs, (byte)((v >> (nBits - 1 - _i)) & 1));       \
        Acn_BitStream_SetPos(bs, cur);                                          \
        det->value = v;                                                         \
        det->is_set = TRUE;                                                     \
        return TRUE;                                                            \
    } else {                                                                    \
        if (det->value != v) {                                                  \
            if (err) *err = ERR_ACN_DET_CONSISTENCY_MISMATCH;                   \
            return FALSE;                                                       \
        }                                                                       \
        return TRUE;                                                            \
    }                                                                           \
}

DEFINE_ACN_DET_ENCODERS_CONSTSIZE(ConstSize, Acn_Enc_Int_PositiveInteger_ConstSize)
DEFINE_ACN_DET_ENCODERS_SIGNED_CONSTSIZE(TwosComplement_ConstSize, Acn_Enc_Int_TwosComplement_ConstSize)

/* IA5String determinant: fixed-size ASCII string (7 bits per character).
 * Defined in asn1crt_encoding_acn.c (not inline) to avoid header pruning
 * collateral damage — the body calls BitStream_AppendBit which, if pruned
 * from the header, would break macro bodies that reference it. */
void Acn_InitDet_IA5String_FixSize(BitStream* bs, int nChars, AcnInsertedFieldRef* det);
flag Acn_PatchDet_IA5String_FixSize(const char* strVal, BitStream* bs, int nChars, AcnInsertedFieldRef* det, int* err);


#ifdef  __cplusplus
}
#endif

#endif
