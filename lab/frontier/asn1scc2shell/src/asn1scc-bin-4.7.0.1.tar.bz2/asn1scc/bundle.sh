#!/bin/bash
echo 'Creating a standalone linux binary for asn1.exe embedding the mono runtime

This is a script made for the tool developpers and should usually not be called

If you get errors, check your /usr/lib/mono/ version, if you have a version higher than 4.0,
you should edit this script and use your version number

The generated binary is called asn1scc and cannot be renamed afterwards.
You must run this script with sudo
'

for file in StringTemplate.dll Antlr.dll Antlr3.Runtime.dll Antlr3.Utility.dll AntlrParser.ACN.dll Ast.dll Backend.c.ST.dll Backend.c.dll Backend2.ST.dll Backend2.dll FSharp.Core.dll ST.dll antlr.runtime.dll
do
    cp "$file" /usr/lib/mono/4.5 || exit 1
done
mkbundle -z -o asn1scc --static --deps --keeptemp asn1.exe
cat temp.c | sed 's,"asn1.exe","asn1",g'  | sed 's,newargs \[k++\] = image_name;,newargs [k++] = newargs[0]; // image_name;,' > aa.$$ && mv aa.$$ temp.c
cc -o asn1 -Wall `pkg-config --cflags mono-2` temp.c -lz `pkg-config --libs-only-L mono-2` -Wl,-Bstatic -lmono-2.0 -Wl,-Bdynamic `pkg-config --libs-only-l mono-2 | sed -e "s/\-lmono-2.0 //"` temp.o
for file in StringTemplate.dll Antlr.dll Antlr3.Runtime.dll Antlr3.Utility.dll AntlrParser.ACN.dll Ast.dll Backend.c.ST.dll Backend.c.dll Backend2.ST.dll Backend2.dll FSharp.Core.dll ST.dll antlr.runtime.dll
do
    rm /usr/lib/mono/4.5/"$file" || exit 1
done
