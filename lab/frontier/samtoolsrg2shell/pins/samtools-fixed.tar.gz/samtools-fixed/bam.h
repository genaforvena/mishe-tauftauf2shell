/*  bam.h -- miscellaneous BAM functions.

    Copyright (C) 2008-2014, 2019 Genome Research Ltd.

    Author: Heng Li <lh3@sanger.ac.uk>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.  */

#ifndef BAM_BAM_H
#define BAM_BAM_H

#include "htslib/sam.h"

int bam_remove_B(bam1_t *b);

const char *bam_get_library(sam_hdr_t *header, const bam1_t *b);

hts_pos_t unclipped_start(bam1_t *b, int include_hard_clips);
hts_pos_t unclipped_other_start(hts_pos_t op, char *cigar, int include_hard_clips);
hts_pos_t unclipped_end(bam1_t *b, int include_hard_clips);
hts_pos_t unclipped_other_end(int64_t op, char *cigar, int include_hard_clips);

#endif
